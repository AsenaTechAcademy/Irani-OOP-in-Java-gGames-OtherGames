package myPack;

import java.awt.event.MouseEvent;


public class AirCraft extends GameMovableElementAdapter
{
	private static int flag;//the state to be reset or not
	private static long time=0;
	
	public AirCraft(int x,int y)
	{
		super("Images/AirCraft.png", x, y);
		setFlag(0);
		
	}//@@@@@@@@@@@@@@@@@@@ end constructor
	public void Reset()
	{
		this.setXY(350 , 460); // set to first status
		
	}
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MouseEvent
	public boolean WantMouseEvents()
	{
		return true;
	}
	public void mouseMoved(MouseEvent e)
	{
		GGame.changeMouseCursor();
		setXY(e.getX()-this.getWidth()/2 ,  e.getY()-this.getHeight()/2);
	}
	public void mouseDragged(MouseEvent e)
	{
		GGame.changeMouseCursor();
		setXY(e.getX()-this.getWidth()/2 ,  e.getY()-this.getHeight()/2);
	}
	public void mouseR_Clicked(MouseEvent e)
	{
		Missile_Firing();
	}
	public void mouseL_Clicked(MouseEvent e)
	{
		//Bullet_Firing();
	}
	public void mouseL_Released(MouseEvent e)
	{
		Bullet_Firing();
	}
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Fire()
	private void Bullet_Firing()
	{
		if (GGame.getTotalBullet()>0)
		{
			// Create new Bullet and shoot it from the airCraft
			myBullet b1=new myBullet(0 , 0);
			b1.setXY(this.getX()+(this.getWidth()/2)-b1.getWidth()-5 , this.getY()-18);
			GGame.addNewEntity(b1);
			
			myBullet b2=new myBullet(0 , 0);
			b2.setXY(this.getX()+(this.getWidth()/2)-b2.getWidth()+117 , this.getY()-18);
			GGame.addNewEntity(b2);
			
			SoundStore.get().Play(Sounds.Fire2);
			GGame.DecreaseBullet(2);
		}
	}
	private void Missile_Firing()
	{
		if (GGame.getTotalMissile()>0)
		{
			// Create new Missile and shoot it from the airCraft
			myMissile m=new myMissile(0 , 0);
			m.setXY(this.getX()+(this.getWidth()/2)-m.getWidth()+25 , this.getY()-45);
		
			//SoundStore.get().Play(Sounds.Fire);
			GGame.addNewEntity(m);
			
			SoundStore.get().Play(Sounds.Fire3);
			GGame.DecreaseMissile(1);
		}
	}
	//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ other methods
	public void CollideWith(GameElementAdapter element)
	{
		if(flag==0 && element instanceof enemyBullet )
		{
			SoundStore.get().Play(Sounds.Explosion1);
			GGame.DecreaseLive();
			setFlag(1);
			setTime(System.currentTimeMillis());
		}
		if(element instanceof Enemy_AirCraft)
		{
			GGame.DecreaseLive();
			SoundStore.get().Play(Sounds.AirCraft);
		}
	}

	public static long getTime() {
		return time;
	}
	public static void setTime(long time) {
		AirCraft.time = time;
	}


	public static void setFlag(int flag) {
		AirCraft.flag = flag;
	}
}
