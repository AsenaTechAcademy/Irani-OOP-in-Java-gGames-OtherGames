package myPack;


public class Enemy_AirCraft extends GameMovableElementAdapter
{
	private int	maxLimit	=70;
	private  int lives;
	private int	direction;
	private static String[] Images={"Images/Brovo_Plane (0).png","Images/Brovo_Plane (1).png","Images/Brovo_Plane (2).png"
		,"Images/Brovo_Plane (3).png","Images/Brovo_Plane (4).png","Images/Brovo_Plane (5).png"
		,"Images/Brovo_Plane (6).png","Images/Brovo_Plane (7).png","Images/Brovo_Plane (8).png"
		,"Images/Brovo_Plane (9).png","Images/Brovo_Plane (10).png","Images/Brovo_Plane (11).png"
		,"batman-16-128_(12).png"};
	private int	X0 ;
	
	
	
	public Enemy_AirCraft(int type,int x, int y) 
	{
		super(Images[type], x, y);
	
		this.lives=3;
		X0=getX();
		direction=1;
	}
	
	protected void goNextPoint()
	{
		setXY(getX()+direction , getY()+1);
		if (getX()>X0+maxLimit)
			direction=-1; // go Left
		if (getX()<X0-maxLimit)
			direction=1; // go Right
	
		int Random=(int) (Math.floor(Math.random() * ( 200-0+1))+ 0);
		if(++Random==5)
			Fire();
	}
	
		
	private void decreaseLives()
	{
		this.lives--;
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	public void CollideWith(GameElementAdapter element)
	{
		if(element instanceof myBullet)
			if(this.lives!=1)
			{
				decreaseLives();
			}
			else
			{
				GGame.IncreaseScore(50);
				SoundStore.get().Play(Sounds.Explosion1);
				this.Destroy();
			}
		if(element instanceof myMissile)
		{
			SoundStore.get().Play(Sounds.Explosion1);
			this.Destroy();
		}
		if(element instanceof AirCraft)
		{
			this.Destroy();
		}
	}
	private void Fire()
	{
		// Create new Bullet and shoot it from the airCraft
		enemyBullet bullet=new enemyBullet(0 , 0);
		bullet.setXY(this.getX()+(this.getWidth()/2)-bullet.getWidth()+10 , this.getY()+this.getHeight()+5);
		
		SoundStore.get().Play(Sounds.Fire1);
		GGame.addNewEntity(bullet);
			
	}
}
