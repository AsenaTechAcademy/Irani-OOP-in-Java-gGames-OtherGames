package myPack;
public class GBackground extends GameElementAdapter
{
	public GBackground(int x , int y )
	{
		super("Images/BG-800-600.jpg" , x , y);
	}
	
}
