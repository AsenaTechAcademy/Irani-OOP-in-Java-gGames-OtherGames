package myPack;

public class GameConstants
{
	public final static int	window_Width	=800;
	public final static int	window_Height	=600;
	//public final static int	Game_Width	=800;
	//public final static int	Game_Height	=9000;
}
