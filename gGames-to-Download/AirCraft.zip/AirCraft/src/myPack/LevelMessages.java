package myPack;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class LevelMessages
{
	public static void ShowLevelMessages(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		ShowScoreBoard(currentPlayer , graphics , Levelstatus);
		ShowLevelNotStarted(currentPlayer , graphics , Levelstatus);
		ShowLossLive(currentPlayer , graphics , Levelstatus);
		ShowGameOver(currentPlayer , graphics , Levelstatus);
		ShowLevelWinned(currentPlayer , graphics , Levelstatus);
		ShowMenu(currentPlayer , graphics , Levelstatus);
	}
	
	private static void ShowMenu(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_Player)
		{
			graphics.setColor(Color.decode("#eece60"));
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Lucida Calligraphy" , Font.BOLD , 28));
			graphics.drawString("Game Stop" , 320 , 405);
			
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Lucida Calligraphy" , Font.BOLD , 12));
			graphics.drawString("press  ESC to exit game" , 310 , 440);
			graphics.drawString("press  Ctrl  to resume game" , 310 , 453);
		}
	}
	
	private static void ShowScoreBoard(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		graphics.setColor(Color.decode("#fb40b9"));
		graphics.setFont(new Font("Lucida Calligraphy" , Font.BOLD , 16));
		graphics.drawString("Level: "+currentPlayer.getCurrentLevel() , 20 , 590);
		graphics.drawString("Lives: "+currentPlayer.getLives() , 100 , 590);
		graphics.drawString("Score: "+currentPlayer.getScore() , 200 , 590);
		graphics.drawString("Bullet: "+currentPlayer.getBullet() , 300 , 590);
		graphics.drawString("Missile: "+currentPlayer.getMissile() , 400 , 590);
		graphics.drawString("Time: "+currentPlayer.getCurrentTime() , 520 , 590);
		graphics.drawString("Salaam  "+currentPlayer.getPlayerName()+", " , 630 , 590);
	}
	
	private static void ShowLevelNotStarted(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelNotStarted)
		{
			
			graphics.setColor(Color.decode("#eece60"));
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Hobo Std" , Font.BOLD , 28));
			graphics.drawString("Welcome to Aircrafts War" , 190 , 415);
			
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Latin" , Font.BOLD , 12));
			graphics.drawString("Hi "+currentPlayer.getPlayerName()
					+", Press Ctrl to get in" , 200 , 440);
		}
	}
	
	
	private static void ShowGameOver(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.GameOver)
		{
			graphics.setColor(Color.decode("#eece60"));
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.decode("#6b0f01"));
			graphics.setFont(new Font("Hobo Std" , Font.BOLD , 28));
			graphics.drawString("Game Over , :( !" , 230 , 405);
			
			graphics.setColor(Color.decode("#747ce7"));
			graphics.setFont(new Font("Latin" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to exit" , 310 , 440);
		}
	}
	
	private static void ShowLossLive(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_LiveLoss)
		{
			graphics.setColor(Color.decode("#eece60"));
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Lucida Calligraphy" , Font.BOLD , 28));
			graphics.drawString("Be careful !!" , 300 , 405);
			
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Lucida Calligraphy" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to continue" , 310 , 440);
		}
	}
	
	private static void ShowLevelWinned(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelWined)
		{
			graphics.setColor(Color.decode("#eece60"));
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Lucida Calligraphy" , Font.BOLD , 28));
			graphics.drawString("OK, Level Complete" , 250 , 405);
			
			graphics.setColor(Color.decode("#fa474b"));
			graphics.setFont(new Font("Lucida Calligraphy" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to next level" , 310 , 440);
		}
	}
	
}
