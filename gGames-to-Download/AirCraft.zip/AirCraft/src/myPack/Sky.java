package myPack;

public class Sky extends GameMovableElementAdapter 
{
	private static String[] Images={"Images/star_small(0).png","Images/full-star(1).png","Images/cloud(2).png","Images/explosion_48(3).png"};
	
	
	public Sky(int type,int x,int y)
	{
		super(Images[type], x, y);
		setDownDirection();
		setSpeedY(1);
		StartMoving();
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	
}//end class Sky
