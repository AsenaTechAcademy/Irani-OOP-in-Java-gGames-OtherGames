package myPack;
import java.applet.Applet;
import java.applet.AudioClip;
import java.util.HashMap;

public class SoundStore
{
	private static SoundStore	single			=new SoundStore();
	private static String		SoundFiles[]	= { Sounds.AirCraft, Sounds.Explosion1, Sounds.Fire2,
			Sounds.Fire1,  Sounds.Fire3 , Sounds.Gun_Cock };
	
	public static SoundStore get()
	{
		return single;
	}
	
	private HashMap<String,AudioClip>	sounds;
	
	public void LoadSounds()
	{
		sounds=new HashMap<String,AudioClip>();
		for (int i=0 ; i<SoundFiles.length ; i++)
		{
			AudioClip clip=Applet.newAudioClip(this.getClass().getClassLoader().getResource(SoundFiles[i]));
			sounds.put(SoundFiles[i] , clip);
		}
	}
	
	public void Play(String ref)
	{
		if (sounds.get(ref)!=null)
			 sounds.get(ref).play();
	}
	
}// End of Class