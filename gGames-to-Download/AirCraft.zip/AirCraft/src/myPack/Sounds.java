package myPack;
public class Sounds
{
	public final static String	Fire1	="Sounds/Fire1.wav";
	public final static String	Fire2	="Sounds/Fire2.wav";
	public final static String	Fire3	="Sounds/Fire3.wav";
	public final static String	Explosion1	="Sounds/Explosion1.wav";
	public final static String	AirCraft	="Sounds/AirCraft.wav";
	public final static String	Gun_Cock		="Sounds/Gun_Cock.wav";
}
