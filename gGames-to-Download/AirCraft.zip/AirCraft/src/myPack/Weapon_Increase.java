package myPack;

public class Weapon_Increase extends GameMovableElementAdapter
{

	
	public Weapon_Increase( int x, int y)
	{
		super("Images/Increase_Bullet_Missile.png",x,y);
		setDownDirection();
		setSpeedY(1);
		StartMoving();
	}
	
	protected void CollideDownBorder()
	{
		Destroy();
	}
	public void CollideWith(GameElementAdapter element) 
	{
		if(element instanceof AirCraft)
		{
			this.Destroy();
			SoundStore.get().Play(Sounds.Gun_Cock);
			GGame.IcreaseMissile(10);
			GGame.IncreaseBullet(20);
		}
	}
}
