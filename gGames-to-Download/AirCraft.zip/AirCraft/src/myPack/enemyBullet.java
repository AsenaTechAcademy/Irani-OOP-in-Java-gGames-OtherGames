package myPack;
public class enemyBullet extends GameMovableElementAdapter
{
	
	public enemyBullet(int x , int y)
	{
		super("Images/mine.png" , x , y);
		
		this.setDownDirection();
		this.setSpeedX(0);
		this.setSpeedY(4);
		this.StartMoving();
	}
	
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if(!(element instanceof Sky) && !(element instanceof Enemy_AirCraft) && (element instanceof enemyBullet))
			this.Destroy();
	}
}
