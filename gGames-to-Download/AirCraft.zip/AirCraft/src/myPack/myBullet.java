package myPack;
public class myBullet extends GameMovableElementAdapter
{
	
	public myBullet(int x , int y)
	{
		super("Images/MyBullet.png" , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(12);
		this.StartMoving();
		this.setUpDirection();
		
	}
	
	
	protected void CollideUpBorder()
	{
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if(!(element instanceof Sky) && (element instanceof myBullet))
			this.Destroy();
		else if(element instanceof Enemy_AirCraft)
			this.Destroy();
	}
	
}
