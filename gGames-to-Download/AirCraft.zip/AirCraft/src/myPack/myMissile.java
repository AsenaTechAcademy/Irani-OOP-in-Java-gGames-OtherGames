package myPack;


public class myMissile extends GameMovableElementAdapter
{
	//private Point p0;// the Point of the place where the Missile has been shot
	
	public myMissile(int x, int y) 
	{
		super("Images/bomb.png", x, y);
				
		this.setSpeedX(0);        
		this.setSpeedY(7);
		this.StartMoving();
		this.setUpDirection();
	}//end myMissile constructor
		
	
	
	protected void CollideUpBorder()
	{
		this.Destroy();
	}
	public void CollideWith(GameElementAdapter element) 
	{
		if(element instanceof Enemy_AirCraft)
		{
			this.ChangeImage("Images/fire.png");
			this.StopMoving();
			try
			{
				Thread.sleep(10);
			}
			catch(Exception e){}
			//this.Destroy();
		}
		if(!(element instanceof AirCraft) && !(element instanceof enemyBullet) && !(element instanceof Sky))
			Destroy();
	}

	
}
