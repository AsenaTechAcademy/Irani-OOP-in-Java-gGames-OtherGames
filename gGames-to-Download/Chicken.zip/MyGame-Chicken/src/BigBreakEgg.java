
public class BigBreakEgg extends BreakEggAdapter
{
	
	public BigBreakEgg(int x , int y)
	{
		super("Images/BigBreakEgg.gif" , x , y);
		
	}
	}
