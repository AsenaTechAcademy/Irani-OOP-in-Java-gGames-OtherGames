public class BigBullet extends BulletAdapter
{
	
	public BigBullet(int x , int y)
	{
		super("Images/BigBullet.gif" , x , y);
		
		
	}
	
}
