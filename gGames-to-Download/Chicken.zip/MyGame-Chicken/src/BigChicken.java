
public class BigChicken extends GameMovableElementAdapter 
{
	private static String	Images[]	= { "Images/BigChicken1.gif", "Images/BigChicken2.gif","Images/BigChicken3.gif","Images/BigChicken4.gif",
		"Images/BigChicken5.gif","Images/BigChicken6.gif","Images/BigChicken7.gif","Images/BigChicken8.gif","Images/BigChicken9.gif",
		"Images/BigChicken10.gif","Images/BigChicken11.gif","Images/BigChicken12.gif","Images/BigChicken13.gif","Images/BigChicken14.gif",
		"Images/BigChicken15.gif","Images/BigChicken16.gif","Images/BigChicken17.gif","Images/BigChicken18.gif","Images/BigChicken19.gif",
		"Images/BigChicken20.gif","Images/BigChicken21.gif","Images/BigChicken22.gif","Images/BigChicken23.gif","Images/BigChicken24.gif",
		"Images/BigChicken25.gif","Images/BigChicken26.gif","Images/BigChicken27.gif","Images/BigChicken28.gif","Images/BigChicken29.gif",
		"Images/BigChicken30.gif","Images/BigChicken31.gif","Images/BigChicken32.gif" };

	
private int				cImage		=0;
private long			waitTime	=70;//sorat change shodan
private long			lastTime	=0;
private long			lastTime1	=0;


private int		dx;			// speed of Movement
private int		x0 , y0;		// first x,y , set if direction change
private double	tana;			// tan(Degree) , no need but its better
private int CBullet=0;
public BigChicken(int x , int y)
{
	super(Images[0] , x , y);//avalin bar image 0 load mishe
	destroyedScore=100;//100 emtiz az beyn raftan
	setSpeedY(0);
	setSpeedX(10);
	setRightDirection();
	StartMoving();
	
	
}
private void nextImage()//avaz kardane aks
{
	cImage=(cImage+1)%32;
	ChangeImage("Images/BigChicken"+(cImage+1)+".gif");
}


public void Step()
{
	
	super.Step();
	if (lastTime+waitTime<System.currentTimeMillis())//zaman avaz kardan aks
	{
		this.nextImage();//tu in kelas ma faghat aks avaz mikonim payin umadane bad chon moving has kelas pedar anjam mide
		lastTime=System.currentTimeMillis();
	calcNextPoint();
	}
	if (lastTime1+3000<System.currentTimeMillis())
	{
		Fire();
		lastTime1=System.currentTimeMillis();
		}

}
private void Fire()
{
			// Create new Bullet and shoot up from Right and Left
	BigEgg b=new BigEgg(0 , 0);
			{			
			if (getY()>600-this.getHeight()-120)
			{
                 //b.StopMoving();
	  			}
			else if ((getY()<600-this.getHeight()))
			{
			     b.setXY(this.getX()+this.getWidth()/2 , this.getY()+this.getHeight()-1);
  			     GGame.addNewEntity(b);
  			   SoundStore.get().Play(Sounds.Egg);
			}
	   		}
}
private void calcNextPoint()
{
	int x2=getX()+dx;
	int y2=(int) (tana*x2+(y0-tana*x0));
	setXY(x2 , y2);
}


public void CollideWith(GameElementAdapter element)
{
	
	if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
	{
		
		this.Destroy();
		return;
	}
	if (element instanceof BigBullet||element instanceof Bullet)
	{
		this.CBullet++;
		
		
	}
	if(this.CBullet==10)
	{
		
		
		this.Destroy();
		SoundStore.get().Play(Sounds.destroyChicken);
		
		GGame.addNewEntity(new Par(getX() ,getY()));
		GGame.addNewEntity(new Par(getX() ,getY()));
		GGame.addNewEntity(new Par(getX() ,getY()));
		GGame.addNewEntity(new Par(getX() ,getY()));
		
		
		GGame.addNewEntity(new Chick(getX()-160 ,getY()+160));
		GGame.addNewEntity(new Chick(getX()+10 ,getY()+160));
		GGame.addNewEntity(new Chick(getX()+160 ,getY()+160));
		
		
		return;
	}
	// to collide with other elements
	//element.Destroy();
}


	protected void CollideRightBorder()
	{
		
		setLeftDirection();
	
	}
	protected void CollideLeftBorder()
	{
		
		setRightDirection();
		
	}
	
}
