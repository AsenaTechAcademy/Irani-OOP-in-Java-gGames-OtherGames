
public class BigEgg extends EggAdapter
{
	public BigEgg(int x , int y)
	{
		super("Images/BigEgg.gif" , x , y);
		
		
	}
	
}
