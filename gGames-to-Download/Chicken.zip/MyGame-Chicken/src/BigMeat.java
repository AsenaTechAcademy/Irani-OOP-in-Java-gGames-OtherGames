


public class BigMeat extends MeatAdapter
{
	
	public BigMeat(int x , int y)
	{
		super("Images/BigMeat.gif" , x , y);

	}

}
