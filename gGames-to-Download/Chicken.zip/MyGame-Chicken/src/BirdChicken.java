
public class BirdChicken extends GameMovableElementAdapter  
{
	

public BirdChicken(String Name, int x , int y)
{
	super(Name , x , y);

	
	setSpeedY(1);
	setSpeedX(0);
	setDownDirection();
	StartMoving();
}



public void CollideWith(GameElementAdapter element)
{
	
	if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
	{
		
		this.Destroy();
		return;
	}
	
	// to collide with other elements
	//element.Destroy();
}

protected void CollideDownBorder()//vaghti b entehaye safhe resid az beyn bere
{
	super.CollideDownBorder();
	this.Destroy();
	//GGame.DecreaseLive();
}
	
}
