
public class BirdChicken1 extends BirdChicken
{
	

public BirdChicken1(int x , int y)
{
	super("Images/birdChicken.gif" , x , y);

}



public void CollideWith(GameElementAdapter element)
{
	

	if (element instanceof Bullet || element instanceof BigBullet)
	{
		this.Destroy();
		GGame.addNewEntity(new Chicken(getX()+10 ,getY()+10));
		SoundStore.get().Play(Sounds.destroyChicken);
		return;
	}
	// to collide with other elements
	//element.Destroy();
}

	
}
