
public class BirdChicken2 extends BirdChicken
{
	


public BirdChicken2(int x , int y)
{
	super("Images/BirdChicken2.gif" , x , y);

}



public void CollideWith(GameElementAdapter element)
{
	
	
	if (element instanceof Bullet || element instanceof BigBullet)
	{
		this.Destroy();
		GGame.addNewEntity(new RedChicken(getX()+10 ,getY()+10));
		SoundStore.get().Play(Sounds.destroyChicken);
		return;
	}
	// to collide with other elements
	//element.Destroy();
}


	
}
