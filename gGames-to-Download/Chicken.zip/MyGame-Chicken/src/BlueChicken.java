
public class BlueChicken extends ChickenAdapter
{
	private static String	Images[]	= { "Images/BlueChicken1.gif", "Images/BlueChicken2.gif","Images/BlueChicken3.gif" };

private long			lastTime1	=0;



public BlueChicken(int x , int y)
{
	super(Images[0] , x , y,"BlueChicken");//avalin bar image 0 load mishe

}


public void Step()
{
	
	super.Step();

	if (lastTime1+3000<System.currentTimeMillis())
	{
		Fire();
		lastTime1=System.currentTimeMillis();
		}

}
private void Fire()
{
			// Create new Bullet and shoot up from Right and Left
	Egg b=new Egg(0 , 0);
			{			
			if (getY()>600-this.getHeight()-120)
			{
                 //b.StopMoving();
	  			}
			else if ((getY()<600-this.getHeight()))
			{
			     b.setXY(this.getX()+this.getWidth()/2 , this.getY()+this.getHeight()-1);
  			     GGame.addNewEntity(b);
  			   SoundStore.get().Play(Sounds.Egg);
			}
	   		}
}

public void CollideWith(GameElementAdapter element)
{
	
	if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
	{
		
		this.Destroy();
		return;
	}
	if (element instanceof Bullet || element instanceof BigBullet)
	{
		this.Destroy();
		GGame.addNewEntity(new Explode(getX()+10 ,getY()+10));
		SoundStore.get().Play(Sounds.destroyChicken);
		GGame.addNewEntity(new Meat(getX() ,getY()));//morghe abi faghat ghusht mide
		return;
	}
	// to collide with other elements
	//element.Destroy();
}


}
