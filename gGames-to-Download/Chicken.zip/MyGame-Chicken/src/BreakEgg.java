
public class BreakEgg extends BreakEggAdapter
{
	
	public BreakEgg(int x , int y)
	{
		super("Images/BreakEgg.gif" , x , y);
		
		
	}
	
}
