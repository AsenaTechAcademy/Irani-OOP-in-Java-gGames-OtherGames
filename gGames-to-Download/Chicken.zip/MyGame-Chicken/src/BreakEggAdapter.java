
public class BreakEggAdapter extends GameMovableElementAdapter
{
	private long			lastTime1	=0;
	public BreakEggAdapter(String Name,int x , int y)
	{
		super(Name , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(0);
		this.setDownDirection();
		//this.StartMoving();
	}
	public void Step()
	{
		
		super.Step();
		

		if (lastTime1+3000<System.currentTimeMillis())
		{
			this.Destroy();
			lastTime1=System.currentTimeMillis();
			}
		
	}
}
