public class Bullet extends BulletAdapter
{
	
	public Bullet(int x , int y)
	{
		super("Images/Bullet.gif" , x , y);
		
	}
	
	
}
