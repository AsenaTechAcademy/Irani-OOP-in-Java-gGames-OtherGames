public class BulletAdapter extends GameMovableElementAdapter
{
	
	public BulletAdapter(String Name, int x , int y)
	{
		super(Name, x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(15);
		this.setUpDirection();
		this.StartMoving();
	}
	
	protected void CollideUpBorder()
	{
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if(element instanceof Chicken||element instanceof BirdChicken||element instanceof ChickenAdapter||element instanceof BigChicken||element instanceof Chick)
		{
			
			this.Destroy();
			return;
		}
		// to collide with other elements
				//element.Destroy();
	}
	
}
