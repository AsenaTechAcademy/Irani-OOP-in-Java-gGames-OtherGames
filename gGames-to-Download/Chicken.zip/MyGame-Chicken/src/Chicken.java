
public class Chicken extends GameMovableElementAdapter 
{
	private static String	Images[]	= { "Images/BlueChicken1.gif", "Images/BlueChicken2.gif","Images/BlueChicken3.gif" };//aksayi k gharare change beshan
private int				cImage		=0;
private long			waitTime	=70;//sorat change shodan
private long			lastTime	=0;
private long			lastTime1	=0;

private int		movingDegree;	// Degree of Movement
private int		dx;			// speed of Movement
private int		x0 , y0;		// first x,y , set if direction change
private double	tana;			// tan(Degree) , no need but its better

public Chicken(int x , int y)
{
	super(Images[0] , x , y);//avalin bar image 0 load mishe
	destroyedScore=100;//100 emtiz az beyn raftan
	
	setmovingDegree(225);
	AfterCollision(); // set x0,y0,tan
	
}
private void nextImage()//avaz kardane aks
{
	cImage=(cImage+1)%3;
	ChangeImage("Images/BlueChicken"+(cImage+1)+".gif");
}

public void Reset()
{
	// set to first status
	this.setXY(365 , 540);
	setmovingDegree(225);
	AfterCollision();
}
public void Step()
{
	
	super.Step();
	if (lastTime+waitTime<System.currentTimeMillis())
	{
		this.nextImage();
		lastTime=System.currentTimeMillis();
		}
	calcNextPoint();

	if (lastTime1+3000<System.currentTimeMillis())
	{
		Fire();
		lastTime1=System.currentTimeMillis();
		}

}
private void Fire()
{
			// Create new Bullet and shoot up from Right and Left
	Egg b=new Egg(0 , 0);
			{			
			if (getY()>600-this.getHeight()-120)
			{
                 //b.StopMoving();
	  			}
			else if ((getY()<600-this.getHeight()))
			{
			     b.setXY(this.getX()+this.getWidth()/2 , this.getY()+this.getHeight()-1);
  			     GGame.addNewEntity(b);
  			   SoundStore.get().Play(Sounds.Egg);
			}
	   		}
}
private void calcNextPoint()
{
	int x2=getX()+dx;
	int y2=(int) (tana*x2+(y0-tana*x0));
	setXY(x2 , y2);
}


public void CollideWith(GameElementAdapter element)
{
	
	if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
	{
		
		this.Destroy();
		return;
	}
	if (element instanceof Bullet || element instanceof BigBullet)
	{
		this.Destroy();
		GGame.addNewEntity(new Explode(getX()+10 ,getY()+10));
		SoundStore.get().Play(Sounds.destroyChicken);
		GGame.addNewEntity(new Meat(getX() ,getY()));
		return;
	}
	// to collide with other elements
	//element.Destroy();
}

private void setmovingDegree(int degree)
{
	//SoundStore.get().Play(Sounds.Ball);
	
	movingDegree=(degree+(int) (6*Math.random()-3))%360;
	// Optimize dx
	if (movingDegree<0)
		movingDegree=355;
	
	if (movingDegree>=178&&movingDegree<=180)
		movingDegree=175;
	else if (movingDegree>=180&&movingDegree<=183)
		movingDegree=185;
	else if (movingDegree<=3&&movingDegree>=0)
		movingDegree=5;
	else if (movingDegree>=357&&movingDegree<=0)
		movingDegree=355;
	else if (movingDegree>=75&&movingDegree<=90)
		movingDegree=75;
	else if (movingDegree>=90&&movingDegree<=105)
		movingDegree=105;
	else if (movingDegree>=255&&movingDegree<=270)
		movingDegree=255;
	else if (movingDegree>=270&&movingDegree<=285)
		movingDegree=285;
	
	// calc dx based on Degree
	if (movingDegree>=0&&movingDegree<=90)
		dx=(int) (-0.06818182*movingDegree+8.06);
	else if (movingDegree>=90&&movingDegree<=180)
		dx=(int) (0.07142857*movingDegree-4.78571429);
	else if (movingDegree>=180&&movingDegree<=270)
		dx=(int) (-0.06818182*movingDegree+20.34090909);
	else if (movingDegree>=270&&movingDegree<=360)
		dx=(int) (0.06818182*movingDegree-16.47727273);
	
	// calc Direction
	if ((movingDegree>0&&movingDegree<90)||(movingDegree>270&&movingDegree<360))
		dx=Math.abs(dx);
	if ((movingDegree>90&&movingDegree<270))
		dx=-1*Math.abs(dx);
}
private void AfterCollision()
{
	x0=getX();
	y0=getY();
	tana=Math.tan(Math.toRadians(movingDegree));
}

protected void CollideDownBorder()//vaghti b entehaye safhe resid az beyn bere
{
	super.CollideDownBorder();
	setmovingDegree(360-movingDegree);
	AfterCollision();
}
	protected void CollideUpBorder()
	{
		setmovingDegree(360-movingDegree);
		AfterCollision();
	}
	protected void CollideRightBorder()
	{
		if (movingDegree<90)
			setmovingDegree(180-movingDegree);
		else if (movingDegree>180)
			setmovingDegree(360+180-movingDegree);
		AfterCollision();
	}
	protected void CollideLeftBorder()
	{
		if (movingDegree>90&&movingDegree<180)
			setmovingDegree(180-movingDegree);
		else if (movingDegree>180&&movingDegree<270)
			setmovingDegree(360+180-movingDegree);
		AfterCollision();
	}
	
}
