
public class ChickenAdapter extends GameMovableElementAdapter 
{

	private int				cImage		=0;
	private long			waitTime	=70;//sorat change shodan
	private long			lastTime	=0;
	private String        ChickenName;
	public ChickenAdapter(String ref, int x, int y,String chickenName) 
	{
		super(ref, x, y);
		
		this.ChickenName=chickenName;
		destroyedScore=100;//100 emtiz az beyn raftan
		
		setSpeedY(1);
		setSpeedX(0);
		setDownDirection();
		StartMoving();
	}
	private void nextImage()//avaz kardane aks
	{
		
		cImage=(cImage+1)%3;
		ChangeImage("Images/"+ChickenName+(cImage+1)+".gif");
	}
	
	public void Step()
	{
		
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())//zaman avaz kardan aks
		{
			this.nextImage();//tu in kelas ma faghat aks avaz mikonim payin umadane bad chon moving has kelas pedar anjam mide
			lastTime=System.currentTimeMillis();
		}
		
	}

	protected void CollideDownBorder()//vaghti b entehaye safhe resid az beyn bere
	{
		super.CollideDownBorder();
		if(Levels.NumberOflevel()==2)
		{
			 setUpDirection();
		}
		else
		{
		    this.Destroy();
		    //GGame.DecreaseLive();
		}
		//this.Destroy();
		//GGame.DecreaseLive();
	}
	protected void CollideUpBorder()//vaghti b entehaye safhe resid az beyn bere
	{
		super.CollideDownBorder();
		if(Levels.NumberOflevel()==2)
		{
			setDownDirection();
		}
		
		//this.Destroy();
		//GGame.DecreaseLive();
	}	
		
}
