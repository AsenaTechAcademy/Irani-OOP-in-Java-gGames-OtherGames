
public class ChickenLogo extends GameMovableElementAdapter
{
	private LevelStatus Levelstatus;
	public ChickenLogo ( int x, int y,LevelStatus Levelstatus)
	{
		super("Images/Chicken_Invaders_3_Logo.png", x, y);
		if(Levelstatus!=LevelStatus.LevelNotStarted)
			this.Destroy();
	}
	public void destoryLogo()
	{
		if(Levelstatus!=LevelStatus.LevelNotStarted)
			this.Destroy();
	}
}
