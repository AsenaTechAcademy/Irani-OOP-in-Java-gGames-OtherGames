import java.util.Random;


public class Coin extends GameMovableElementAdapter
{
	private int	X0 , Y0;
	private int	direction;
	private int	state		=0;	// SAHMI mode
	public Coin(int x , int y)
	{
		super("Images/coin.gif" , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(8);
		this.setDownDirection();
		this.StartMoving();
		
		X0=getX();
		Y0=getY();
	}
	private int F(int x)
	{
		return (int) (.01*(x-X0)*(x-X0)+Y0);//moadeleye harekate seke
	}
	protected void goNextPoint()
	{
		super.goNextPoint();
		if (state==0)
		{
			// a SAHMI
			direction=this.getRandom();
			//setXY(getX()+direction , F(getX()));
			state=1;
			
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		setXY(getX()+direction , F(getX()));
		
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
		 	return;	 	
	}
	public void CollideWith(GameElementAdapter element)
	{
		
		if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
		{
			
			this.Destroy();
			return;
		}
	}
	public int getRandom()
	{
		int random=0;
		int a=20;
		Random randomnumber=new Random();
		random=randomnumber.nextInt(a);
		
		int a1=7,b1=3,c1;
		c1=b1+randomnumber.nextInt(a1);
			
		if(random<=10)
		{
		return c1;
		}
		else
		{
			 
				return (-1)*c1;
		}
		
	}
}
