
public class Egg extends EggAdapter
{
	public Egg(int x , int y)
	{
		super("Images/Egg.gif" , x , y);
		
	}
	
}
