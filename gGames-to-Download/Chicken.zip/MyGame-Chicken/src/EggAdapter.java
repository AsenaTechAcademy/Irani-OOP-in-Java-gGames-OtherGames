
public class EggAdapter extends GameMovableElementAdapter
{
	public EggAdapter(String Name,int x , int y)
	{
		super(Name , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(5);
		this.setDownDirection();
		this.StartMoving();
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
		 	
		 	GGame.addNewEntity(new BreakEgg(getX()-10 ,getY()-10));
		 	SoundStore.get().Play(Sounds.BreakEgg);
		 	return;	 	
	}
	public void CollideWith(GameElementAdapter element)
	{
		
		if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
		{
			
			this.Destroy();
			return;
		}
	}
}
