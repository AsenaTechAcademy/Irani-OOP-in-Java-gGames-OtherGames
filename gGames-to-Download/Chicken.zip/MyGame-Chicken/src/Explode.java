
public class Explode extends GameMovableElementAdapter
{
	private long			lastTime	=0;
	public Explode ( int x, int y)
	{
		super("Images/explode.gif", x, y);
		
	}
	public void Step()
	{
		
		super.Step();
		

		if (lastTime+3000<System.currentTimeMillis())
		{
			this.Destroy();
			lastTime=System.currentTimeMillis();
			}

	}
}
