public class GBackground extends GameElementAdapter
{
	public GBackground(int x , int y , int type)
	{
		super("Images/BG"+type+"-800-600.jpg" , x , y);
	}
	
}
