public class GameConstants//andazeye frame game
{
	public final static int	Game_Width	=800;
	public final static int	Game_Height	=600;
}
