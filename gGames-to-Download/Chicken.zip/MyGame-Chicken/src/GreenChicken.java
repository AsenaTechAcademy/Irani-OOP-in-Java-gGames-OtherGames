
public class GreenChicken extends ChickenAdapter
{
	private static String	Images[]	= { "Images/GreenChicken1.gif", "Images/GreenChicken2.gif","Images/GreenChicken3.gif" };//aksayi k gharare change beshan



public GreenChicken(int x , int y)
{
	super(Images[0] , x , y,"GreenChicken");//avalin bar image 0 load mishe
	
}



public void CollideWith(GameElementAdapter element)
{
	
	if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
	{
		
		this.Destroy();
		return;
	}
	if (element instanceof Bullet || element instanceof BigBullet)//morghe red 3ghusht+1 seke
	{
		this.Destroy();
		GGame.addNewEntity(new Explode(getX()+10 ,getY()+10));
		SoundStore.get().Play(Sounds.destroyChicken);
		GGame.addNewEntity(new Prize(getX()+10 ,getY()+10));
	
		return;
	}
	// to collide with other elements
	//element.Destroy();
}


	
}
