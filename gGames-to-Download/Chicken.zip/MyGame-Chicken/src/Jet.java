import java.awt.event.KeyEvent;


public class Jet extends GameMovableElementAdapter
{
	private int CFire=1;
	private int level;
	public Jet( int x, int y,int level)
	{
		super("Images/jet.gif", x, y);
		this.level=level;
		setSpeedX(15);//sorateshe rastaye x
		setSpeedY(0);
		destroyedScore=1;
	}
	public void Reset()
	{
		this.setXY(300 , 560); // set to first status
	}
	// need to get Key Events
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_LEFT||e.getKeyCode()==KeyEvent.VK_RIGHT)
			StopMoving();
	}
	
	public void KeyPressed(KeyEvent e)
	{
		
		if (e.getKeyCode()==KeyEvent.VK_SPACE)
			Fire();
		
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			StartMoving();
			setRightDirection();
		}
		/*if (e.getKeyCode()==KeyEvent.VK_UP)
		{
			StartMoving();
			setUpDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			StartMoving();
			setDownDirection();
		}*/
	}
	
	private void Fire()
	{
		//if (GGame.getTotalFires()>0)//age tir hamun bozorgtar az 0
		{
			// Create new Bullet and shoot up from Right and Left
			
			if(this.CFire==2)///for level 3
			{
				Bullet b1=new Bullet(0 , 0);
				b1.setXY(this.getX()+this.getWidth()-50 , this.getY()-b1.getHeight());
				  GGame.addNewEntity(b1);
				  
				  Bullet b2=new Bullet(0 , 0);
					b2.setXY(this.getX()+this.getWidth()-10 , this.getY()-b2.getHeight());
					  GGame.addNewEntity(b2);
			}
			else
			{
				  if(this.level==5)
				  {
					  BigBullet b1=new BigBullet(0 , 0);
					    b1.setXY(this.getX()+this.getWidth()-30 , this.getY()-b1.getHeight());
				        GGame.addNewEntity(b1);
				  }
				  else
				  {
				Bullet b1=new Bullet(0 , 0);
				    b1.setXY(this.getX()+this.getWidth()-30 , this.getY()-b1.getHeight());
			        GGame.addNewEntity(b1);
				  }
			}
		
			SoundStore.get().Play(Sounds.Fire);
		}
	}
	 public void CollideWith(GameElementAdapter element)
		{
	    	
	    	if(element instanceof Egg||element instanceof Chicken||element instanceof BirdChicken||element instanceof BlueChicken||element instanceof RedChicken||
	    			element instanceof YellowChicken||element instanceof GreenChicken||element instanceof VioletChicken||element instanceof BigChicken
	    			||element instanceof BigEgg||element instanceof BirdChicken||element instanceof BirdChicken2||element instanceof Chick)
	    	{
	    		this.Reset();
	    		GGame.DecreaseLive();
	    		SoundStore.get().Play(Sounds.destroyJet);
	    	}
	    	if (element instanceof Meat||element instanceof BigMeat)
			{
				GGame.IncreaseScore(1);
				SoundStore.get().Play(Sounds.Meat);
				return;
			}
	    	if (element instanceof Coin)
			{
				GGame.IncreaseScore(30);
				SoundStore.get().Play(Sounds.Score);
				return;
			}
	    	if (element instanceof Prize)
			{
				
				SoundStore.get().Play(Sounds.Prize);
				this.CFire=2;
				return;
			}
		}
}
