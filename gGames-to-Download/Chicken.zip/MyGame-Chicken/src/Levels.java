public abstract class Levels
{
	public static final int	FinalLevel	=5;
	private static int NumberLevel=1;
	public static void SetLevel(GGame game , int level)
	{
		NumberLevel=level;
		if (level==1)
		{
			// configs of Level 1
			PlayerInfo p=new PlayerInfo();
			p.setLives(5);
			//p.setFires(0);
			p.setScore(0);
			p.setPlayerName("Sepideh Entezari");
			p.setCurrentLevel(1);
			
			game.setPlayerInfo(p);
			LoadMap(game , 4);/////////////////
		}
		
		else if (level<=FinalLevel)
		{
			PlayerInfo p=game.getPlayerInfo();
			p.setCurrentLevel(p.getCurrentLevel()+1);
			game.setPlayerInfo(p);
			LoadMap(game , level);
		}
		
	}
	
	private static void LoadMap(GGame game , int level)
	{
		if (level==1)
			LoadMap1(game);
		if (level==2)
			LoadMap2(game);
		if (level==3)
			LoadMap3(game);
		if (level==4)
			LoadMap4(game);
		if (level==5)
			LoadMap5(game);
		
	}
	
	private static void LoadMap1(GGame game)
	{
		game.clearEntities();
		// Static parts
		game.setNextEntity(new GBackground(0 , 0 , 3));
		game.setNextEntity(new Jet(370 , 510,1));
		game.setNextEntity(new Chicken(300 ,0));
	
		
		// Other Elements (from MAP)
		
		
	}
	
	private static void LoadMap2(GGame game)
	{
		game.clearEntities();
		// Static parts
		game.setNextEntity(new GBackground(0 , 0 , 4));
		game.setNextEntity(new Jet(370 , 510,2));//60
		
		
		
		game.setNextEntity(new BlueChicken(100,0));
		game.setNextEntity(new VioletChicken(160,0));
		game.setNextEntity(new BlueChicken(220 ,0));
		game.setNextEntity(new VioletChicken(100,60));
		game.setNextEntity(new BlueChicken(160 ,60));
		game.setNextEntity(new RedChicken(220 ,60));
		game.setNextEntity(new BlueChicken(100,120));
		game.setNextEntity(new RedChicken(160 ,120));
		game.setNextEntity(new BlueChicken(220 ,120));
		
		game.setNextEntity(new VioletChicken(500,0));
		game.setNextEntity(new BlueChicken(560,0));
		game.setNextEntity(new  VioletChicken(620 ,0));
		game.setNextEntity(new BlueChicken(500,60));
		game.setNextEntity(new RedChicken(560,60));
		game.setNextEntity(new  RedChicken(620 ,60));
		game.setNextEntity(new VioletChicken(500,120));
		game.setNextEntity(new RedChicken(560,120));
		game.setNextEntity(new  BlueChicken(620 ,120));
		// Other Elements (from MAP)
		
		
	}
	
	
	private static void LoadMap3(GGame game)
	{
		game.clearEntities();
		// Static parts
		game.setNextEntity(new GBackground(0 , 0 , 3));
		game.setNextEntity(new Jet(370 , 510,3));
		// Other Elements (from MAP)
		
		game.setNextEntity(new BlueChicken(100 ,0));//+120
		game.setNextEntity(new RedChicken(220 ,0));
		game.setNextEntity(new BlueChicken(340 ,0));
		game.setNextEntity(new BlueChicken(460 ,0));
		game.setNextEntity(new VioletChicken(580,0));
		game.setNextEntity(new YellowChicken(700,0));
		
		game.setNextEntity(new YellowChicken(160,60));
		game.setNextEntity(new RedChicken(280 ,60));
		game.setNextEntity(new YellowChicken(400,60));
		game.setNextEntity(new GreenChicken(520,60));
		game.setNextEntity(new BlueChicken(640 ,60));
		
		game.setNextEntity(new VioletChicken(100 ,120));//+120
		game.setNextEntity(new BlueChicken(220 ,120));
		game.setNextEntity(new RedChicken(340 ,120));
		game.setNextEntity(new BlueChicken(460 ,120));
		game.setNextEntity(new VioletChicken(580,120));
		game.setNextEntity(new RedChicken(700,120));
		
	}
	
	
	private static void LoadMap4(GGame game)
	{
		game.clearEntities();
		// Static elements
		game.setNextEntity(new GBackground(0 , 0 , 4));
		game.setNextEntity(new Jet(370 , 510,4));
		
		// Other Elements (from MAP)
		game.setNextEntity(new BirdChicken1(300,0));
		game.setNextEntity(new BirdChicken1(500,0));
		game.setNextEntity(new BirdChicken1(700,0));
		game.setNextEntity(new BirdChicken1(100,120));
		game.setNextEntity(new BirdChicken1(600,120));
		game.setNextEntity(new BirdChicken1(300,240));
		game.setNextEntity(new BirdChicken1(500,240));
		game.setNextEntity(new BirdChicken1(700,240));
		
		game.setNextEntity(new BirdChicken2(100,0));
		game.setNextEntity(new BirdChicken2(300,120));
		game.setNextEntity(new BirdChicken2(100,240));
	}
	private static void LoadMap5(GGame game)
	{
		game.clearEntities();
		// Static parts
		game.setNextEntity(new GBackground(0 , 0 , 1));
		game.setNextEntity(new Jet(370 , 510,5));
		
		// Other Elements (from MAP)
		game.setNextEntity(new BigChicken(0,0));
		
	}
	public static int NumberOflevel()
	{
		return NumberLevel;
	}
}
