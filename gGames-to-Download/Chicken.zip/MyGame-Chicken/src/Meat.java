


public class Meat extends MeatAdapter
{
	
	public Meat(int x , int y)
	{
		super("Images/Meat.gif" , x , y);
		
	}
	
	
}
