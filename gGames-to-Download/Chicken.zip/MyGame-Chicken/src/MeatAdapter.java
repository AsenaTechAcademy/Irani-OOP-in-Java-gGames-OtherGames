import java.util.Random;


public class MeatAdapter extends GameMovableElementAdapter
{

	private int	X0 , Y0;
	private int	direction;
	private int	state		=0;	// SAHMI mode
	public MeatAdapter(String Name, int x , int y)
	{
		super(Name , x , y);
		this.setSpeedX(0);
		this.setSpeedY(9);//faghat baraye vaghti k amudi beshe
		this.setDownDirection();
		this.StartMoving();
		
		X0=getX();
		Y0=getY();
		//direction=1;// go Right
		
	}
	
	private int F(int x)
	{
		return (int) (.01*(x-X0)*(x-X0)+Y0);//moadeleye harekate seke
	}
	
	protected void goNextPoint()
	{
		super.goNextPoint();
		if (state==0)
		{
			// a SAHMI
			direction=this.getRandom();
			//setXY(getX()+direction , F(getX()));
			state=1;
		}
		setXY(getX()+direction , F(getX()));
		
	}

	
	protected void CollideDownBorder()
	{
		this.Destroy();	
	}
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof Jet)
		{
		
			this.Destroy();	
			return;
		}
		
	}
	public int getRandom()
	{
		int random=0;
		int a=20;
		Random randomnumber=new Random();
		random=randomnumber.nextInt(a);
		
		   int a1=7,b1=3,c1;//baraye kamtar az 3 meat harakat nakard//15_5
		c1=b1+randomnumber.nextInt(a1);
			
		if(random<=10)
		{
		return c1;
		}
		else
		{
			 
				return (-1)*c1;
		}
		
	}
}
