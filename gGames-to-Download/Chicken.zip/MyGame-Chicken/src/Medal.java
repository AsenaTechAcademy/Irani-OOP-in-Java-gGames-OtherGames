
public class Medal extends GameMovableElementAdapter
{
	public Medal ( int x, int y,LevelStatus Levelstatus)
	{
		super("Images/Medal.gif", x, y);
		if(Levelstatus!=LevelStatus.LevelWined)
			this.Destroy();
	}
}
