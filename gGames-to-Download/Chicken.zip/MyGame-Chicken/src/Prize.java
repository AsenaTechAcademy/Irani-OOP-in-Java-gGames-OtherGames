
public class Prize extends GameMovableElementAdapter
{
	public Prize(int x , int y)
	{
		super("Images/prize.gif" , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(5);
		this.setDownDirection();
		this.StartMoving();
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
		 	return;	 	
	}
	public void CollideWith(GameElementAdapter element)
	{
		
		if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
		{
			
			this.Destroy();
			return;
		}
	}
}
