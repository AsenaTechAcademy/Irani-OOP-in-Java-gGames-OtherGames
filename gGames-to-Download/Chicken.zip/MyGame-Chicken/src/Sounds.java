public class Sounds
{
	public final static String	BeginJet            = "Sounds/beginJet.wav";
	public final static String	BreakEgg          = "Sounds/BreakEgg.wav";
	public final static String	destroyChicken	="Sounds/destroyChicken.wav";
	public final static String	destroyJet  	    = "Sounds/destroyJet.wav";
	public final static String	Egg                  =  "Sounds/Egg.wav";
	public final static String	FinishGame	    = "Sounds/finishGame.wav";
	public final static String	Fire	                =  "Sounds/Fire.wav";
	public final static String	GameOver	         ="Sounds/GameOver.wav";
	public final static String	Meat                 = "Sounds/Meat.wav";
	public final static String	Prize	                = "Sounds/Prize.wav";
	public final static String	Score	            = "Sounds/Score.wav";
	
}
