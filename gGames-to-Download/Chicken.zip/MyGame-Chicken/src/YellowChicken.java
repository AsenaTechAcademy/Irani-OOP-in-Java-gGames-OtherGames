
public class YellowChicken extends ChickenAdapter  
{
	private static String	Images[]	= { "Images/YellowChicken1.gif", "Images/YellowChicken2.gif","Images/YellowChicken3.gif" };//aksayi k gharare change beshan


public YellowChicken(int x , int y)
{
	super(Images[0] , x , y,"YellowChicken");//avalin bar image 0 load mishe
	
}




public void CollideWith(GameElementAdapter element)
{
	
	if (element instanceof Jet)//age be bar bokhore az jun kam mishe khodesham az beyn mire
	{
		
		this.Destroy();
		return;
	}
	if (element instanceof Bullet || element instanceof BigBullet)//morghe red 3ghusht+1 seke
	{
		this.Destroy();
		GGame.addNewEntity(new Explode(getX()+10 ,getY()+10));
		SoundStore.get().Play(Sounds.destroyChicken);
		GGame.addNewEntity(new Coin(getX() ,getY()));
		GGame.addNewEntity(new Coin(getX() ,getY()));
		GGame.addNewEntity(new Coin(getX() ,getY()));
		return;
	}
	// to collide with other elements
	//element.Destroy();
}


	
}
