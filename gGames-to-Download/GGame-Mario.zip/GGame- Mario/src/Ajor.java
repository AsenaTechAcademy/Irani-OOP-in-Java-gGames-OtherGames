import java.awt.event.*;

public class Ajor extends GameMovableElementAdapter {

	public Ajor(int x, int y, String S) {
		super(S, x, y);
		this.destroyedScore = this.getWidth() * this.getHeight() / 400;
	}

	@Override
	public void KeyPressed(KeyEvent e) {

		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(1);
			setLeftDirection();
			StartMoving();

		}

		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			setSpeedX(1);
			setRightDirection();
			StartMoving();

		}

	}

	@Override
	public void KeyReleased(KeyEvent e) {

		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			StopMoving();

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			StopMoving();

		}
	}

	@Override
	public boolean WantKeyEvents() {
		return true;
	}

	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.Destroy();
	}

	public void CollideWith(GameElementAdapter him) {
		if ((him instanceof Player) || (him instanceof Bullet)) {
			this.Destroy();
			SoundStore.get().Play(Sounds.Brick);
			return;
		}
	}

}
