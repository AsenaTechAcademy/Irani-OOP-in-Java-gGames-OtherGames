public class Bullet extends GameMovableElementAdapter {

	public Bullet(int x, int y, int r, int Y) {
		super("Images/bullet.gif", x, y);
		if (r == 1) {
			this.setSpeedX(3);
			this.setSpeedY(Y);
			this.setUpDirection();
			this.StartMoving();
		} else if (r == -1) {
			this.setSpeedX(-3);
			this.setSpeedY(0);
			this.setUpDirection();
			this.StartMoving();
		} else if (r == 0) {
			this.setSpeedX(0);
			this.setSpeedY(Y);
			this.setDownDirection();
			this.StartMoving();
		}

	}

	public void CollideWith(GameElementAdapter element) {
		if (element instanceof Player) {
			return;
		}

		else if (element instanceof Enemy) {
			this.Destroy();
			return;
		} else if (element instanceof Ajor) {
			this.Destroy();
			return;
		} else if (element instanceof Planet) {
			this.Destroy();
			return;
		} else if (element instanceof SekkeBrick10) {
			this.Destroy();
			return;
		} else if (element instanceof GHeart) {
			this.Destroy();
			return;
		}
	}

	@Override
	protected void CollideRightBorder() {
		super.CollideRightBorder();
		this.Destroy();
	}

	@Override
	protected void CollideUpBorder() {

		super.CollideUpBorder();
		this.Destroy();
	}

	@Override
	protected void CollideLeftBorder() {

		super.CollideLeftBorder();
		this.Destroy();
	}

}
