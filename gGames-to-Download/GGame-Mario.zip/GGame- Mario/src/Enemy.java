import java.awt.event.KeyEvent;

public class Enemy extends GameMovableElementAdapter {

	public Enemy(int x, int y, String S, int X) {
		super(S, x, y);
		destroyedScore = 100;

		setSpeedY(0);
		setSpeedX(X);
		setDownDirection();
		StartMoving();

	}

	@Override
	public void Step() {
		super.Step();
	}

	public void CollideWith(GameElementAdapter element) {

		if (element instanceof Player) {
			GGame.DecreaseLive();
			this.Destroy();
			return;
		}
		if (element instanceof Bullet) {
			// GGame.DecreaseLive();
			this.Destroy();
			return;
		}

		// to collide with other elements
		// element.Destroy();
	}

	protected void CollideDownBorder() {
		super.CollideDownBorder();
		this.Destroy();
	}

	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.Destroy();
	}
	@Override
	public boolean WantKeyEvents() {
		return true;
	}

	@Override
	public void KeyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(2);
			StartMoving();
			setLeftDirection();
		} else if (e.getKeyCode() == KeyEvent.VK_C) {
			StopMoving();

		}
	}

	@Override
	public void KeyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
		
		}
	}
	

}
