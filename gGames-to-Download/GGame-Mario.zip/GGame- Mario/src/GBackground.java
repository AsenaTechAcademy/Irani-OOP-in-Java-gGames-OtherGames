import java.awt.event.KeyEvent;

public class GBackground extends GameMovableElementAdapter {
static int D=0;
	
	public GBackground(int x, int y, String s) {

		super(s, x, y);
		setSpeedX(2);
		setSpeedY(0);
	

	}

	@Override
	public boolean WantKeyEvents() {
		return true;
	}

	@Override
	public void KeyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
			D=getX();

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			setSpeedX(1);
			StartMoving();
			setRightDirection();
			D=getX();

		}
		
	}

	@Override
	public void KeyReleased(KeyEvent e) {

		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
		
			StopMoving();
			setSpeedX(0);

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			
			StopMoving();
			setSpeedX(0);

		}
	}

	@Override
	public void CollideWith(GameElementAdapter element) {

	}

	protected void CollideLeftBorder() {
		return;
	}

}
