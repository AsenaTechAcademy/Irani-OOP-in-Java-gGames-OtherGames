import java.awt.event.KeyEvent;

public class GGarch extends GameMovableElementAdapter {

	public GGarch(int x, int y, String S) {
		super(S, x, y);
		destroyedScore = 100;

	}

	@Override
	public boolean WantKeyEvents() {
		return true;
	}

	@Override
	public void KeyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			setSpeedX(1);
			StartMoving();
			setRightDirection();
		}

	}

	@Override
	public void KeyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			StopMoving();
			setSpeedX(0);
		}

		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			StopMoving();
			setSpeedX(0);
		}
	}

	@Override
	public void CollideWith(GameElementAdapter element) {
		if (element instanceof Player) {
			GGame.IncreaseScore(this.destroyedScore);
			this.Destroy();
			SoundStore.get().Play(Sounds.Score);
			return;
		}
	}

	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.Destroy();
	}

}
