import java.awt.event.KeyEvent;

public class GHeart extends GameMovableElementAdapter {

	private static String Images[] = { "Images/Heart1.gif",
			"Images/Heart2.gif", "Images/Heart3.gif", "Images/Heart4.gif",
			"Images/Heart5.gif", "Images/Heart6.gif" };
	private int cImage = 0;
	private long waitTime = 50;
	private long lastTime = 0;

	public GHeart(int x, int y) {
		super(Images[0], x, y);
		destroyedScore = 100;

	}

	private void nextImage() {
		cImage = (cImage + 1) % 6;
		ChangeImage("Images/Heart" + (cImage + 1) + ".gif");
	}

	public void Step() {
		super.Step();
		if (lastTime + waitTime < System.currentTimeMillis()) {
			this.nextImage();
			lastTime = System.currentTimeMillis();
		}
	}

	protected void CollideDownBorder() {
		super.CollideDownBorder();
		this.Destroy();
	}

	public void CollideWith(GameElementAdapter element) {
		if ((element instanceof Player) || (element instanceof Bullet)) {

			GGame.IncreaseLive();
			GGame.IncreaseScore(destroyedScore);
			this.Destroy();
			return;
		}
		if (element instanceof Player) {
			GGame.IncreaseLive();
			GGame.IncreaseScore(destroyedScore);
			this.Destroy();
			return;
		}

		// to collide with other elements
		// this.goBack();
		// this.StopMoving();
	}

	@Override
	public boolean WantKeyEvents() {
		return true;
	}

	@Override
	public void KeyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			setSpeedX(1);
			StartMoving();
			setRightDirection();
		}
	}

	@Override
	public void KeyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

			StopMoving();
			setSpeedX(0);
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {

			StopMoving();
			setSpeedX(0);
		}
	}

	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.Destroy();
	}
}
