public class GameConstants
{
	public  static int	Game_Width	=800;
	public  static int	Game_Height	=600;
}
