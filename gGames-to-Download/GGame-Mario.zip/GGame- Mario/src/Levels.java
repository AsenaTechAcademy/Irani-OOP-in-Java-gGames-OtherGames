public abstract class Levels {
	public static final int FinalLevel = 3;

	public static void SetLevel(GGame game, int level) {
		if (level == 1) {
			// configs of Level 1
			PlayerInfo p = new PlayerInfo();
			p.setLives(3);
			p.setFires(100);
			p.setScore(0);
			p.setPlayerName("SUPER MARIO");
			p.setCurrentLevel(1);

			game.setPlayerInfo(p);
			LoadMap(game, 1);
		}

		else if (level <= FinalLevel) {
			PlayerInfo p = game.getPlayerInfo();
			p.setCurrentLevel(p.getCurrentLevel() + 1);
			game.setPlayerInfo(p);
			LoadMap(game, level);
		}

	}

	private static void LoadMap(GGame game, int level) {
		if (level == 1)
			LoadMap1(game);
		if (level == 2)
			LoadMap2(game);
		/*
		 * if (level == 3) LoadMap3(game); if (level == 4) LoadMap4(game); if
		 * (level == 5) LoadMap5(game);
		 */

	}

	private static void LoadMap1(GGame game) {
		game.clearEntities();
		// Static parts

		game.setNextEntity(new GBackground(0, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(990, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(2800, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(3500, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(3000, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(0, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(800, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(1800, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(0, 80, "Images/background.gif"));
		game.setNextEntity(new GBackground(1000, 80, "Images/background.gif"));
		game.setNextEntity(new GBackground(2000, 80, "Images/background.gif"));
		game.setNextEntity(new GBackground(2150, 170, "Images/mile.gif"));
		game.setNextEntity(new GBackground(2200, 320, "Images/borj.gif"));

		game.setNextEntity(new Player(100, 430));

		// Other Elements (from MAP)
		game.setNextEntity(new Enemy(2700, 450, "Images/Enemy.gif", -1));
		game.setNextEntity(new Enemy(3700, 450, "Images/Enemy3.gif", -1));
		game.setNextEntity(new Enemy(700, 450, "Images/Enemy0.gif", -1));
		game.setNextEntity(new Enemy(1000, 450, "Images/Enemy.gif", -1));
		game.setNextEntity(new Enemy(2000, 450, "Images/Enemy3.gif", -1));
		game.setNextEntity(new Enemy(800, 210, "Images/Abr1.gif", -1));
		game.setNextEntity(new Planet(540, 310, "Images/planta.gif"));
		game.setNextEntity(new GHeart(140, 300));

	game.setNextEntity(new Ajor(290, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(260, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(320, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(350, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(380, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(410, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(440, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(470, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(500, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(530, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(560, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1060, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1075, 382, "Images/Ajor.gif"));
     	game.setNextEntity(new Ajor(1105, 382, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1135, 382, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1165, 382, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1195, 382, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1225, 382, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1240, 350, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1225, 320, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1195, 320, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1165, 320, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1135, 320, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1105, 320, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1075, 320, "Images/Ajor.gif"));
		game.setNextEntity(new objects(1100, 350, objects.sekke));
		game.setNextEntity(new objects(1120, 350, objects.sekke));
		game.setNextEntity(new objects(1140, 350, objects.sekke));
		game.setNextEntity(new objects(1160, 350, objects.sekke));
		game.setNextEntity(new objects(1180, 350, objects.sekke));
		game.setNextEntity(new objects(1200, 350, objects.sekke));
		game.setNextEntity(new objects(1220, 350, objects.sekke));

		// game.setNextEntity(new TirBrick(200, 500));
		game.setNextEntity(new SekkeBrick10(170, 300));
		game.setNextEntity(new SekkeBrick10(140, 260));
		game.setNextEntity(new SekkeBrick10(190, 260));
		game.setNextEntity(new SekkeBrick10(85, 300));
		game.setNextEntity(new SekkeBrick10(105, 260));
		game.setNextEntity(new SekkeBrick10(220, 300));
		game.setNextEntity(new objects(1640, 330, objects.jabe));
		game.setNextEntity(new objects(1670, 330, objects.jabe));
		game.setNextEntity(new objects(1700, 330, objects.jabe));
		game.setNextEntity(new objects(1730, 330, objects.jabe));
		game.setNextEntity(new objects(1760, 330, objects.jabe));
		game.setNextEntity(new objects(1790, 330, objects.jabe));
		game.setNextEntity(new GGarch(280, 320, "Images/garch.gif"));
		game.setNextEntity(new GGarch(2100, 450, "Images/garch1.gif"));
		game.setNextEntity(new objects(320, 320, objects.sekke));
		game.setNextEntity(new objects(350, 320, objects.sekke));
		game.setNextEntity(new objects(380, 320, objects.sekke));
		game.setNextEntity(new objects(410, 320, objects.sekke));
		// game.setNextEntity(new objects(540, 310, objects.planta));
		game.setNextEntity(new objects(660, 320, objects.star));

	}

	private static void LoadMap2(GGame game) {
		game.clearEntities();
		// Static parts

		game.setNextEntity(new GBackground(0, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(0, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(800, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(1800, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(2500, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(3200, 0, "Images/BG0-800-600.jpg"));
		game.setNextEntity(new GBackground(0, 50, "Images/background1.gif"));
		game.setNextEntity(new GBackground(800, 50, "Images/background1.gif"));
		game.setNextEntity(new GBackground(1600, 50, "Images/background1.gif"));
		game.setNextEntity(new GBackground(2400, 50, "Images/background1.gif"));
		game.setNextEntity(new GBackground(3200, 50, "Images/background1.gif"));
		game.setNextEntity(new GBackground(3250, 170, "Images/mile.gif"));
		game.setNextEntity(new GBackground(3100, 320, "Images/borj.gif"));

		game.setNextEntity(new Player(100, 430));

		// Other Elements (from MAP)

		game.setNextEntity(new SekkeBrick10(130, 370));
		game.setNextEntity(new Ajor(240, 370, "Images/Ajor.gif"));
		game.setNextEntity(new objects(273, 370, objects.jabe));
		game.setNextEntity(new Ajor(305, 370, "Images/Ajor.gif"));
		game.setNextEntity(new objects(338, 370, objects.jabe));
		game.setNextEntity(new Ajor(371, 370, "Images/Ajor.gif"));
		game.setNextEntity(new Enemy(720, 450, "Images/Enemy.gif", 0));
		game.setNextEntity(new Enemy(1720, 450, "Images/Enemy.gif", 0));
		game.setNextEntity(new Enemy(2000, 450, "Images/Enemy3.gif", 0));
		game.setNextEntity(new Enemy(2500, 450, "Images/Enemy0.gif", 0));
		game.setNextEntity(new Enemy(3000, 450, "Images/Enemy.gif", 0));
		game.setNextEntity(new Ajor(371, 370, "Images/Ajor.gif"));

		game.setNextEntity(new Ajor(1035, 370, "Images/Ajor.gif"));
		game.setNextEntity(new SekkeBrick10(1068, 370));
		game.setNextEntity(new Ajor(1101, 370, "Images/Ajor.gif"));
		game.setNextEntity(new SekkeBrick10(1134, 370));
		game.setNextEntity(new Ajor(1167, 370, "Images/Ajor.gif"));
		game.setNextEntity(new SekkeBrick10(1068, 337));
		game.setNextEntity(new objects(1105, 337, objects.sekke));
		game.setNextEntity(new SekkeBrick10(1134, 337));
		game.setNextEntity(new SekkeBrick10(1101, 304));

		game.setNextEntity(new SekkeBrick10(1600, 370));
		game.setNextEntity(new Ajor(1633, 370, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1666, 370, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1699, 370, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1732, 370, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(1765, 370, "Images/Ajor.gif"));
		game.setNextEntity(new SekkeBrick10(1798, 370));
		game.setNextEntity(new objects(1633, 335, objects.sekke));
		game.setNextEntity(new objects(1666, 335, objects.sekke));
		game.setNextEntity(new objects(1699, 335, objects.sekke));
		game.setNextEntity(new objects(1732, 335, objects.sekke));
		game.setNextEntity(new objects(1765, 335, objects.sekke));
		game.setNextEntity(new Planet(1600, 325, "Images/planta.gif"));
		game.setNextEntity(new Planet(1798, 335, "Images/planet2.gif"));

		game.setNextEntity(new Ajor(2255, 370, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(2288, 370, "Images/Ajor.gif"));
		game.setNextEntity(new objects(2321, 370, objects.jabe));
		game.setNextEntity(new objects(2354, 370, objects.jabe));
		game.setNextEntity(new Ajor(2387, 370, "Images/Ajor.gif"));
		game.setNextEntity(new Ajor(2420, 370, "Images/Ajor.gif"));
		game.setNextEntity(new objects(3000, 320, objects.star));

		game.setNextEntity(new Enemy(700, 450, "Images/Enemy0.gif", -1));
		game.setNextEntity(new Enemy(1000, 450, "Images/Enemy.gif", -1));
		game.setNextEntity(new Enemy(2000, 450, "Images/Enemy3.gif", -1));

	}

	/*
	 * private static void LoadMap3(GGame game) { game.clearEntities(); //
	 * Static parts game.setNextEntity(new GBackground(0, 0, 1,
	 * "Images/background.gif")); game.setNextEntity(new Player(300, 560));
	 * 
	 * // Other Elements (from MAP)
	 * 
	 * game.setNextEntity(new LifeBrick(200, 200)); game.setNextEntity(new
	 * LifeBrick(240, 200)); game.setNextEntity(new LifeBrick(280, 200));
	 * game.setNextEntity(new LifeBrick(320, 200)); game.setNextEntity(new
	 * LifeBrick(360, 200)); game.setNextEntity(new LifeBrick(400, 200));
	 * game.setNextEntity(new LifeBrick(440, 200)); game.setNextEntity(new
	 * LifeBrick(480, 200)); game.setNextEntity(new LifeBrick(520, 200));
	 * game.setNextEntity(new LifeBrick(560, 200)); game.setNextEntity(new
	 * TirBrick(200, 160)); game.setNextEntity(new TirBrick(240, 160));
	 * game.setNextEntity(new TirBrick(280, 160)); game.setNextEntity(new
	 * TirBrick(320, 160)); game.setNextEntity(new TirBrick(360, 160));
	 * game.setNextEntity(new TirBrick(400, 160)); game.setNextEntity(new
	 * TirBrick(440, 160)); game.setNextEntity(new TirBrick(480, 160));
	 * game.setNextEntity(new TirBrick(520, 160)); game.setNextEntity(new
	 * TirBrick(560, 160)); game.setNextEntity(new objects(120, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(180, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(240, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(300, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(360, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(420, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(480, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(540, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(600, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(660, 240,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(660, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(600, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(540, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(480, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(420, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(360, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(300, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(240, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(180, 140,
	 * objects.Beton_60_20)); game.setNextEntity(new objects(120, 140,
	 * objects.Beton_60_20)); }
	 */
}
