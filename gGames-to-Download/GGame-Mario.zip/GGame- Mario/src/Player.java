import java.awt.event.KeyEvent;

public class Player extends GameMovableElementAdapter implements Runnable {

	// to firing from both Right and Left sequentially
	private boolean isRightFire = true;

	private static String Images[] = { "Images/mario1.gif",
			"Images/mario2.gif", "Images/mario1.gif" };

	int d = 0;
	static int D = 0;
	Thread animator;
	boolean k = false;

	int X = 1;
	int Y = 0;

	public Player(int x, int y) {

		super(Images[0], x, y);
		d = y;
		setSpeedX(12);
		setSpeedY(0);
	}

	public void Reset() {
		this.setXY(100, 430); // set to first status

	}

	// need to get Key Events
	public boolean WantKeyEvents() {
		return true;
	}

	public void KeyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT
				|| e.getKeyCode() == KeyEvent.VK_RIGHT
				|| e.getKeyCode() == KeyEvent.VK_UP) {
			StopMoving();
			setXY(getpX(), 430);
			setSpeedX(0);
			setSpeedY(0);
			D = getX();
		}
	}

	public void KeyPressed(KeyEvent e) {

		if (e.getKeyCode() == KeyEvent.VK_S)
			Fire(0, 3);
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			System.out.println(getdX());

			ChangeImage("Images/corriendo2.gif");
			System.out.println(getX());
			X = -1;
			Y = 0;

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

			X = 1;

			Y = 0;
			ChangeImage("Images/mario1.gif");

		}

		if (e.getKeyCode() == KeyEvent.VK_UP) {
			SoundStore.get().Play(Sounds.jump);
			if (k == false) {
				animator = new Thread(this);
				animator.start();

				setXY(getX(), d);

			}

		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			Fire(X, Y);

		}
	}

	private void Fire(int x, int y) {
		// if (GGame.getTotalFires() > 0) {
		// Create new Bullet and shoot up from Right and Left
		Bullet b = new Bullet(0, 0, x, y);

		b.setXY(this.getX() + this.getWidth() - b.getWidth() - 10, this.getY()
				- b.getHeight() + 30);

		isRightFire = !isRightFire;

		GGame.addNewEntity(b);
		GGame.DecreaseFires(1);
		SoundStore.get().Play(Sounds.Fire);

	}

	@Override
	public void run() {

		long beforeTime, timeDiff, sleep;
		beforeTime = System.currentTimeMillis();
		while (done == false) {
			cycle();
			timeDiff = System.currentTimeMillis() - beforeTime;
			sleep = 80 - timeDiff;
			if (sleep < 0)
				sleep = 2;
			try {
				Thread.sleep(sleep);
			} catch (Exception e) {
			}
			beforeTime = System.currentTimeMillis();
		}
		done = false;
		h = false;
		k = false;
	}

	boolean h = false;
	boolean done = false;

	public void cycle() {
		if (h == false) {
			d--;
		}
		if (d == 330)
			h = true;
		if (h == true && d <= 430) {
			d++;

			if (d == 430) {
				done = true;
			}
		}
	}
}