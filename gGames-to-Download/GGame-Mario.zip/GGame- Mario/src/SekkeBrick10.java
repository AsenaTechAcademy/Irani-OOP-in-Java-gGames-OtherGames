import java.awt.event.KeyEvent;

public class SekkeBrick10 extends GameMovableElementAdapter {

	public SekkeBrick10(int x, int y) {
		super("Images/emtiaz.gif", x, y);
		destroyedScore = 10;
	}

	public void CollideWith(GameElementAdapter element) {
		if ((element instanceof Player) || (element instanceof Bullet)) {
			GGame.IncreaseScore(destroyedScore);
			this.Destroy();
			return;
		}

	}

	@Override
	protected void CollideLeftBorder() {

		super.CollideLeftBorder();
		this.Destroy();
	}

	@Override
	public void KeyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			setSpeedX(1);
			StartMoving();
			setRightDirection();
		}
	}

	@Override
	public void KeyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			// key = -1;
			StopMoving();
			setSpeedX(0);
		} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			// key = -1;
			StopMoving();
			setSpeedX(0);
		}
	}

	@Override
	public boolean WantKeyEvents() {
		return true;
	}

}
