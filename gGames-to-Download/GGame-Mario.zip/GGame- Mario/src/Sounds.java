public class Sounds {
	public final static String Fire = "Sounds/smb_fireball.wav";
	public final static String Brick = "Sounds/smb_breakblock.wav";
	public final static String levelwin = "Sounds/levelwin.wav";
	public final static String Score = "Sounds/smb_coin.wav";
	public final static String jump = "Sounds/jump (1).wav";
	public final static String gameover = "Sounds/gameover.wav";
	public final static String pause = "Sounds/pause.wav";
	public final static String main = "Sounds/main.wav";
}
