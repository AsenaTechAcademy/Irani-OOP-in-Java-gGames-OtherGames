public class TirBrick extends MultiLifeBrick
{
	public TirBrick(int x , int y)
	{
		super("Images/bolita.gif" , x , y , 3);
		destroyedScore=50;
		
		
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof Player)
		{
			GGame.IncreaseFires(100);
			GGame.IncreaseScore(destroyedScore);
			this.Destroy();
			return;
		}
		super.CollideWith(element);
	}
	
}
