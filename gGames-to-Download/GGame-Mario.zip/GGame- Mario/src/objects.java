import java.awt.event.KeyEvent;

public class objects extends GameMovableElementAdapter {
	public static final int garch = 0;
	public static final int sekke = 1;
	public static final int planta = 2;
	public static final int star = 3;
	public static final int jabe = 4;
	public static final int garch1 = 5;

	public objects(int x, int y, int BetonType) {
		super((getBetonType(BetonType)), x, y);
		this.destroyedScore = this.getWidth() * this.getHeight() / 400;

	}

	private static String getBetonType(int type) {

		if (type == sekke)
			return "Images/sekke.gif";
		else if (type == planta)
			return "Images/planta.gif";
		else if (type == star)
			return "Images/star.gif";
		else if (type == jabe)
			return "Images/jabe.gif";

		return "";
	}

	public void CollideWith(GameElementAdapter him) {
		if (him instanceof Player) {
			GGame.IncreaseScore(this.destroyedScore);
			this.Destroy();
			SoundStore.get().Play(Sounds.Score);
			return;
		}
	}

	@Override
	public boolean WantKeyEvents() {
		return true;
	}

	@Override
	public void KeyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			setSpeedX(1);
			StartMoving();
			setRightDirection();
		}
	}

	@Override
	public void KeyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			StopMoving();
			setSpeedX(0);
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			StopMoving();
			setSpeedX(0);
		}
	}

	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.Destroy();
	}
}