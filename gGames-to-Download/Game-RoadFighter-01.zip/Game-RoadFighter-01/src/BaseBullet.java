public class BaseBullet extends GameMovableElementAdapter {
	
	public BaseBullet(String Image,int x, int y) {
		super(Image,x, y);
		setSpeedX(20);
		setSpeedY(0);
		setRightDirection();
		StartMoving();
	}
	
	public void Step(){
		super.Step();
		if(this.getX()>GameConstants.Window_Width)
			this.Destroy();
		
	}
	
	public void CollideWith(GameElementAdapter element)
	{			
		if(element instanceof CarBase||element instanceof MultiLifeBrick){
		this.Destroy();
			return;}
		super.CollideWith(element);
		}
		
	

}