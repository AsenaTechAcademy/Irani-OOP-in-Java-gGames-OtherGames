public class BigCar extends CarBase
{
	private int CountCollide4;
	private int CountCollide2;
	private static String	Images[]	= { "Images/car1.png","Images/car2.png"};
	private int				cImage		=0;
	
	public BigCar(int x , int y)
	{
		super(Images[0] , x , y);
		destroyedScore=15;
		CountCollide4=0;
		CountCollide2=0;
	}
	
	public void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/car"+(cImage+1)+".png");
	}

	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		if(element instanceof Bullet)
			CountCollide4++;
		if(CountCollide4==4)
		{
			GGame.IncreaseScore(destroyedScore);
			SoundStore.get().Play(Sounds.Score);
			this.Destroy();
			return;	
		}
		
		if(element instanceof SuperBullet)
			CountCollide2++;
		if(CountCollide2==2)
		{
			GGame.IncreaseScore(destroyedScore);
			SoundStore.get().Play(Sounds.Score);
			this.Destroy();
			return;
		}
		
	}
}
