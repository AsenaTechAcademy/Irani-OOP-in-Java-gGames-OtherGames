public class Bullet extends BaseBullet
{
	
	public Bullet(int x , int y)
	{
		super("Images/Bullet0.GIF" , x , y);
	}
	
	public void Step()
	{
		super.Step();
	}
	
	public void CollideWith(GameElementAdapter element)
	{			
		super.CollideWith(element);
	}
	
		
	
}
