
public class CarBase extends Move {
	
	private long			waitTime	=40;
	private long			lastTime	=0;
	public CarBase(String ref, int x, int y) {
		super(ref, x, y);
	}

	public void nextImage()
	{
		//overriding in child class
	}
	
	
	public void Step()
	{
		super.Step();
		if(this.getX()<MyCar.GetXCar()-200)
		{
			GGame.IncreaseLoseScore(2*destroyedScore);
			this.Destroy();
		}
		
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
			
		}
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof MyCar)
		{
			if(Shield.getShield()&&!Star.getPower())
			{
				SoundStore.get().Play(Sounds.Score);
				GGame.IncreaseScore(destroyedScore);
				Shield.setNoShield();
				this.Destroy();
				return;
			}
			
			if(Star.getPower())
			{
				SoundStore.get().Play(Sounds.Score);
				GGame.IncreaseScore(destroyedScore);
				MyCar.Power++;
				this.Destroy();
				if(MyCar.Power==4)
				{
					Star.setNoPower();
					MyCar.Power=0;
				}
			}
			
			else
			{
				SoundStore.get().Play(Sounds.Brick);
				GGame.DecreaseLive();
				this.Destroy();
				return;
			}
			
		}
	}
}
