public class Cars extends CarBase
{
	public static final int	CarYellow	=1;
	public static final int	CarCyan 	=2;
	private int				cImage		=0;
	private int		NumberCar	=0;
	
	public Cars(int x , int y , int CarType)
	{
		super((getCarType(CarType)) , x , y);
		this.destroyedScore=5;
		if(CarType==CarYellow)
			NumberCar=1;
		if(CarType==CarCyan)
			NumberCar=2;
	}
	  
	private static String getCarType(int type)
	{
		if (type==CarYellow)
			return "Images/y1.png";
		else if (type==CarCyan)
			return "Images/cy1.png";
		
		return "";
	}

	public void nextImage()
	{
		cImage=(cImage+1)%2;
		if(NumberCar==1)
			ChangeImage("Images/y"+(cImage+1)+".png");
		if(NumberCar==2)
			ChangeImage("Images/cy"+(cImage+1)+".png");
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		if (element instanceof Bullet||element instanceof SuperBullet)
		{
			SoundStore.get().Play(Sounds.Score);
			GGame.IncreaseScore(destroyedScore);
			this.Destroy();
			return;
		}
	}
	
}
