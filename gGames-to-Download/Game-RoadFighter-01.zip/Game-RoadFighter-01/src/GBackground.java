import java.awt.event.KeyEvent;

public class GBackground extends GameMovableElementAdapter
{
	private static String	Images[]	= { "Images/b1.png","Images/b1.png","Images/b2.png"};
	private int				cImage		=0;
	private long			waitTime	=70;
	private long			lastTime	=0;
	
	public GBackground(int x , int y,int type)
	{
		super(Images[0] , x , y);
		
	}
	private void nextImage()
	{
		
		cImage=(cImage+1)%2;
		ChangeImage("Images/b"+(cImage+1)+".png");
	}

	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
			
		}
	}

	
}
