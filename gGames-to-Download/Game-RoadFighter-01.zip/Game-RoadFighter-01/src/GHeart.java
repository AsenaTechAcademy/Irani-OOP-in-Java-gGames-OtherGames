public class GHeart extends Prise
{
	
	private static String	Images[]	= { "Images/Heart1.gif", "Images/Heart2.gif",
			"Images/Heart3.gif","Images/Heart4.gif","Images/Heart5.gif","Images/Heart6.gif" };
	private int				cImage		=0;
	
	public GHeart(int x , int y)
	{
		super(Images[0] , x , y);
		
	}
	
	public void nextImage()
	{
		cImage=(cImage+1)%6;
		ChangeImage("Images/Heart"+(cImage+1)+".gif");
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		GGame.IncreaseLive();
	}
}
