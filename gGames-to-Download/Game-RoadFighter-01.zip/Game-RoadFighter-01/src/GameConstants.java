public class GameConstants
{
	public final static int	Game_Width	=12550;
	public final static int	Game_Height	=600;
	public final static int	Window_Width	=800;
	public final static int	Window_Height	=600;
}
