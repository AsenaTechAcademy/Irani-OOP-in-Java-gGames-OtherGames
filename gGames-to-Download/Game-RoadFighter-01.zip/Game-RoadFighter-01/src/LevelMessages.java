import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class LevelMessages
{
	public static void ShowLevelMessages(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		ShowScoreBoard(currentPlayer , graphics , Levelstatus);
		ShowLevelNotStarted(currentPlayer , graphics , Levelstatus);
		ShowLossLive(currentPlayer , graphics , Levelstatus);
		ShowGameOver(currentPlayer , graphics , Levelstatus);
		ShowLevelWinned(currentPlayer , graphics , Levelstatus);
		ShowMenu(currentPlayer , graphics , Levelstatus);
	}
	
	private static void ShowMenu(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_Player)
		{
			graphics.setColor(Color.black);
			graphics.fillRect(260 , 380 , 250 , 80);
			graphics.setColor(Color.red);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Game Stop" , 320 , 405);
			
			graphics.setColor(Color.green);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("press  ESC to exit game" , 310 , 440);
			graphics.drawString("press  Ctrl  to resume game" , 310 , 453);
		}
	}
	
	private static void ShowScoreBoard(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		graphics.setColor(Color.white);
		graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
		graphics.drawString("Name: "+currentPlayer.getPlayerName() , 10 , 470);
		graphics.drawString("Level: "+currentPlayer.getCurrentLevel() , 10 ,490);
		graphics.drawString("Lives: "+currentPlayer.getLives() , 10, 510);
		graphics.drawString("Score: "+currentPlayer.getScore() , 10 , 530);
		graphics.drawString("LoseScore: "+currentPlayer.getLoseScore() , 10, 550);
		graphics.drawString("Fires: "+currentPlayer.getFires() , 10 , 570);
		graphics.drawString("SuperFire: "+currentPlayer.getSuperFires() , 160, 470);
		graphics.drawString("WaterFire: "+currentPlayer.getWaterFires() ,160, 490);
		graphics.drawString("Time: "+currentPlayer.getCurrentTime() , 160, 510);
		graphics.drawString("Shield: "+GGame.getShield() , 160, 530);
		graphics.drawString("Power: "+GGame.getPower() , 160, 550);
		
		
	}
	
	private static void ShowLevelNotStarted(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelNotStarted)
		{
			
			graphics.setColor(Color.black);
			graphics.fillRect(210 , 370 , 450 , 50);
			graphics.setColor(Color.blue);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Please ''Ctrl'' to Start"+"   "+"Level"+GGame.getLevel() , 240 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
		}
	}
	
	
	private static void ShowGameOver(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		
		if (Levelstatus==LevelStatus.GameOver)
		{
			graphics.setColor(Color.BLACK);
			graphics.fillRect(170 , 370 , 400 , 80);
			graphics.setColor(Color.red);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Game Over, Looser !" , 230 , 405);
			
			graphics.setColor(Color.red);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to Exit" , 310 , 440);
		}
	}
	
	private static void ShowLossLive(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_LiveLoss)
		{
			graphics.setColor(Color.black);
			graphics.fillRect(250 , 380 , 250 , 80);
			graphics.setColor(Color.red);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Be careful !!" , 300 , 405);
			
			graphics.setColor(Color.green);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to continue" , 310 , 440);
		}
	}
	
	private static void ShowLevelWinned(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		
		if (Levelstatus==LevelStatus.LevelWined)
		{
			if(GGame.getLevel()==4){
				
				graphics.setColor(Color.black);
				graphics.fillRect(160 , 350 , 300 , 80);
				graphics.setColor(Color.BLUE);
				graphics.setFont(new Font("Arial" , Font.BOLD , 28));
				graphics.drawString("The End" , 250 , 375);
				graphics.setColor(Color.WHITE);
				graphics.setFont(new Font("Tahoma" , Font.BOLD , 15));
				graphics.drawString("Press Ctrl to Exit" , 250 , 410);
				
			}
			else{
			graphics.setColor(Color.black);
			graphics.fillRect(180 , 370 , 400 , 80);
			graphics.setColor(Color.GREEN);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("OK, Level Complete" , 250 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to next level" , 310 , 440);}
		
		}
	}
	
}
