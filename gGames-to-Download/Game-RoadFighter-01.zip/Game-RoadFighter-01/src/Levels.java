public abstract class Levels
{
	public static final int	FinalLevel	=3;
	
	public static void SetLevel(GGame game , int level)
	{
		if (level==1)
		{
			PlayerInfo p=new PlayerInfo();
			p.setLives(3);
			p.setFires(0);
			p.setScore(0);
			p.setPlayerName("Saeed Mahrani");
			p.setCurrentLevel(1);
			
			game.setPlayerInfo(p);
			LoadMap(game , 1);
		}
		
		else if (level<=FinalLevel)
		{
			PlayerInfo p=game.getPlayerInfo();
			p.setCurrentLevel(p.getCurrentLevel()+1);
			game.setPlayerInfo(p);
			LoadMap(game , level);
		}
		
	}
	
	private static void LoadMap(GGame game , int level)
	{
		if (level==1)
			LoadMap1(game);
		if (level==2)
			LoadMap2(game);
		if (level==3)
			LoadMap3(game);
		
	}
	
	private static void LoadMap1(GGame game)
	{
		game.clearEntities();
		game.setNextEntity(new GBackground(0, 0 ,0));
		game.setNextEntity(new MyCar( MyCar.GetXCar(), MyCar.GetYCar()));
		
		game.setNextEntity(new TirBrick(900 ,380 ));
		game.setNextEntity(new Pit(1000 ,350 ));
		game.setNextEntity(new WaterTir(1200 ,270 ));
		game.setNextEntity(new TirBrick(1400 ,270 ));
		game.setNextEntity(new SLoseFire( 1500,270  ));
		game.setNextEntity(new Cars(1600 ,250,Cars.CarYellow));
		game.setNextEntity(new Cars(1700 ,350,Cars.CarYellow));
		game.setNextEntity(new Pit(1800 ,210 ));
		game.setNextEntity(new Cars(1900 ,250,Cars.CarCyan));
		game.setNextEntity(new Cars(2000 ,170,Cars.CarYellow));
		game.setNextEntity(new SLoseFire( 2100,330 ));
		game.setNextEntity(new Cars(2300 ,350,Cars.CarCyan));
		game.setNextEntity(new SLoseFire( 2500,370  ));
		game.setNextEntity(new BigCar( 2600,370  ));
		game.setNextEntity(new SLoseFire( 2800,210  ));
		game.setNextEntity(new Cars( 3000,300,Cars.CarCyan));
		game.setNextEntity(new Cars( 3200,230,Cars.CarYellow ));
		game.setNextEntity(new Pit(3300 ,220 ));
		game.setNextEntity(new GHeart(3400 ,220  ));
		game.setNextEntity(new Cars(3500 ,350,Cars.CarYellow));
		game.setNextEntity(new Cars(3600 ,180,Cars.CarCyan));
		game.setNextEntity(new Cars( 3700,320,Cars.CarYellow));
		game.setNextEntity(new Cars( 3900,350,Cars.CarCyan));
		game.setNextEntity(new Pit(4100 ,350 ));
		game.setNextEntity(new Cars( 4200,350,Cars.CarYellow));
		game.setNextEntity(new Cars(4300,190,Cars.CarCyan));
		game.setNextEntity(new SLoseFire(4400 ,350  ));
		game.setNextEntity(new GHeart(4500 ,350 ));
		game.setNextEntity(new Cars(4600 ,220,Cars.CarYellow));
		game.setNextEntity(new Cars(4700 ,280,Cars.CarYellow));
		game.setNextEntity(new Cars(4900 ,300,Cars.CarCyan));
		game.setNextEntity(new SpeedUp(5000 ,250));
		game.setNextEntity(new SpeedUp(5000 ,280));
		game.setNextEntity(new SpeedUp(5000 ,350));
		game.setNextEntity(new SpeedUp(5000 ,380));
		game.setNextEntity(new Cars(5100 ,330,Cars.CarCyan));
		game.setNextEntity(new Star(5200 ,280));
		game.setNextEntity(new Cars(5300 ,250,Cars.CarCyan));
		game.setNextEntity(new BigCar(5400 ,350));
		game.setNextEntity(new Cars(5600 ,380,Cars.CarYellow));
		game.setNextEntity(new Cars(5750 ,250,Cars.CarYellow));
		game.setNextEntity(new Pit( 5950,160 ));
		game.setNextEntity(new SLoseFire( 5950,190 ));
		game.setNextEntity(new SLoseFire( 5950,250 ));
		game.setNextEntity(new SLoseFire( 5950,300 ));
		game.setNextEntity(new SLoseFire( 5950,350 ));
		game.setNextEntity(new Pit( 5950,390 ));
		game.setNextEntity(new TirBrick(6100 ,195 ));
		game.setNextEntity(new Cars(6200 ,260,Cars.CarCyan));
		game.setNextEntity(new Cars(6400 ,300,Cars.CarYellow));
		game.setNextEntity(new Cars(6500 ,360,Cars.CarCyan));
		game.setNextEntity(new Pit(6600 ,350 ));
		game.setNextEntity(new Cars( 6700,200,Cars.CarYellow));
		game.setNextEntity(new SLoseFire(6800 ,190 ));
		game.setNextEntity(new Cars(6900 ,180,Cars.CarCyan));
		game.setNextEntity(new Cars( 7300,250,Cars.CarCyan));
		game.setNextEntity(new Cars(7500 ,300,Cars.CarYellow));
		game.setNextEntity(new SLoseFire(7600 ,280 ));
		game.setNextEntity(new Cars(7700 ,220,Cars.CarYellow));
		game.setNextEntity(new Cars(7800 ,300,Cars.CarCyan));
		game.setNextEntity(new Cars(7900 ,380,Cars.CarCyan));
		game.setNextEntity(new Cars(8000 ,310,Cars.CarYellow));
		game.setNextEntity(new SpeedUp(8100 ,180 ));
		game.setNextEntity(new Pit(8100 ,210 ));
		game.setNextEntity(new SpeedUp(8100 ,270 ));
		game.setNextEntity(new SpeedUp(8100 ,300 ));
		game.setNextEntity(new SpeedUp(8100 ,340 ));
		game.setNextEntity(new Pit(8100 ,380 ));
		game.setNextEntity(new SuperTirBrick(8200 ,280 ));
		game.setNextEntity(new Cars(8300 ,350,Cars.CarCyan));
		game.setNextEntity(new Cars(8400 ,270,Cars.CarYellow));
		game.setNextEntity(new Cars( 8600,350,Cars.CarYellow));
		game.setNextEntity(new Cars(8800 ,380,Cars.CarCyan));
		game.setNextEntity(new ZeroDoer(8900 ,285 ));
		game.setNextEntity(new SLoseFire(9100 ,180 ));
		game.setNextEntity(new SLoseFire(9100 ,260 ));
		game.setNextEntity(new SLoseFire(9100 ,300 ));
		game.setNextEntity(new SLoseFire(9100 ,350 ));
		game.setNextEntity(new BigCar( 9200,320 ));
		game.setNextEntity(new BigCar( 9500,350 ));
		game.setNextEntity(new Cars(9600 ,280,Cars.CarYellow));
		game.setNextEntity(new Cars(9750 ,230,Cars.CarYellow));
		game.setNextEntity(new SuperTirBrick(9900,300));
		game.setNextEntity(new Cars(10000 ,200,Cars.CarCyan ));
		game.setNextEntity(new SLoseFire(10200 ,160 ));
		game.setNextEntity(new SpeedUp(10200 ,220 ));
		game.setNextEntity(new SpeedUp(10200 ,250 ));
		game.setNextEntity(new SpeedUp(10200 ,280 ));
		game.setNextEntity(new SLoseFire(10200 ,315  ));
		game.setNextEntity(new SpeedUp(10200 ,370 ));
		game.setNextEntity(new Shield(10300 ,300  ));
		game.setNextEntity(new BigCar(10500 ,250  ));
		game.setNextEntity(new Cars(10700 ,220,Cars.CarCyan));
		game.setNextEntity(new Cars(10800 ,350,Cars.CarYellow));
		game.setNextEntity(new BigCar(10900 ,350  ));
		game.setNextEntity(new BigCar(11100 ,220 ));
		game.setNextEntity(new BigCar(11300 ,350 ));
		game.setNextEntity(new BigCar(11500 ,220 ));
		game.setNextEntity(new LineEnd(12000 ,155));
		
	}

	private static void LoadMap2(GGame game)
	{
		game.clearEntities();
		game.setNextEntity(new GBackground(0 , 0 , 0));
		game.setNextEntity(new MyCar( MyCar.GetXCar(), MyCar.GetYCar()));
		
		game.setNextEntity(new WaterTir(900 ,350 ));
		game.setNextEntity(new TirBrick(1000 ,270 ));
		game.setNextEntity(new SLoseFire( 1100,270  ));
		game.setNextEntity(new SLoseFire( 1200,350  ));
		
		game.setNextEntity(new Cars(1300 ,320,Cars.CarYellow));
		game.setNextEntity(new Shield(1400 ,350 ));
		game.setNextEntity(new Cars(1500 ,350,Cars.CarYellow ));
		game.setNextEntity(new Cars(1600 ,270,Cars.CarCyan));
		game.setNextEntity(new Cars(1800 ,320,Cars.CarYellow));
		game.setNextEntity(new Cars( 1900,210,Cars.CarCyan ));
		game.setNextEntity(new Cars(2100,250,Cars.CarCyan));
		game.setNextEntity(new SLoseFire( 2200,265 ));
		game.setNextEntity(new TirBrick(2300 ,300 ));
		game.setNextEntity(new SLoseFire( 2400,350 ));
		game.setNextEntity(new GHeart(2500 ,220 ));
		game.setNextEntity(new Pit(2600 ,220 ));
		game.setNextEntity(new Cars(2700 ,280,Cars.CarYellow));
		game.setNextEntity(new SLoseFire(2800,250));
		game.setNextEntity(new Cars(2900 ,230,Cars.CarCyan));
		game.setNextEntity(new Cars(3000 ,380,Cars.CarYellow));
		game.setNextEntity(new Cars(3300 ,355,Cars.CarCyan));
		game.setNextEntity(new SLoseFire( 3400,210));
		game.setNextEntity(new Cars(3500 ,260,Cars.CarYellow));
		game.setNextEntity(new Pit(3600 ,220 ));
		game.setNextEntity(new TirBrick(3700 ,210 ));
		game.setNextEntity(new SpeedUp(3800 ,280 ));
		game.setNextEntity(new SpeedUp(3800 ,330 ));
		game.setNextEntity(new SpeedUp(3800 ,380 ));
		game.setNextEntity(new ZeroDoer(3900 ,350 ));
		game.setNextEntity(new Star(4000 ,210 ));
		game.setNextEntity(new Cars(4100 ,280,Cars.CarCyan));
		game.setNextEntity(new Cars(4200 ,350,Cars.CarYellow ));
		game.setNextEntity(new Cars(4300 ,270,Cars.CarYellow));
		game.setNextEntity(new SLoseFire( 4400,350 ));
		game.setNextEntity(new Cars( 4500,300,Cars.CarCyan ));
		game.setNextEntity(new Cars(4600 ,200 ,Cars.CarCyan));
		game.setNextEntity(new Cars(4700,320,Cars.CarYellow));
		game.setNextEntity(new Cars(4800 ,280,Cars.CarYellow));
		game.setNextEntity(new Cars(4900 ,230,Cars.CarCyan));
		game.setNextEntity(new SuperTirBrick(5100,320));
		game.setNextEntity(new SLoseFire(5200,250 ));
		game.setNextEntity(new BigCar(5300,250 ));
		game.setNextEntity(new BigCar(5500 ,350 ));
		game.setNextEntity(new Cars(5600 ,230,Cars.CarCyan));
		game.setNextEntity(new Pit(5700 ,380 ));
		game.setNextEntity(new GHeart(5800,380 ));
		game.setNextEntity(new SpeedUp(5900 ,250 ));
		game.setNextEntity(new SpeedUp(5900 ,300 ));
		game.setNextEntity(new ZeroDoer(6000 ,250 ));
		game.setNextEntity(new Cars(6200 ,290 ,Cars.CarCyan));
		game.setNextEntity(new Cars(6200 ,330,Cars.CarYellow ));
		game.setNextEntity(new TirBrick(6300,300));
		game.setNextEntity(new Cars(6400 ,210,Cars.CarYellow ));
		game.setNextEntity(new Cars(6500 ,250,Cars.CarCyan));
		game.setNextEntity(new Cars(6700 ,370,Cars.CarYellow));
		game.setNextEntity(new Cars(6900 ,380,Cars.CarCyan));
		game.setNextEntity(new Pit(7000 ,380 ));
		game.setNextEntity(new Cars(7100 ,210,Cars.CarCyan));
		game.setNextEntity(new Pit(7200 ,220 ));
		game.setNextEntity(new Shield(7300 ,280 ));
		game.setNextEntity(new SpeedUp(7400 ,200 ));
		game.setNextEntity(new SpeedUp(7400 ,230 ));
		game.setNextEntity(new SpeedUp(7400 ,270 ));
		game.setNextEntity(new SpeedUp(7400 ,300 ));
		game.setNextEntity(new SpeedUp(7400 ,350 ));
		game.setNextEntity(new SpeedUp(7400 ,380 ));
		game.setNextEntity(new BigCar(7600 ,350 ));
		game.setNextEntity(new BigCar(7800 ,220 ));
		game.setNextEntity(new BigCar(8000 ,310 ));
		game.setNextEntity(new BigCar(8200 ,350 ));
		game.setNextEntity(new BigCar(8400 ,220 ));
		game.setNextEntity(new LineEnd(9000 ,155));
		
	}
	
	
	private static void LoadMap3(GGame game)
	{
		game.clearEntities();

		game.setNextEntity(new GBackground(0 , 0 , 1));
		game.setNextEntity(new MyCar( MyCar.GetXCar(), MyCar.GetYCar()));
		
		game.setNextEntity(new WaterTir(900 ,250 ));
		game.setNextEntity(new TirBrick(1000 ,270 ));
		game.setNextEntity(new SuperTirBrick(1100 ,300 ));
		game.setNextEntity(new SLoseFire( 1250,250  ));
		game.setNextEntity(new BigCar(1350 ,220 ));
		game.setNextEntity(new Cars(1500 ,320,Cars.CarCyan));
		game.setNextEntity(new Cars(1600 ,350,Cars.CarYellow));
		game.setNextEntity(new Cars(1700 ,270,Cars.CarYellow));
		game.setNextEntity(new Pit(1850 ,380));
		game.setNextEntity(new BigCar(1900 ,350));
		game.setNextEntity(new GHeart(2000 ,300));
		game.setNextEntity(new BigCar( 2100,220));
		game.setNextEntity(new SpeedUp( 2200,360));
		game.setNextEntity(new SpeedUp( 2400,380));
		game.setNextEntity(new BigCar(2600 ,220));
		game.setNextEntity(new Cars(2700 ,300,Cars.CarCyan));
		game.setNextEntity(new Cars(2850 ,380,Cars.CarYellow));
		game.setNextEntity(new BigCar(3000 ,350));
		game.setNextEntity(new SpeedUp( 3250,250));
		game.setNextEntity(new SpeedUp( 3250,350 ));
		game.setNextEntity(new SpeedUp(3250,380 ));
		game.setNextEntity(new Cars(3400,210,Cars.CarCyan));
		game.setNextEntity(new Cars(3500,220,Cars.CarYellow));
		game.setNextEntity(new Pit(3700 ,230 ));
		game.setNextEntity(new Pit(3700 ,380 ));
		game.setNextEntity(new BigCar(3800 ,280 ));
		game.setNextEntity(new Cars(3900 ,350,Cars.CarYellow));
		game.setNextEntity(new Cars(4000 ,380,Cars.CarYellow));
		game.setNextEntity(new GHeart(4100 ,280 ));
		game.setNextEntity(new ZeroDoer(4200 ,300 ));
		game.setNextEntity(new Star(4300 ,350 ));
		game.setNextEntity(new SpeedUp(4400,210));
		game.setNextEntity(new SpeedUp(4400,240));
		game.setNextEntity(new SpeedUp(4400,280));
		game.setNextEntity(new SpeedUp(4400,320 ));
		game.setNextEntity(new Cars(4500 ,280,Cars.CarCyan));
		game.setNextEntity(new Cars(4600 ,230,Cars.CarCyan));
		game.setNextEntity(new TirBrick(4700,300));
		game.setNextEntity(new Shield(4800,350));
		game.setNextEntity(new SLoseFire( 4900,210));
		game.setNextEntity(new BigCar(5000,220));
		game.setNextEntity(new BigCar(5200,350));
		game.setNextEntity(new Cars(5300,330 ,Cars.CarYellow));
		game.setNextEntity(new SpeedUp(5400,250 ));
		game.setNextEntity(new SpeedUp(5400,350 ));
		game.setNextEntity(new BigCar(5500 ,300 ));
		game.setNextEntity(new Cars(5600,350,Cars.CarCyan));
		game.setNextEntity(new SpeedUp(5700,280));
		game.setNextEntity(new SpeedUp(5700,330));
		game.setNextEntity(new SpeedUp(5700,380));
		game.setNextEntity(new BigCar(5850 ,355));
		game.setNextEntity(new ZeroDoer(6000 ,250));
		game.setNextEntity(new SuperTirBrick(6100,280));
		game.setNextEntity(new BigCar(6200 ,220 ));
		game.setNextEntity(new BigCar(6400,350));
		game.setNextEntity(new BigCar(6600 ,220));
		game.setNextEntity(new Cars(6800 ,350,Cars.CarYellow));
		game.setNextEntity(new BigCar(6900 ,350));
		game.setNextEntity(new Pit(7000 ,210));
		game.setNextEntity(new BigCar(7200 ,220));
		game.setNextEntity(new BigCar(7300 ,350 ));
		game.setNextEntity(new BigCar(7600 ,350 ));
		game.setNextEntity(new LineEnd(9000 ,155));}
}
