public class LineEnd extends Move
{
	private static String	Image="Images/End.png";
	public LineEnd(int x , int y)
	{
		super(Image , x , y);
		
	}
		public void Step(){
			super.Step();
			if(this.getX()<MyCar.GetXCar()-50)
				GGame.Levelstatus=LevelStatus.LevelWined;
			}
		
		public void CollideWith(GameElementAdapter element)
		{
			
		}
	
	
}
