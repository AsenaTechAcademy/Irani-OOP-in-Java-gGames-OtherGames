
public class Move extends GameMovableElementAdapter{

	public Move(String ref, int x, int y) {
		super(ref, x, y);
	}
	
	public void Step()
	{
		super.Step();
		setSpeed();
		
	}
	
	public void setSpeed()
	{
		setSpeedX(5);
		setSpeedY(0);
		setLeftDirection();
		StartMoving();
	}	
	
}
