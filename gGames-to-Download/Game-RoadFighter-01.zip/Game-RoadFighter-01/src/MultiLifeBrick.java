public abstract class MultiLifeBrick extends Move
{
	public MultiLifeBrick(String FirstImage , int x , int y )
	{
		super(FirstImage , x , y);
		
	}
	
	public void Step(){
		super.Step();
		if(this.getX()<MyCar.GetXCar()-200)
			this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof MyCar||element instanceof Bullet||element instanceof SuperBullet||element instanceof WaterBullet)
				this.Destroy();
	}	
	
	
}
