import java.awt.event.KeyEvent;

public class MyCar extends GameMovableElementAdapter
{
	private boolean	isRightFire	=true;
	private int FireReady;
	private int minY=155, maxY=405, minX=100, maxX=100;
	private static final int X=100,Y=280;
	private static  boolean	Activate;
	static  boolean	Down,Up;
	static  int     Power       =0;
	 
	private int				cImage		=0;
	private long			waitTime	=30;
	private long			lastTime	=0;

	public MyCar(int x , int y)
	{
		super("Images/cb1.png" , x , y);
		setSpeedX(0);
		setSpeedY(5);
		SetLimits(minX, maxX, minY, maxY);
		Activate=true;
		Down=false;
		Up=false;
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		if(GGame.getTotalFires()>0||GGame.getTotalSuperFires()>0&&Activate)
			ChangeImage("Images/m"+(cImage+1)+".png");
		
		else
		ChangeImage("Images/cb"+(cImage+1)+".png");
		
	}

	
	public void setLimitMove()
	{
		if(this.getY()==minY||this.getY()==maxY)
		{
			if(!Star.getPower())
			{
				if(GGame.getPlayerInfo().getLives()>0)
				{
					Reset();
					SoundStore.get().Play(Sounds.Brick);
					if(Shield.getShield())
					{
						Shield.setNoShield();
						Reset();
					}	
					else
					{
					GGame.DecreaseLive();
					StopMoving();
					}
				}
				else GGame.DecreaseLive();
			}
		}
		else return;
		
	}
		
  public static int GetXCar(){
		return X;
  }
	
  public static int GetYCar(){
		return Y;
  }
  
  public void Step(){
		super.Step();
		setLimitMove();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();	
		}
		if(Up)
			ChangeImage("Images/m1-15d.png");
		if(Down)
			ChangeImage("Images/m1-15u.png");
			
	}
  
  
  public void CollideWith(GameElementAdapter element)
  {
		if (element instanceof Pit)
		{
			if(!Star.getPower())
			{
				Activate=false;
				if(this.getY()<Y)
				{
					Up=true;
					setUpDirection();
					
				}
				if(this.getY()>Y)
				{
					setDownDirection();
					Down=true;
				}
				StartMoving();
				return;
			}
		}
		
		if (element instanceof BigCar)
		{
			if(Shield.getShield()&&!Star.getPower())
			{
				Shield.setNoShield();
				return;
			}
			if(!Star.getPower())
			{
				GGame.DecreaseLive();
				return;
			}
		}	
	}
  
  
	public void Reset()
	{
		this.setXY(GetXCar() ,GetYCar());
		if(GGame.getTotalFires()>0)
			ChangeImage("Images/m1.png");
		else
			ChangeImage("Images/cb1.png");
	}
	
	
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyReleased(KeyEvent e)
	{
		if(Activate)
		{
		if (e.getKeyCode()==KeyEvent.VK_DOWN||e.getKeyCode()==KeyEvent.VK_UP)
			StopMoving();
		}
	}
	
	public void KeyPressed(KeyEvent e)
	{
		if(Activate)
		{
			if (e.getKeyCode()==KeyEvent.VK_S)
				Fire();
			if (e.getKeyCode()==KeyEvent.VK_D )
				SuperFire();	
			if (e.getKeyCode()==KeyEvent.VK_A )
				WaterFire();	
			
			if (e.getKeyCode()==KeyEvent.VK_DOWN)
			{
				StartMoving();
				setDownDirection();
				}
			
			if (e.getKeyCode()==KeyEvent.VK_UP)
			{
				StartMoving();
				setUpDirection();
				
				}
		}
	}
	
	private void Fire()
	{
		if(GGame.getTotalFires()>0){
			Bullet b=new Bullet(X , Y);
			if (isRightFire)
				b.setXY(this.getX()+50 , this.getY()+7);
			else
				b.setXY(this.getX()+80 , this.getY()+7);	
			isRightFire=!isRightFire;
			
			GGame.addNewEntity(b);
			GGame.DecreaseFires(1);
			SoundStore.get().Play(Sounds.Fire);}
	
		}
	
		private void SuperFire(){
			if(GGame.getTotalSuperFires()>0){	
				SuperBullet b=new SuperBullet(X , Y);
				if (isRightFire)
				b.setXY(this.getX()+50 , this.getY()+7);
				else
					b.setXY(this.getX()+80 , this.getY()+7);
				isRightFire=!isRightFire;
		
			GGame.addNewEntity(b);
			GGame.DecreaseSuperFires(1);
			SoundStore.get().Play(Sounds.SuperFire);}
	}
		
		private void WaterFire(){
			if(GGame.getTotalWaterFires()>0){
			WaterBullet b=new WaterBullet(X , Y);
			if (isRightFire)
				b.setXY(this.getX()+50 , this.getY()+7);
			else
				b.setXY(this.getX()+80 , this.getY()+7);
			isRightFire=!isRightFire;
			
			GGame.addNewEntity(b);
			GGame.DecreaseWaterFires(1);
			SoundStore.get().Play(Sounds.Water);}
		}
		
		public static void setActivate()
		{
			Activate=true;
		}
}
