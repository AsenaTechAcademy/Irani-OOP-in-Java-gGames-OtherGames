public class Pit extends Prise
{

	public Pit(int x , int y)
	{
		super("Images/Pit.png" , x , y);
		
	}
	 
	
	public void Step()
	{
		super.Step();
		setSpeedX(5);
		setSpeedY(0);
		setLeftDirection();
		StartMoving();
	}
		
	public void CollideWith(GameElementAdapter element)
	{	
			
	}
	
}
