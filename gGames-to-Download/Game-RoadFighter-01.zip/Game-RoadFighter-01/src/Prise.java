
public class Prise extends Move {

	private long			waitTime	=40;
	private long			lastTime	=0;
	
	public Prise(String ref, int x, int y) {
		super(ref, x, y);
	}
	public void nextImage()
	{
		//overriding in child class
	}
	
	
	public void Step()
	{
		//super.Step();
		if(this.getX()<MyCar.GetXCar()-200)
			this.Destroy();
		
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
			
		}
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		
		super.CollideWith(element);
		if (!(element instanceof BaseBullet))
		{
			SoundStore.get().Play(Sounds.Zero);
			this.Destroy();
			return;
		}
	}
}
	

