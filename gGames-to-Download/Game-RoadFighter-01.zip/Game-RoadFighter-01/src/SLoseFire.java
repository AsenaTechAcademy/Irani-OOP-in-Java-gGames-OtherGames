import java.awt.Graphics;

public class SLoseFire extends Move
{
	
	private static String	Images[]={"Images/f1.png","Images/f2.png","Images/f3.png","Images/f4.png","Images/f5.png"
		,"Images/f6.png","Images/f7.png","Images/f8.png","Images/f9.png","Images/f10.png","Images/f11.png","Images/f12.png"};
			
	private int				cImage		=0;
	private long			waitTime	=10;
	private long			lastTime	=0;
	private int             Count;
	public SLoseFire(int x , int y)
	{
		super(Images[0] , x , y);
		this.destroyedScore=5;
		Count=0;
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%12;
		ChangeImage("Images/f"+(cImage+1)+".png");
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
		
		if(this.getX()<MyCar.GetXCar()-100)
			this.Destroy();
		
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof MyCar)
		{
			if(!Star.getPower())
			{
				if(Shield.getShield())
				{
					SoundStore.get().Play(Sounds.Brick);
					Shield.setNoShield();
					this.Destroy();
					return;
				}
				else
				{
					SoundStore.get().Play(Sounds.TirFall);
					GGame.DecreaseFires(destroyedScore);
					this.Destroy();
					return;
				}
			}
			else
			{
				this.Destroy();
				return;
			}
		}	
		if (element instanceof WaterBullet)
			Count++;
			if(Count==2)
		{
			GGame.IncreaseScore(2*destroyedScore);
			this.Destroy();
			return;
		}
	}
}
