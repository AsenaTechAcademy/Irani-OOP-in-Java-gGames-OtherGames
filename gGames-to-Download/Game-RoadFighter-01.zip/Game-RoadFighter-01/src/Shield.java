
public class Shield extends Prise{

	private static boolean isShield=false;
	
	public Shield(int x, int y)
	{
		super("Images/Shield.png" , x , y );
		
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		isShield=true;
	}
	
	public static void setNoShield()
	{
			isShield=false;
	}
		
	public static boolean getShield()
	{
		return isShield;
	}
		
}