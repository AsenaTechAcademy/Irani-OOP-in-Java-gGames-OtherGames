public class Sounds
{
	public final static String	Fire	="Sounds/Fire.wav";
	public final static String	Brick	="Sounds/Brick.wav";
	public final static String	Score	="Sounds/Score.wav";
	public final static String	Ready ="Sounds/Ready.wav";
	public final static String	Destroy ="Sounds/Destroy.wav";
	public final static String	SuperFire ="Sounds/SuperFire.wav";
	public final static String	TirFall ="Sounds/TirFall.wav";
	public final static String	Water ="Sounds/Water.wav";
	public final static String	Zero ="Sounds/Zero.wav";
	public final static String	LoseScore ="Sounds/LoseScore.wav";
	public final static String	Bm ="Sounds/Bm.wav";
}
