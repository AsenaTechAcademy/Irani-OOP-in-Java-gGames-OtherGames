public class SpeedUp extends Move
{
	private static boolean Speed=false;
	public SpeedUp(int x , int y)
	{
		super("Images/Speed.png" , x , y );
	}
	
	public void Step(){
		super.Step();
		if(this.getX()<MyCar.GetXCar()-100)
			this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof MyCar)
		{
			Speed=true;
			GGame.speed=10;
			return;
		}
		super.CollideWith(element);
	}
	public static boolean getSpeed()
	{
		return Speed;
	}
	
	public static void notSpeed()
	{
		 Speed=false;
	}
	
}
