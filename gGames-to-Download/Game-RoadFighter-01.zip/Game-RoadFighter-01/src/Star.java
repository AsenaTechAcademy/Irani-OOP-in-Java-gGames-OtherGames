
public class Star extends Prise {

	private static String	Images[]	= { "Images/star1.png", "Images/star2.png",
		"Images/star3.png","Images/star4.png","Images/star5.png","Images/star6.png" };
	private int				cImage		=0;
	private static boolean  Power=false;
	
	public Star(int x, int y) {
		super(Images[0], x, y);
	}
	
	public void nextImage()
	{
		cImage=(cImage+1)%6;
		ChangeImage("Images/star"+(cImage+1)+".png");
	}
		
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		Power=true;
	}
	
	public static void setNoPower()
	{
		Power=false;
	}
		
	public static boolean getPower()
	{
		return Power;
	}
	
}

	
	
	
	

