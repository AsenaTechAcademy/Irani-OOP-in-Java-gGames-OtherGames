
public class SuperBullet extends BaseBullet {
	private int count;
	public SuperBullet(int x, int y) {
		super("Images/Bullet1.png",x, y);
		count=0;
	}
	
	public void Step(){
		super.Step();	
	}
	
	public void CollideWith(GameElementAdapter element)
	{			
		super.CollideWith(element);
		
		if(element instanceof Cars)
			count++;
		if(count==2){
			this.Destroy();
			return;}
		
		}
		
	

}
