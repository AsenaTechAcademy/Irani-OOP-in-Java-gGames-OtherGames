public class SuperTirBrick extends MultiLifeBrick
{
	private static String	Image="Images/STir.png";
	public SuperTirBrick(int x , int y)
	{
		super(Image , x , y );
		destroyedScore=50;
	}
	
	 public void Step()
	 {
		super.Step();		
	 }
	
	
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		SoundStore.get().Play(Sounds.Ready);
		GGame.IncreaseSuperFires(destroyedScore);
			
		
	}
	
}
