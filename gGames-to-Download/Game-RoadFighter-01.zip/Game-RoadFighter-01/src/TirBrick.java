public class TirBrick extends MultiLifeBrick
{
	private static String	Image="Images/Tir1.png";
	public TirBrick(int x , int y)
	{
		super(Image , x , y );
		destroyedScore=20;
	}
	
	
	 public void Step()
	 {
		super.Step();
	 }
	
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		if(GGame.getTotalFires()==0&&GGame.getTotalSuperFires()==0)
			SoundStore.get().Play(Sounds.Ready);
		GGame.IncreaseFires(destroyedScore);
		
	}
	
}
