
public class WaterBullet extends BaseBullet {
	
	public WaterBullet(int x, int y) 
	{
		super("Images/Bullet2.png",x, y);
	}
	
	public void Step()
	{
		super.Step();
		
	}
	
	public void CollideWith(GameElementAdapter element)
	{			
		super.CollideWith(element);
		if(element instanceof SLoseFire)
		{
			this.Destroy();
			return;
		}
			
	}
		
	

}
