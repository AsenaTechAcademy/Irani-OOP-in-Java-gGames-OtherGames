public class WaterTir extends MultiLifeBrick
{
	private static String	Image="Images/WTir.png";
	public WaterTir(int x , int y)
	{
		super(Image , x , y );
		destroyedScore=50;
	}
	
	 public void Step()
	 {
		super.Step();
	}
	
	
	public void CollideWith(GameElementAdapter element)
	{
		
		super.CollideWith(element);
		GGame.IncreaseWaterFires(destroyedScore);
	}
	
}
