public class ZeroDoer extends Prise
{
	
	public ZeroDoer(int x , int y)
	{
		super("Images/zd.png", x , y);
	}
	
	public void CollideWith(GameElementAdapter element)
	{	
		super.CollideWith(element);
		GGame.getPlayerInfo().setLoseScore(0);
		
	}
	
}
