///////////// ax digar barayeh marahel 
public class Background extends BaseClass{

	public Background(int x , int y , int type)//////////// jaygozin esm
	{
		super("Images/BG"+type+"-800-600.jpg", x , y);
		if(Main.getlvl()==2){
		ChangeImage("Images/BG-2.jpg");
		}
		else if(Main.getlvl()==3)
			ChangeImage("Images/BG-3.jpg");
		else if(Main.getlvl()==4)
			ChangeImage("Images/BG-4.jpg");
		else if(Main.getlvl()==5)
			ChangeImage("Images/BG-5.jpg");
		
		GGame.Wint++;
	}
	
}
