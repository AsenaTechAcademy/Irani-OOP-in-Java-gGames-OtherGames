import java.awt.event.KeyEvent;

import org.omg.CosNaming.IstringHelper;


public class Ball extends MoveableBaseClass {
	

	private int key=-1;
	private int collide=-1;
	private int space=0;
	private long lastTime=0;
	private int c=0;
	public static int Hot=0;
	
	public Ball(int x , int y)
	{
		super("Images/ball-0.gif" , x , y);
		Hot=0;
		StartMoving();
		
		GGame.Wint++;
		
	}
	@Override
	public void  KeyPressed(KeyEvent e){
		if(e.getKeyCode()==KeyEvent.VK_RIGHT){
			key=e.getKeyCode();
			StartMoving();
			setSpeedX(7);
		}
		else if(e.getKeyCode()==KeyEvent.VK_LEFT){
			key=e.getKeyCode();
			StartMoving();
			setSpeedX(-7);
		}
		else if(e.getKeyCode()==KeyEvent.VK_SPACE){
			if(collide!=-1)
				if(space==0){
					SoundStore.get().Play(Sounds.Jump);
					space=1;
				}
		}
		if(e.getKeyCode()==KeyEvent.VK_Z)
				Fire(-1);
		if(e.getKeyCode()==KeyEvent.VK_X)
			Fire(1);
		
	}
	@Override
	public boolean WantKeyEvents()
	{
		return true;
	}
	@ Override
	public void KeyReleased(KeyEvent e)
	{
		if(e.getKeyCode()==KeyEvent.VK_RIGHT){
			key=-1;
			StopMoving();
			setSpeedX(0);
		}
		else if(e.getKeyCode()==KeyEvent.VK_LEFT){
			key=-1;
			StopMoving();
			setSpeedX(0);
		}
		else if(e.getKeyCode()==KeyEvent.VK_SPACE){
			setSpeedY(0);
			if(getSpeedX()==0)
				StopMoving();
		}
	}
	private void Fire(int a)
	{
		
		if (GGame.getTotalFires()>0)
		{
			// Create new Bullet and shoot up from Right and Left
			Fire b=new Fire(getX()+28,getY());
			
			if(a==1)
				b.FireRight();
			else{
				b.setXY(getX()-17 ,getY());
				b.FireLeft();
			}
			
		///	b.setXY(this.getX()+1 , this.getY()+1);
			
			GGame.addNewEntity(b);
			GGame.DecreaseFires(1);
		}
		else
			SoundStore.get().Play(Sounds.F);
	}
	
	public void Reset()
	{
		this.setXY(100 , 469);
	}
	@Override
	public void CollideWith(BaseClass element) {
		
		if(element instanceof grands)
		{
			if(collide!=1){
			if(this.getY()>(element.getY()+18))
				GGame.DecreaseLive();
			else if(getY()<element.getY()+2)
					this.setXY(getX(),element.getY()-32);
			else
				setSpeedY(3);
						
			}
			
			collide=1;
		}
		
	}
	public void jump(){
		if(key==KeyEvent.VK_RIGHT){
			if(space<20)
				setXY(getX()+3, getY()-5);
			if(space>=20){
				setXY(getX()+3, getY()+2);
				if(space==29)
					space=0;
			}
		}
		else if(key==KeyEvent.VK_LEFT){
				if(space<20)
					setXY(getX()-3, getY()-5);
				if(space>=20){
					setXY(getX()-3, getY()+2);
					if(space==29)
						space=0;
				}
			}
		else{
			if(space<20)
				setXY(getX(), getY()-5);
			if(space>=20){
				setXY(getX(), getY()+1);
				if(space==29)
					space=0;
			}
		}
		if(space!=0)
			space++;
		
	}
	
	@Override
	public void step()
	{
		super.step();
		
		collide=-1;

		
		StartMoving();
		if(key==KeyEvent.VK_RIGHT)
			setSpeedX(1);
		else if(key==KeyEvent.VK_LEFT)
			setSpeedX(-1);
		else
			setSpeedX(0);
		setSpeedY(2);
		
		if (getX()< getminX() && getX() > getmaxX())
			setSpeedY(3);
		
		if(space!=0)
			jump();
		
	if(Hot==0 && space==0)
		ChangeImage("Images/ball-0.gif");
	}
}
