import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public abstract class BaseClass implements IBaseClass {

	private int X;
	private int Y;
	
	private Sprite	sprite;	

	private int ID;

	private int Height;
	private int Width;

	private int maxX;
	private int maxY;
	private int minX;
	private int minY;

	public BaseClass() {
		
	}
	
	public BaseClass(String ref, int x, int y) {
		this.sprite=SpriteStore.get().getSprite(ref);
		

		setWidth(sprite.getWidth());
		setHeight(sprite.getHeight());
		
		minX=0;
		maxX=GameConstants.Game_Width-getWidth();
		minY=0;
		maxY=GameConstants.Game_Height-getHeight();

		setXY(x, y);
	}


	public int getmaxX() {
		return this.maxX;
	}

	public int getminX() {
		return this.minX;
	}

	public int getmaxY() {
		return this.maxY;
	}

	public int getminY() {
		return this.minY;
	}

	public int getID() {
		return ID;
	}

	private Rectangle getRectangle() {
		return new Rectangle(X, Y, Width, Height);
	}

	public void setXY(int x, int y) {
		if (y >= minY && y <= maxY && x >= minX && x <= maxX) {
			X = x;
			Y = y;
		}
		else if(this instanceof Fire  )
				Destroy();
		else if(this instanceof F )
				Destroy();
		else if ( y >= maxY)
		{
			if(this instanceof Ball)
				GGame.DecreaseLive();
		}
	}
	
	public boolean WantKeyEvents()
	{
		return false;
	}
	
	public void KeyPressed(KeyEvent e)
	{
		// should override in child classes
	}
	
	public void KeyReleased(KeyEvent e)
	{
		// should override in child classes
	}

	public void setID(int id)
	{
		if (id>=0)
			this.ID=id;
	}
	
	private void setWidth(int width) {
		if (width > 0 && width <= GameConstants.Game_Width)
			Width = width;
	}

	private void setHeight(int height) {
		if (height > 0 && height <= GameConstants.Game_Height)
			Height = height;
	}

	protected void SetLimits(int minX, int maxX, int minY, int maxY) {
		this.minX = minX;
		this.maxX = maxX;
		this.minY = minY;
		this.maxY = maxY;
	}

	public void ChangeImage(String ref)
	{
		sprite=SpriteStore.get().getSprite(ref);
		setWidth(sprite.getWidth());
		setHeight(sprite.getHeight());
	}
	
	public int getX() {
		return X;
	}

	public int getY() {
		return Y;
	}

	public int getHeight() {
		return Height;
	}

	public int getWidth() {
		return Width;
	}

	@Override
	public void draw(Graphics g) {
		sprite.draw(g , X , Y);

	}

	@Override
	public void Destroy() {
		GGame.NotifyDeath(this);
	}

	@Override
	public void step() {
		// TODO Auto-generated method stub

	}

	@Override
	public void CollideWith(BaseClass bs) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean contains(BaseClass bs) {

		return this.getRectangle().intersects(bs.getRectangle());
	}

}
