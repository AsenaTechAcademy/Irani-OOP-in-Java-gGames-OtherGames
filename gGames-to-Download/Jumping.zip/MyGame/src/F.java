
public class F extends MoveableBaseClass{
	
	public F(int x , int y)
	{
		super("Images/F-R.gif" , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(0);
		this.StartMoving();
	}
	public void FireRight(){
		ChangeImage("Images/F-R.gif");
		this.setSpeedX(5);
	}
	public void FireLeft(){
		ChangeImage("Images/F-L.gif");
		this.setSpeedX(-5);
	}
	public void CollideWith(BaseClass element)
	{
		if(element instanceof Ball){
			this.Destroy();
			GGame.DecreaseLive();
		}
	}

}
