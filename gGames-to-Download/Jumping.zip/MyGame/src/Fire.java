
public class Fire extends MoveableBaseClass{
	
	public Fire(int x , int y)
	{
		super("Images/bullet-R.gif" , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(0);
		this.StartMoving();
	}
	public void FireRight(){
		ChangeImage("Images/bullet-R.gif");
		this.setSpeedX(5);
	}
	public void FireLeft(){
		ChangeImage("Images/bullet-L.gif");
		this.setSpeedX(-5);
	}
	public void CollideWith(BaseClass element)
	{
		this.Destroy();
	}

}
