
public class Hot extends BaseClass {
	

	private static String	Images[]	={ "Images/fire-0.gif", "Images/fire-1.gif",
			"Images/fire-2.gif", "Images/fire-3.gif", "Images/fire-4.gif", "Images/fire-5.gif", "Images/fire-6.gif" };

	private int				cImage		=0;
	private long			waitTime	=110;
	private long			lastTime	=0;
	
	public Hot(int x , int y)
	{
		super(Images[0] , x , y);
		GGame.Wint++;
		
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%7;
		ChangeImage("Images/fire-"+(cImage)+".gif");
	}
	@Override
	public void step()
	{
		super.step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(BaseClass element)
	{
		if (element instanceof Ball)
		{
			((Ball) element).Hot=3;
			element.ChangeImage("Images/ball-3.gif");
			GGame.Wint--;
			this.Destroy();
			return;
		}
		
	}


}
