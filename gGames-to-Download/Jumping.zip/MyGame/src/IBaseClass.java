import java.awt.Graphics;

public interface IBaseClass {

	public void draw(Graphics g);

	public void Destroy();

	public void step();

	public void CollideWith(BaseClass bs);

	public boolean contains(BaseClass bs);

}
