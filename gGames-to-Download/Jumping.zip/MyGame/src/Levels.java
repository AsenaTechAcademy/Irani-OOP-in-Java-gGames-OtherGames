import javax.swing.JOptionPane;
/////
public abstract class Levels
{
	public static final int	FinalLevel	=5;///////// chang lvls
	
	public static void SetLevel(GGame game , int level)
	{
		if (level==1)
		{
			PlayerInfo p=new PlayerInfo();
			p.setLives(2);
			p.setFires(1);
			p.setScore(0);
			p.setPlayerName("you name");
			p.setCurrentLevel(1);
			
			game.setPlayerInfo(p);
			LoadMap(game ,1);
		}
		
		else if (level<=FinalLevel)
		{
			PlayerInfo p=game.getPlayerInfo();
			p.setCurrentLevel(p.getCurrentLevel()+1);
			game.setPlayerInfo(p);
			LoadMap(game , level);
		}
		
	}
	
	private static void LoadMap(GGame game , int level)
	{
		if (level==1)
			LoadMap1(game);
		if (level==2)
			LoadMap2(game);
		if (level==3)
			LoadMap3(game);
		if (level==4)
			LoadMap4(game);
		if (level==5)
			LoadMap5(game);
		
	}
	
	
	private static void LoadMap1(GGame game)
	{
		GGame.Wint=0;
		game.clearEntities();
		// Static parts
		game.setNextEntity(new Background(0 , 0 , 3));
		game.setNextEntity(new Ball(100 , 469));
				
		game.setNextEntity(new grands(0, 500,0));
		game.setNextEntity(new grands(455 , 500,0));
		game.setNextEntity(new grands(0 , 420,3));
		game.setNextEntity(new grands(620 , 420,2));
		game.setNextEntity(new grands(200 ,350,1));
		game.setNextEntity(new grands(450 ,280,1));

		game.setNextEntity(new sekkeh2(320 ,220));
		game.setNextEntity(new sekkeh2(340 ,220));
		game.setNextEntity(new sekkeh2(360 ,220));
		game.setNextEntity(new sekkeh2(380 ,220));
		game.setNextEntity(new sekkeh(90 , 395));
		game.setNextEntity(new sekkeh(0 , 395));
		game.setNextEntity(new sekkeh(30 , 395));
		game.setNextEntity(new sekkeh(60 , 395));
		game.setNextEntity(new sekkeh(710 , 395));
		game.setNextEntity(new sekkeh(740 , 395));
		game.setNextEntity(new sekkeh(770 , 395));
		game.setNextEntity(new sekkeh(300 , 325));
		game.setNextEntity(new sekkeh(330 , 325));
		game.setNextEntity(new sekkeh(530 , 255));
		game.setNextEntity(new sekkeh(560 , 255));
		game.setNextEntity(new sekkeh(590 , 255));

		
		game.setNextEntity(new heart(630 , 253));
		
	}
	
	private static void LoadMap2(GGame game)
	{
		GGame.Wint=0;
		game.clearEntities();
		// Static parts
		game.setNextEntity(new Background(0 , 0 , 3));
		game.setNextEntity(new Ball(100 , 469));
		
		game.setNextEntity(new Xeshab(210 , 460));
		
		game.setNextEntity(new grands(100, 500,0));
		game.setNextEntity(new grands(0, 430,3));
		game.setNextEntity(new grands(130, 350,1));
		game.setNextEntity(new grands(400, 400,1));
		game.setNextEntity(new grands(620, 320,2));
		game.setNextEntity(new grands(370, 240,1));
		
		game.setNextEntity(new sekkeh(300 , 475));
		game.setNextEntity(new sekkeh(330 , 475));
		game.setNextEntity(new sekkeh(360 , 475));
		game.setNextEntity(new sekkeh(390 , 475));
		
		game.setNextEntity(new sekkeh(10 , 405));
		game.setNextEntity(new sekkeh(40 , 405));
		game.setNextEntity(new sekkeh(70 , 405));
		
		game.setNextEntity(new sekkeh(260 , 325));
		game.setNextEntity(new sekkeh(290 , 325));
		game.setNextEntity(new sekkeh(320 , 325));
		game.setNextEntity(new sekkeh(350 , 325));
		
		game.setNextEntity(new sekkeh(530 , 375));
		game.setNextEntity(new sekkeh(560 , 375));
		game.setNextEntity(new sekkeh(590 , 375));
		game.setNextEntity(new sekkeh(620 , 375));
		
		game.setNextEntity(new sekkeh(670 , 295));
		game.setNextEntity(new sekkeh(700 , 295));
		game.setNextEntity(new sekkeh(730 , 295));
		
		game.setNextEntity(new sekkeh(480 , 215));
		
		game.setNextEntity(new sekkeh2(460 , 180));
		game.setNextEntity(new sekkeh2(480 , 180));
		game.setNextEntity(new sekkeh2(500 , 180));

		game.setNextEntity(new sekkeh2(100 , 280));
		game.setNextEntity(new sekkeh2(80 , 280));
		game.setNextEntity(new sekkeh2(60 , 280));
		game.setNextEntity(new sekkeh2(40 , 280));
		game.setNextEntity(new sekkeh2(20 , 280));
		
		game.setNextEntity(new sekkeh2(480 , 160));
		game.setNextEntity(new sekkeh2(680 , 150));
		game.setNextEntity(new sekkeh2(700 , 130));
		game.setNextEntity(new sekkeh2(660 , 130));
		game.setNextEntity(new sekkeh2(720 , 150));
				
		game.setNextEntity(new hayola(120 , 360));
		game.setNextEntity(new hayola(190 , 280));
		game.setNextEntity(new hayola(460 , 335));
		game.setNextEntity(new hayola(410 , 170));
		game.setNextEntity(new hayola(570 , 170));
		
		game.setNextEntity(new heart(630 , 288));
		
	}
	
	
	private static void LoadMap3(GGame game)
	{
		GGame.Wint=0;
		game.clearEntities();
		// Static parts
		game.setNextEntity(new Background(0 , 0 , 3));
		game.setNextEntity(new Ball(100 , 469));
		
		game.setNextEntity(new grands(50, 500,0));
		game.setNextEntity(new grands(400, 430,1));//
		game.setNextEntity(new grands(90, 360,1));
		game.setNextEntity(new grands(375, 300,1));
		game.setNextEntity(new grands(80, 240,1));//
		game.setNextEntity(new grands(310, 170,1));//
		
		game.setNextEntity(new sekkeh(300 , 475));
		game.setNextEntity(new sekkeh(520 , 405));
		game.setNextEntity(new sekkeh(550 , 405));
		game.setNextEntity(new sekkeh(150 , 335));
		game.setNextEntity(new sekkeh(180 , 335));
		game.setNextEntity(new sekkeh(210 , 335));
		game.setNextEntity(new sekkeh(500 , 275));
		game.setNextEntity(new sekkeh(530, 275));
		game.setNextEntity(new sekkeh(560 , 275));
		game.setNextEntity(new sekkeh(230 ,215));
		game.setNextEntity(new sekkeh(260 ,215));
		game.setNextEntity(new sekkeh(290 ,215));
		game.setNextEntity(new sekkeh(550 ,145));
		game.setNextEntity(new sekkeh(750 ,430));
		game.setNextEntity(new sekkeh(700 ,310));
		game.setNextEntity(new sekkeh(740 ,210));
		
		game.setNextEntity(new sekkeh2(250 , 300));
		game.setNextEntity(new sekkeh2(270 , 300));
		game.setNextEntity(new sekkeh2(290 , 300));
		game.setNextEntity(new sekkeh2(310 , 300));
		game.setNextEntity(new sekkeh2(600 , 230));
		game.setNextEntity(new sekkeh2(620 , 230));
		game.setNextEntity(new sekkeh2(640 , 230));
		game.setNextEntity(new sekkeh2(680 , 280));
		game.setNextEntity(new sekkeh2(660 , 250));
		game.setNextEntity(new sekkeh2(660 , 380));
		
		game.setNextEntity(new heart(650 , 550));
		game.setNextEntity(new heart(500 ,140));
		
		game.setNextEntity(new hayola(460 , 360));
		game.setNextEntity(new hayola(120 , 170));
		game.setNextEntity(new hayola2(390 , 100));
		
		game.setNextEntity(new Xeshab(590 , 380));
		
		
		
	}
	
	
	private static void LoadMap4(GGame game)
	{
		GGame.Wint=0;
		game.clearEntities();
		// Static parts
		game.setNextEntity(new Background(0 , 0 , 3));
		game.setNextEntity(new Ball(100 , 469));
		
		game.setNextEntity(new grands(0, 500,0));
		game.setNextEntity(new grands(500, 560,1));
		game.setNextEntity(new grands(0, 430,3));
		game.setNextEntity(new grands(200, 350,1));
		game.setNextEntity(new grands(0, 275,3));
		game.setNextEntity(new grands(120, 205,1));
		game.setNextEntity(new grands(450, 135,1));
		game.setNextEntity(new grands(620, 70,2));
		game.setNextEntity(new grands(620, 300,2));
		
		
		game.setNextEntity(new Hot(320 ,155));

		game.setNextEntity(new sekkeh(600, 535));
		game.setNextEntity(new sekkeh(630, 535));
		game.setNextEntity(new sekkeh(660, 535));
		game.setNextEntity(new sekkeh(10, 405));
		game.setNextEntity(new sekkeh(40, 405));
		game.setNextEntity(new sekkeh(70, 405));
		game.setNextEntity(new sekkeh(300, 325));
		game.setNextEntity(new sekkeh(270, 325));
		game.setNextEntity(new sekkeh(240, 325));
		game.setNextEntity(new sekkeh(20, 250));
		game.setNextEntity(new sekkeh(50, 250));
		game.setNextEntity(new sekkeh(80, 250));
		game.setNextEntity(new sekkeh(250, 180));
		game.setNextEntity(new sekkeh(295, 180));
		game.setNextEntity(new sekkeh(210, 180));
		game.setNextEntity(new sekkeh(175, 180));
		game.setNextEntity(new sekkeh(470, 105));
		game.setNextEntity(new sekkeh(650, 105));
		game.setNextEntity(new sekkeh(680, 105));
		game.setNextEntity(new sekkeh(740, 40));
		game.setNextEntity(new sekkeh(770, 40));
		game.setNextEntity(new sekkeh(630, 270));
		game.setNextEntity(new sekkeh(670,270));
		
			game.setNextEntity(new sekkeh(430,195));
			game.setNextEntity(new sekkeh(565, 309));
			game.setNextEntity(new sekkeh(570, 347));

			game.setNextEntity(new sekkeh(522, 382));
			game.setNextEntity(new sekkeh(474, 417));
			game.setNextEntity(new sekkeh(426, 452));
			game.setNextEntity(new sekkeh(471, 490));
			game.setNextEntity(new sekkeh(516, 528));
		
			game.setNextEntity(new heart(490 , 270));
			
		game.setNextEntity(new hayola(390 ,280));
		game.setNextEntity(new hayola2(570 ,65));
		game.setNextEntity(new hayola(655 ,0));
		game.setNextEntity(new hayola2(740 ,230));
	
	}
	
	private static void LoadMap5(GGame game)
	{GGame.Wint=0;
	game.clearEntities();
	// Static parts
	game.setNextEntity(new Background(0 , 0 , 3));
	game.setNextEntity(new Ball(100 , 469));
	
	game.setNextEntity(new grands(0, 500,0));
	game.setNextEntity(new grands(320, 430,1));//
	game.setNextEntity(new grands(10,320,1));
	game.setNextEntity(new grands(498, 350,1));
	game.setNextEntity(new grands(0, 200,1));//
	game.setNextEntity(new grands(460,268,1));//
	game.setNextEntity(new grands(250,110,1));//
	game.setNextEntity(new grands(320,190,1));//
	
	game.setNextEntity(new sekkeh(300 , 475));
	game.setNextEntity(new sekkeh(490 , 405));
	game.setNextEntity(new sekkeh(520 , 405));
	game.setNextEntity(new sekkeh(550 , 405));
	game.setNextEntity(new sekkeh(150 , 294));
	game.setNextEntity(new sekkeh(180 , 294));
	game.setNextEntity(new sekkeh(210 , 294));
	game.setNextEntity(new sekkeh(500 , 240));
	game.setNextEntity(new sekkeh(530, 240));
	game.setNextEntity(new sekkeh(560 , 240));
	game.setNextEntity(new sekkeh(100 ,175));
	game.setNextEntity(new sekkeh(70,175));
	game.setNextEntity(new sekkeh(40 ,175));
	game.setNextEntity(new sekkeh(500 ,165));
	game.setNextEntity(new sekkeh(750 ,430));
	game.setNextEntity(new sekkeh(710 ,325));
	game.setNextEntity(new sekkeh(680 ,325));
	game.setNextEntity(new sekkeh(740 ,210));
	
	game.setNextEntity(new sekkeh2(340 , 300));
	game.setNextEntity(new sekkeh2(360 , 300));
	game.setNextEntity(new sekkeh2(380 , 300));
	game.setNextEntity(new sekkeh2(400 , 300));
	game.setNextEntity(new sekkeh2(420 , 300));
	game.setNextEntity(new sekkeh2(440 , 300));
	game.setNextEntity(new sekkeh2(140 , 60));
	game.setNextEntity(new sekkeh2(160 , 60));
	game.setNextEntity(new sekkeh2(180 , 60));
	game.setNextEntity(new sekkeh2(120 , 60));
	game.setNextEntity(new sekkeh2(100 , 60));
	
	
	game.setNextEntity(new heart(450 ,165));
	
	game.setNextEntity(new hayola(360 , 360));
	game.setNextEntity(new hayola2(170 , 135));
	game.setNextEntity(new hayola(380 , 45));
	game.setNextEntity(new hayola(173 , 440));
	game.setNextEntity(new hayola(77 , 255));
	game.setNextEntity(new hayola2(560 ,285));
	game.setNextEntity(new hayola2(640 ,200));
	
	
	game.setNextEntity(new Hot(20 ,457));
	game.setNextEntity(new Hot(360 ,143));
	
	
	
	
	
		
	}
	
	
}
