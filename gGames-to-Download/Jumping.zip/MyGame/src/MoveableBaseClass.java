
public class MoveableBaseClass extends BaseClass {
	private int		pX , pY;
	private int		speedX;
	private int		speedY;	
	private boolean	ismoving;	
	
	public MoveableBaseClass(String ref , int x , int y)
	{
		super(ref , x , y);
		this.speedX=0;
		this.speedY=0;
		this.ismoving=false;
		this.pX=getX();
		this.pY=getY();
		
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , 0 ,
				GameConstants.Game_Height-this.getHeight());
	}
	
	protected void goNextPoint()
	{
		if (ismoving)
		{
			pX=getX();
			pY=getY();
			setXY(getX()+speedX , getY()+speedY);
		}
	}
	@Override
	public void step()
	{
		super.step(); 
		goNextPoint();
	}
	protected boolean isMoving()
	{
		return ismoving;
	}
	
	protected void StopMoving()
	{
		ismoving=false;
	}
	
	protected void StartMoving()
	{
		ismoving=true;
	}
	
	protected void setSpeedX(int newSpeedX)
	{
		speedX=Math.abs(newSpeedX);
		if(newSpeedX<0)
			speedX*=-1;
	}
	
	protected void setSpeedY(int newSpeedY)
	{
		speedY=Math.abs(newSpeedY);
		if(newSpeedY<0)
			speedY*=-1;
	}
	
	protected int getSpeedX()
	{
		return speedX;
	}
	
	protected int getSpeedY()
	{
		return speedY;
	}
	
	
}
