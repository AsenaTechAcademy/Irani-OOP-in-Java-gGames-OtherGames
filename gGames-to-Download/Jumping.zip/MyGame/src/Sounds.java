public class Sounds
{
	public final static String	Die	="Sounds/Die.wav";
	public final static String	sekkeh	="Sounds/sekkeh.wav";
	public final static String	fire	="Sounds/fire-0.wav";
	public final static String	xeshab	="Sounds/xeshab.wav";
	public final static String	F	="Sounds/F.wav";
	public final static String	Kill	="Sounds/Kill.wav";
	public final static String	Jump	="Sounds/Jump.wav";
	public final static String	Win	="Sounds/Win.wav";

}
