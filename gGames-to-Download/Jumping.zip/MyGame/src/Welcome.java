
public class Welcome extends MoveableBaseClass {
private static String Images[] = { "Images/wel-0.gif", "Images/wel-1.gif", "Images/wel-2.gif","Images/wel-3.gif", "Images/wel-4.gif" ,"Images/wel-5.gif", "Images/wel-6.gif","Images/wel-7.gif", "Images/wel-8.gif","Images/wel-9.gif","Images/wel-10.gif", "Images/wel-11.gif", "Images/wel-12.gif", "Images/wel-13.gif", "Images/wel-14.gif", "Images/wel-15.gif", "Images/wel-16.gif", "Images/wel-17.gif", "Images/wel-18.gif", "Images/wel-19.gif", "Images/wel-20.gif", "Images/wel-21.gif", "Images/wel-22.gif", "Images/wel-23.gif"};
	
	private int cImage = 0;
	private long waitTime = 70;
	private long lastTime = 0;
	protected int destroyedScore=0;

	public Welcome(int x, int y) {
		
		super(Images[0], x, y);
		destroyedScore = 100;

		setSpeedY(2);
		setSpeedX(0);
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%24;
		ChangeImage("Images/wel-"+(cImage)+".gif");
	}
	
	@Override
	public void step()
	{
		super.step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
}
