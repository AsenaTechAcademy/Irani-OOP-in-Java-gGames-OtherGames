
public class Xeshab extends BaseClass{
	

	private static String	Images[]	= { "Images/xeshab-0.gif", "Images/xeshab-1.gif"};
	private int				cImage		=0;
	private long			waitTime	=200;
	private long			lastTime	=0;
	
	public Xeshab(int x , int y)
	{
		super(Images[0] , x , y);
		
	}
	
	private void nextImage()
	{
		if(cImage==1)
			waitTime	=100;
		else
			waitTime	=350;
		cImage=(cImage+1)%2;
		ChangeImage("Images/xeshab-"+(cImage)+".gif");
	}
	@Override
	public void step()
	{
		super.step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(BaseClass element)
	{
		if (element instanceof Ball)
		{
			GGame.IncreaseFires(6);
			this.Destroy();
			return;
		}
		
	}

}
