
public class grands extends BaseClass{
	
	public grands(int x , int y , int BrickType)
	{
		super((getBrickType(BrickType)) , x , y);
		GGame.Wint++;
	}
	
	private static String getBrickType(int type)
	{
		return "Images/grand-"+type+".gif";
		
	}

}
