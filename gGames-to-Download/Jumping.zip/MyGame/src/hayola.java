public class hayola extends MoveableBaseClass {

	private static String Images[] = { "Images/man-0.gif", "Images/man-1.dif", "Images/man-2.gif", "Images/man-3.gif", "Images/man-4.gif", "Images/man-5.gif", "Images/man-6.gif", "Images/man-7.gif"};
	private int cImage = 0;
	private long waitTime = 200;
	private long lastTime = 0;
	protected int destroyedScore = 0;

	public hayola(int x, int y) {
		super(Images[0], x, y);
		destroyedScore = 150;

		StartMoving();
		
		setSpeedY(0);
		setSpeedX(1);
		StartMoving();
	}

	private void nextImage() {
		cImage = (cImage + 1) % 8;
		ChangeImage("Images/man-" + (cImage) + ".gif");
	}
	@Override
	public  void step() {
		super.step();
		if (lastTime + waitTime < System.currentTimeMillis()) {
			this.nextImage();
			lastTime = System.currentTimeMillis();
		}
		
		if(cImage>3)
			setSpeedX(1);
		else
			setSpeedX(-1);
	}

	public void CollideWith(BaseClass element) {
		if ((element instanceof Fire)) {
			GGame.IncreaseScore(destroyedScore);
			SoundStore.get().Play(Sounds.Kill);
			this.Destroy();
			return;
		}
		if (element instanceof Ball) {
			if(((Ball) element).Hot!=0){
				this.Destroy();
				((Ball) element).Hot--;
			}
			else{
				GGame.DecreaseLive();
			}
			return;
		}
		
	}

}
