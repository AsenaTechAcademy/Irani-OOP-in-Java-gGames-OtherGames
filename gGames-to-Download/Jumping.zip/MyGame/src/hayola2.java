public class hayola2 extends MoveableBaseClass {

	private int cImage = 0;
	private long waitTime = 200;
	private long lastTime = 0;
	protected int destroyedScore = 0;

	public hayola2(int x, int y) {
		super("Images/ma-0.gif", x, y);
		destroyedScore = 150;

		StartMoving();
		
		setSpeedY(0);
		setSpeedX(1);
		StartMoving();
	}

	private void nextImage() {
		
		cImage = (cImage + 1) % 8;
		if(cImage==4)
		{
			Fire(-1);
			Fire(1);
		}
		ChangeImage("Images/ma-" + (cImage) + ".gif");
	}
	@Override
	public  void step() {
		super.step();
		if (lastTime + waitTime < System.currentTimeMillis()) {
			this.nextImage();
			lastTime = System.currentTimeMillis();
		}
		
		if(cImage>3)
			setSpeedX(1);
		else
			setSpeedX(-1);
	}

	public void CollideWith(BaseClass element) {
		if ((element instanceof Fire)) {
			GGame.IncreaseScore(destroyedScore);
			this.Destroy();
			return;
		}
		if (element instanceof Ball) {
			if(((Ball) element).Hot!=0){
				this.Destroy();
				((Ball) element).Hot--;
			}
			else{
				GGame.DecreaseLive();
			}
			return;
		}
		
	}
	private void Fire(int a)
	{

			// Create new Bullet and shoot up from Right and Left
			F b=new F(getX()+28,getY()+31);
			
			if(a==1)
				b.FireRight();
			else{
				b.setXY(getX()-45 ,getY()+31);
				b.FireLeft();
			}
			
			GGame.addNewEntity(b);
		
	}

}

