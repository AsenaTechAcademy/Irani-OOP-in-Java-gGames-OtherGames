
public class heart extends BaseClass{

	private static String Image="Images/Heart-0.gif";
	
	private int cImage = 0;
	private long waitTime = 70;
	private long lastTime = 0;

	public heart(int x, int y) {
		
		super(Image, x, y);
		
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%6;
		ChangeImage("Images/Heart-"+(cImage)+".gif");
	}
	
	@Override
	public void step()
	{
		super.step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(BaseClass element)
	{
		if ((element instanceof Ball))
		{
			GGame.IncreaseLive();
			this.Destroy();
			return;
		}
	
	}
	
}
