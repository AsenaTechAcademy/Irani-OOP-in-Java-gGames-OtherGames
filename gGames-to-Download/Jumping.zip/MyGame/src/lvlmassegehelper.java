import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;


public class lvlmassegehelper extends BaseClass {

	private LevelStatus Levelstatu;
	
	
	private static String Images="Images/sekkeh-12.gif";

	
	
	private int cImage = 0;
	private long waitTime = 150;
	private long lastTime = 0;

	public lvlmassegehelper() {
		
		super(Images,310, 290);
	}
	public void get(LevelStatus Levelstatus){
		Levelstatu=Levelstatus;
	}
	
	private void nextImage(int n)
	{
		if(n==1){
			setXY(310, 290);
			cImage=(cImage+1)%23;
			ChangeImage("Images/tmp-"+(cImage)+".gif");
		}
		if(n==2){
			setXY(325, 325);
			cImage=(cImage+1)%6;
			ChangeImage("Images/next-"+(cImage)+".gif");
		}
		if(n==3)
		{
			setXY(350, 315);
			cImage=(cImage+1)%2;
			ChangeImage("Images/new-"+(cImage)+".gif");
		}
		if(n==4)
		{
			setXY(350, 315);
			cImage=(cImage+1)%5;
			ChangeImage("Images/java-"+(cImage)+".gif");
		}
		if(n==5)
		{
			setXY(350, 315);
			cImage=(cImage+1)%2;
			ChangeImage("Images/care-"+(cImage)+".gif");
		}
	}
	
	@Override
	public void step()
	{
		super.step();

		ShowLevelNotStart( Levelstatu);
		ShowLevelWinned( Levelstatu);
		ShowLevelRuning(Levelstatu);
		Shownewleve(Levelstatu);
		Showgameover(Levelstatu);
		Showloselife(Levelstatu);
		
	}
	private void ShowLevelNotStart(LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelNotStarted)
		{
			if (lastTime+waitTime<System.currentTimeMillis())
			{
				this.nextImage(1);
				lastTime=System.currentTimeMillis();
			}
		}
	}
	
	private void ShowLevelWinned(LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelWined)
		{
			if (lastTime+waitTime<System.currentTimeMillis())
			{
				this.nextImage(2);
				lastTime=System.currentTimeMillis();
			}
		}
	}
	
	private void Shownewleve(LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.newlevel)
		{
			if (lastTime+waitTime<System.currentTimeMillis())
			{
				this.nextImage(3);
				lastTime=System.currentTimeMillis();
			}
		}
	}
	
	private void Showgameover(LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.GameOver)
		{
			if (lastTime+waitTime<System.currentTimeMillis())
			{
				this.nextImage(4);
				lastTime=System.currentTimeMillis();
			}
		}
	}
	
	private void Showloselife(LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_LiveLoss)
		{
			if (lastTime+waitTime<System.currentTimeMillis())
			{
				this.nextImage(5);
				lastTime=System.currentTimeMillis();
			}
		}
	}
	
	private void ShowLevelRuning(LevelStatus Levelstatus){
		if (Levelstatus==LevelStatus.LevelRunning)
		{
			ChangeImage(Images);
		}
	}
}
