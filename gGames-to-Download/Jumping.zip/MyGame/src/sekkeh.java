public class sekkeh extends BaseClass {

	private static String Images[] = { "Images/sekkeh-0.gif", "Images/sekkeh-1.gif", "Images/sekkeh-2.gif", "Images/sekkeh-3.gif", "Images/sekkeh-4.gif" , "Images/sekkeh-5.gif", "Images/sekkeh-6.gif", "Images/sekkeh-7.gif", "Images/sekkeh-8.gif", "Images/sekkeh-9.gif", "Images/sekkeh-10.gif", "Images/sekkeh-11.gif"};
	
	private int cImage = 0;
	private long waitTime = 70;
	private long lastTime = 0;
	protected int destroyedScore=0;

	public sekkeh(int x, int y) {
		
		super(Images[0], x, y);
		destroyedScore =20;
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%12;
		ChangeImage("Images/sekkeh-"+(cImage)+".gif");
	}
	
	@Override
	public void step()
	{
		super.step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(BaseClass element)
	{
		if ((element instanceof Ball))
		{
			GGame.IncreaseScore(destroyedScore);
			SoundStore.get().Play(Sounds.sekkeh);
			this.Destroy();
			return;
		}
	}
	

}
