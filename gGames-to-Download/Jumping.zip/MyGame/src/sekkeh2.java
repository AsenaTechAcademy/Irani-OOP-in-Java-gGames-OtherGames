public class sekkeh2 extends BaseClass {

	
	private int cImage = 0;
	private long waitTime = 70;
	private long lastTime = 0;
	protected int destroyedScore=0;

	public sekkeh2(int x, int y) {
		
		super("Images/Penny-0.gif", x, y);
		destroyedScore =25;
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%13;
		ChangeImage("Images/Penny-"+(cImage)+".gif");
	}
	
	@Override
	public void step()
	{
		super.step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(BaseClass element)
	{
		if ((element instanceof Ball))
		{
			GGame.IncreaseScore(destroyedScore);
			SoundStore.get().Play(Sounds.sekkeh);
			this.Destroy();
			return;
		}
	}
	

}
