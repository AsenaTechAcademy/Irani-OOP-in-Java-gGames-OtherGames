package Game;



import java.applet.AudioClip;
import java.awt.event.KeyEvent;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;


public class Car extends GameMovableElementAdapter {

	private long			waitTime	=10;
	private long			lastTime	=0;
	Sound so=new Sound();
	Sound2 so2=new Sound2();
	Sound3 so3=new Sound3();
	private boolean	isRightFire	=true;
	
	public Car( int x, int y) {
		super("Images/Car2.png",x,y);
		setSpeedX(2);
		setSpeedY(2);
		SetLimits(205, 765, 123, GameConstants.Game_Height-getHeight());
		
	}
	
	public void Reset()
	{
		this.setXY(540 , 480); // set to first status
	}
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			lastTime=System.currentTimeMillis();
		    GGame.IncreaseScore(1);
		    GGame.levelup();
		}

	}
	private void Fire()
	{
		if (GGame.getTotalFires()>0)
		{
			// Create new Bullet and shoot up from Right and Left
			moshak b=new moshak(0 , 0);
			if (isRightFire)
				b.setXY(this.getX()+this.getWidth()-b.getWidth() , this.getY()-b.getHeight()-1);
			else
				b.setXY(this.getX() , this.getY()-b.getHeight()-1);
			isRightFire=!isRightFire;
			
			GGame.addNewEntity(b);
			GGame.DecreaseFires(1);
		 }
		}
	
	private void setmovingDegree(int degree)
	{
		
	}
	
	// need to get Key Events
	
	@Override
	protected void goBack() {
		// TODO Auto-generated method stub
		super.goBack();
	}
    public void CollideWith(GameElementAdapter element){
    	if ((element instanceof Cars))
		{
    		goBack();
    		
		}
    	if((element instanceof Cars))
    	{
    		so.playBBounce();
    		GGame.DecreaseLive();
    		Reset();
    	}

    }
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_SPACE)
			{so2.playBBounce();Fire();}
		if (e.getKeyCode()==KeyEvent.VK_LEFT||e.getKeyCode()==KeyEvent.VK_RIGHT||
			e.getKeyCode()==KeyEvent.VK_UP||e.getKeyCode()==KeyEvent.VK_DOWN)
			{so3.playBBounce();StopMoving();}
		
	}
	
	public void KeyPressed(KeyEvent e)
	{
		
		
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			setSpeedX(2);
			setSpeedY(0);
			StartMoving();
			setLeftDirection();
			
		}
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			setSpeedX(2);
			setSpeedY(0);
			StartMoving();
			setRightDirection();
		}
		if(e.getKeyCode()==KeyEvent.VK_UP)
		{
			setSpeedX(0);
			setSpeedY(2);
			StartMoving();
			setUpDirection();
		}
		if(e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			setSpeedX(0);
			setSpeedY(2);
			StartMoving();
			setDownDirection();
		}
	}


	public static class Sound
	{
	   AudioClip clip;
	   
	   protected void playBBounce()
	   {
	      try
	      {
	         URL url = this.getClass().getClassLoader().getResource("Sound/Hit_4.wav");
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      }
	      catch(Exception e) { 
	            System.out.println(e); 
	            e.printStackTrace();
	        }
	    }
	   
	}
	
	public static class Sound2
	{
	   AudioClip clip;
	   
	   protected void playBBounce()
	   {
	      try
	      {
	         URL url = this.getClass().getClassLoader().getResource("Sound/Fire.wav");
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      }
	      catch(Exception e) { 
	            System.out.println(e); 
	            e.printStackTrace();
	        }
	    }
	   
	}
	
	public static class Sound3
	{
	   AudioClip clip;
	   
	   protected void playBBounce()
	   {
	      try
	      {
	         URL url = this.getClass().getClassLoader().getResource("Sound/Engine_Traffic.wav");
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      }
	      catch(Exception e) { 
	            System.out.println(e); 
	            e.printStackTrace();
	        }
	    }
	   
	}
	
}
