package Game;


public class Cars extends GameMovableElementAdapter{
	
	private long			waitTime	=550;
	private long			lastTime	=0;
	int wait=0;
	public Cars(int z,int x,int y,int w,int g)
	{
		super("Images/Car"+z+".png", x, y);
		setSpeedY(g);
		setSpeedX(0);
		setDownDirection();
		StopMoving();
		wait=w;
	}
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			lastTime=System.currentTimeMillis();
			wait+=1;
		}
		if(wait==500)
		{
			StartMoving();
		}
	}
	protected void CollideDownBorder()
	{
		super.CollideDownBorder();
		this.Destroy();
	}
	public void CollideWith(GameElementAdapter element){
    	if ((element instanceof Car)||(element instanceof moshak)||(element instanceof rocket))
		{
    		this.Destroy();
		}
    }

}
