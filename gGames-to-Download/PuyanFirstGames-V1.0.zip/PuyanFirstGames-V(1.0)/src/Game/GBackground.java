package Game;

import java.applet.AudioClip;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class GBackground extends GameMovableElementAdapter
{
	private int				cImage		=0;
	private long			waitTime	=150;
	private long			lastTime	=0;
	
	public GBackground(int x , int y )
	{
		super("Images/Road1.png", x , y);

	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/Road"+(cImage+1)+".png");
		
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	public static class Sound
	{
	   AudioClip clip;
	   
	   protected void playBBounce()
	   {
	      try
	      {
	         URL url = this.getClass().getClassLoader().getResource("Sound/theme5.wav");
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      }
	      catch(Exception e) { 
	            System.out.println(e); 
	            e.printStackTrace();
	        }
	    }
	   protected void stop()
	   {
		   clip.stop();
	   }
	   
	}
}
