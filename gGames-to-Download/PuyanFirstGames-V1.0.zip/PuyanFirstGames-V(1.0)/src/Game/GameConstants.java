package Game;
public class GameConstants
{
	public final static int	Game_Width	=1024;
	public final static int	Game_Height	=768;
}
