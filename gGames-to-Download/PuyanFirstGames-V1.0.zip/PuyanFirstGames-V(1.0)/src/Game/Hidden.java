package Game;

public class Hidden extends GameElementAdapter{
	
	public Hidden(int x,int y)
	{
		super("Images/Hidden.png",x,y);
	}
}
