package Game;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;


public class LevelMessages
{
	static Sprite dr;
	static Sprite dr2;
	static Sprite dr3;
	static Sprite dr4;
	static Sound so=new Sound();
	
	public static void ShowLevelMessages(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		ShowScoreBoard(currentPlayer , graphics , Levelstatus);
		ShowLevelNotStarted(currentPlayer , graphics , Levelstatus);
		ShowLossLive(currentPlayer , graphics , Levelstatus);
		ShowGameOver(currentPlayer , graphics , Levelstatus);
		ShowLevelWinned(currentPlayer , graphics , Levelstatus);
		ShowMenu(currentPlayer , graphics , Levelstatus);
	}
	
	private static void ShowMenu(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_Player)
		{
			dr=SpriteStore.get().getSprite("Images/Road1stop.png");
			dr.draw(graphics,0,0);
			/*graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Game Stop" , 320 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 16));
			graphics.drawString("press  ESC to exit game" , 310 , 440);
			graphics.drawString("press  Ctrl  to resume game" , 310 , 453);
			*/
		}
	}
	
	private static void ShowScoreBoard(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		graphics.setColor(Color.WHITE);
		graphics.setFont(new Font("Arial" , Font.CENTER_BASELINE , 16));
		graphics.drawString("Level: "+currentPlayer.getCurrentLevel() , 210 , 55);
		graphics.drawString("Lives: "+currentPlayer.getLives() , 760 , 55);
		graphics.drawString("Score: "+currentPlayer.getScore() , 210 , 75);
		graphics.drawString("Fires: "+currentPlayer.getFires() , 760 , 75);
		graphics.drawString("Time: "+currentPlayer.getCurrentTime() , 480 , 55);
		graphics.drawString("Salam  "+currentPlayer.getPlayerName()+", " , 480 , 75);
	}
	
	private static void ShowLevelNotStarted(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		
		if (Levelstatus==LevelStatus.LevelNotStarted)
		{
			dr2=SpriteStore.get().getSprite("Images/Gameplay.png");
			dr2.draw(graphics,0,0);
			/*graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Welcome to GGames.Paraniod" , 190 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Salaam "+currentPlayer.getPlayerName()
					+", Press CTRL to start the game" , 200 , 440);*/
		}
	}
	
	
	private static void ShowGameOver(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.GameOver)
		{
			dr4=SpriteStore.get().getSprite("Images/gameover.png");
			dr4.draw(graphics,0,0);
			/*graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Game Over, Looser !" , 230 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to exit" , 310 , 440);*/
		}
	}
	
	private static void ShowLossLive(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_LiveLoss)
		{
			dr3=SpriteStore.get().getSprite("Images/Livelose.png");
			dr3.draw(graphics,0,0);
			/*graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Be careful !!" , 300 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to continue" , 310 , 440);*/
		}
	}
	
	private static void ShowLevelWinned(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelWined)
		{
			graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("OK, Level Complete" , 250 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to next level" , 310 , 440);
		}
	}

		
	
	public static class Sound
	{
	   AudioClip clip;
	   
	   protected void playBBounce()
	   {
	      try
	      {
	         URL url = this.getClass().getClassLoader().getResource("Sound/theme5.wav");
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      }
	      catch(Exception e) { 
	            System.out.println(e); 
	            e.printStackTrace();
	        }
	    }
	   
	}
	
}
