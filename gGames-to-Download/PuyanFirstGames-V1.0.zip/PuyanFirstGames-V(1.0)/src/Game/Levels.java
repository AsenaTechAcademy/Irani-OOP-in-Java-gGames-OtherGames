package Game;
public abstract class Levels
{
	public static final int	FinalLevel	=5;
	
	public static void SetLevel(GGame game , int level)
	{
		if (level==1)
		{
			// configs of Level 1
			PlayerInfo p=new PlayerInfo();
			p.setLives(3);
			p.setFires(50);
			p.setScore(0);
			p.setPlayerName("Puyan Tabrizi");
			p.setCurrentLevel(1);
			
			game.setPlayerInfo(p);
			LoadMap(game , 1);
		}
		if (level==2)
		{
			// configs of Level 2
			PlayerInfo p=new PlayerInfo();
			p.setLives(3);
			p.setFires(70);
			p.setScore(2000);
			p.setPlayerName("Puyan Tabrizi");
			p.setCurrentLevel(2);
			
			game.setPlayerInfo(p);
			LoadMap(game , 2);
		}
		if (level==3)
		{
			// configs of Level 3
			PlayerInfo p=new PlayerInfo();
			p.setLives(3);
			p.setFires(100);
			p.setScore(2500);
			p.setPlayerName("Puyan Tabrizi");
			p.setCurrentLevel(3);
			
			game.setPlayerInfo(p);
			LoadMap(game , 3);
		}

		
		else if (level<=FinalLevel)
		{
			PlayerInfo p=game.getPlayerInfo();
			p.setCurrentLevel(p.getCurrentLevel()+1);
			game.setPlayerInfo(p);
			LoadMap(game , level);
		}
		
	}
	
	private static void LoadMap(GGame game , int level)
	{
		if (level==1)
			LoadMap1(game);
		if (level==2)
			LoadMap2(game);
		if (level==3)
			LoadMap3(game);
		if (level==4)
			LoadMap4(game);
		if (level==5)
			LoadMap5(game);
		
	}
	
	
	private static void LoadMap1(GGame game)
	{
		game.clearEntities();
		
		// Static parts
		
		game.setNextEntity(new GBackground(0 , 0 ));
		game.setNextEntity(new Car(540 , 480));
		
		//other Elements
		game.setNextEntity(new Hidden(212 , 0));
		//Cars
		int i1=1,i2=230,i3=398;
		for(int i=0;i<50;i++)
		{
		game.setNextEntity(new Cars(i1,i2 ,0,i3,1));
		i1++;
		i2+=100;
		i3+=2;
		if(i1>5)
			i1=1;
		if(i2>710)
			i2=230;
		}
		int i12=1,i22=710,i32=398;
		for(int i=0;i<50;i++)
		{
		game.setNextEntity(new Cars(i12,i22 ,0,i32,2));
		i12++;
		i22-=100;
		i32+=2;
		if(i12>5)
			i12=1;
		if(i22<230)
			i22=710;
		}
		game.setNextEntity(new emtiaz(230 ,0,30));
		game.setNextEntity(new emtiaz(710 ,0,28));
		game.setNextEntity(new emtiaz(410 ,0,20));
		game.setNextEntity(new emtiaz(520 ,0,10));
		game.setNextEntity(new Mane(220 ,0,28));
		game.setNextEntity(new Mane(720 ,0,22));
		game.setNextEntity(new Mane(340 ,0,12));
		game.setNextEntity(new Mane(560 ,0,6));
		
		for(int i=0;i<22;i++)
		{game.setNextEntity(new Hidden(212 , 0));}
		
		
		
		
		//Hidden
		

	}
	
	private static void LoadMap2(GGame game)
	{
		game.clearEntities();
		game.setNextEntity(new GBackground(0 , 0 ));
		game.setNextEntity(new rocket(520 , 480));
		
		//other Elements
		game.setNextEntity(new Hidden(212 , 0));
		//Cars
		int i1=1,i2=230,i3=398;
		for(int i=0;i<50;i++)
		{
		game.setNextEntity(new Cars(i1,i2 ,0,i3,2));
		i1++;
		i2+=135;
		i3+=2;
		if(i1>5)
			i1=1;
		if(i2>710)
			i2=230;
		}
		int i12=1,i22=710,i32=398;
		for(int i=0;i<50;i++)
		{
		game.setNextEntity(new Cars(i12,i22 ,0,i32,3));
		i12++;
		i22-=100;
		i32+=2;
		if(i12>5)
			i12=1;
		if(i22<230)
			i22=710;
		}
		game.setNextEntity(new emtiaz(230 ,0,30));
		game.setNextEntity(new emtiaz(710 ,0,28));
		game.setNextEntity(new emtiaz(410 ,0,20));
		game.setNextEntity(new emtiaz(520 ,0,10));
		game.setNextEntity(new Mane(220 ,0,28));
		game.setNextEntity(new Mane(720 ,0,22));
		game.setNextEntity(new Mane(340 ,0,12));
		game.setNextEntity(new Mane(560 ,0,6));
		
		for(int i=0;i<22;i++)
		{game.setNextEntity(new Hidden(212 , 0));}
		
		
		
	}
	
	
	private static void LoadMap3(GGame game)
	{
		game.clearEntities();
		game.setNextEntity(new GBackground(0 , 0 ));
		game.setNextEntity(new Car(540 , 480));
		
		//other Elements
		game.setNextEntity(new Hidden(212 , 0));
		//Cars
		int i1=1,i2=230,i3=298;
		for(int i=0;i<100;i++)
		{
		game.setNextEntity(new Cars(i1,i2 ,0,i3,3));
		i1++;
		i2+=160;
		i3+=2;
		if(i1>5)
			i1=1;
		if(i2>710)
			i2=230;
		}
		int i12=1,i22=710,i32=298;
		for(int i=0;i<50;i++)
		{
		game.setNextEntity(new Cars(i12,i22 ,0,i32,5));
		i12++;
		i22-=100;
		i32+=2;
		if(i12>5)
			i12=1;
		if(i22<230)
			i22=710;
		}
		game.setNextEntity(new emtiaz(230 ,0,30));
		game.setNextEntity(new emtiaz(710 ,0,28));
		game.setNextEntity(new emtiaz(410 ,0,20));
		game.setNextEntity(new emtiaz(520 ,0,10));
		game.setNextEntity(new Mane(220 ,0,28));
		game.setNextEntity(new Mane(720 ,0,22));
		game.setNextEntity(new Mane(340 ,0,12));
		game.setNextEntity(new Mane(560 ,0,6));
		
		for(int i=0;i<22;i++)
		{game.setNextEntity(new Hidden(212 , 0));}
		

		
	
	}
	
	
	private static void LoadMap4(GGame game)
	{
		game.clearEntities();
		// Static elements
		//game.setNextEntity(new GBackground(0 , 0 , 3));
		
		
	}

	private static void LoadMap5(GGame game)
	{
		game.clearEntities();
		// Static parts
	//	game.setNextEntity(new GBackground(0 , 0 , 3));
		game.setNextEntity(new Car(500 , 450));
	//	game.setNextEntity(new GBall(365 , 540));
		
	
	}
}
