package Game;
public class Main
{
	public static void main(String[] args)
	{
		int curLevel=1;
		LevelStatus gamestatus=LevelStatus.waitNextLevel;
		GBackground.Sound so=new GBackground.Sound();
		
		//SoundStores.get().LoadSounds();
		so.playBBounce();
		GGame game=new GGame();
		//so.stop();
		while (gamestatus==LevelStatus.waitNextLevel&&curLevel<=Levels.FinalLevel)
		{
			
			Levels.SetLevel(game , curLevel++);
			
			game.Game_Start();
			gamestatus=game.Game_Loop();
			
			if (gamestatus==LevelStatus.waitGameOver)
				System.exit(0);
		}
		
		if (gamestatus==LevelStatus.waitNextLevel&&curLevel==Levels.FinalLevel+1)
			System.out.print("You Complete this GAME...");
		
		System.exit(0);
		
	}// end of main
}
