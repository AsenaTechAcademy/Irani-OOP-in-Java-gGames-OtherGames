package Game;

public class Mane extends GameMovableElementAdapter {
	private long			waitTime	=550;
	private long			lastTime	=0;
	int wait=0;
	public Mane(int x,int y,int w)
	{
		super("Images/Roadblock.gif", x, y);
		setSpeedY(1);
		setSpeedX(0);
		setDownDirection();
		StopMoving();
		wait=w;
	}
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			lastTime=System.currentTimeMillis();
			wait+=1;
		}
		if(wait==33)
		{
			StartMoving();
		}
	}
	protected void CollideDownBorder()
	{
		super.CollideDownBorder();
		this.Destroy();
	}
	public void CollideWith(GameElementAdapter element){
    	if ((element instanceof Car)||(element instanceof rocket))
		{
    		GGame.DecreaseFires(5);
    		Destroy();
    		
		}
    }
}