package Game;

import java.applet.AudioClip;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class emtiaz extends GameMovableElementAdapter {
	private long			waitTime	=550;
	private long			lastTime	=0;
	int wait=0;
	public emtiaz(int x,int y,int w)
	{
		super("Images/del.gif", x, y);
		setSpeedY(1);
		setSpeedX(0);
		setDownDirection();
		StopMoving();
		wait=w;
	}
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			lastTime=System.currentTimeMillis();
			wait+=1;
		}
		if(wait==33)
		{
			StartMoving();
		}
	}
	protected void CollideDownBorder()
	{
		super.CollideDownBorder();
		this.Destroy();
	}
	public void CollideWith(GameElementAdapter element){
    	if ((element instanceof Car)||(element instanceof rocket))
		{
    		GGame.IncreaseLive();
    		Destroy();
    		
		}
    }
	public class Sound
	{
	   AudioClip clip;
	   
	   protected void playBBounce()
	   {
	      try
	      {
	         URL url = this.getClass().getClassLoader().getResource("Sound/Hit_4.wav");
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      }
	      catch(Exception e) { 
	            System.out.println(e); 
	            e.printStackTrace();
	        }
	    }
	   
	}
}
