package Game;


public class moshak extends GameMovableElementAdapter
{
	
	public moshak(int x , int y)
	{
		super("Images/moshak.gif" , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(3);
		this.setUpDirection();
		this.StartMoving();
	}
	
	protected void CollideUpBorder()
	{
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		this.Destroy();
	}
}
