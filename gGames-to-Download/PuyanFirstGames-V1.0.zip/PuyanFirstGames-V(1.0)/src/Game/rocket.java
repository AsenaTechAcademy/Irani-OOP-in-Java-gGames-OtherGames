package Game;



import java.applet.AudioClip;
import java.awt.event.KeyEvent;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import Game.Car.Sound;

public class rocket extends GameMovableElementAdapter{
	
	Car.Sound so=new Car.Sound();
	Car.Sound2 so1=new Car.Sound2();
	Sound3 so2=new Sound3();
	private long			waitTime	=100;
	private long			lastTime	=0;
	private boolean	isRightFire	=true;
	
	private int				cImage		=0;
	public rocket( int x, int y)
	{
		super("Images/Blue_rocket1.png",x,y);
		setSpeedX(2);
		setSpeedY(2);
		SetLimits(205, 765, 123, GameConstants.Game_Height-getHeight());
	}
	
	
	public void Reset()
	{
		this.setXY(520 , 480); // set to first status
	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/Blue_rocket"+(cImage+1)+".png");
		
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			lastTime=System.currentTimeMillis();
			this.nextImage();
		    GGame.IncreaseScore(1);
		    GGame.levelup();
		}

	}
	
	
	protected void goBack() {
		// TODO Auto-generated method stub
		super.goBack();
	}
    public void CollideWith(GameElementAdapter element){
    	if ((element instanceof Cars))
		{
    		goBack();
    		
		}
    	if((element instanceof Cars))
    	{
    		so.playBBounce();
    		GGame.DecreaseLive();
    		Reset();
    	}

    }
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_SPACE)
			{so1.playBBounce();Fire();}
		
		if (e.getKeyCode()==KeyEvent.VK_LEFT||e.getKeyCode()==KeyEvent.VK_RIGHT||
			e.getKeyCode()==KeyEvent.VK_UP||e.getKeyCode()==KeyEvent.VK_DOWN)
			{so2.playBBounce();StopMoving();}
		
	}
	
	public void KeyPressed(KeyEvent e)
	{
		
		
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			setSpeedX(2);
			setSpeedY(0);
			StartMoving();
			setLeftDirection();
			
		}
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			setSpeedX(2);
			setSpeedY(0);
			StartMoving();
			setRightDirection();
		}
		if(e.getKeyCode()==KeyEvent.VK_UP)
		{
			setSpeedX(0);
			setSpeedY(2);
			StartMoving();
			setUpDirection();
		}
		if(e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			setSpeedX(0);
			setSpeedY(2);
			StartMoving();
			setDownDirection();
		}
	}

	private void Fire()
	{
		if (GGame.getTotalFires()>0)
		{
			// Create new Bullet and shoot up from Right and Left
			moshak b=new moshak(0 , 0);
			if (isRightFire)
				b.setXY(this.getX()+this.getWidth()-b.getWidth() , this.getY()-b.getHeight()-1);
			else
				b.setXY(this.getX() , this.getY()-b.getHeight()-1);
			isRightFire=!isRightFire;
			
			GGame.addNewEntity(b);
			GGame.DecreaseFires(1);
			
		}
	}
	
	public static class Sound3
	{
	   AudioClip clip;
	   
	   protected void playBBounce()
	   {
	      try
	      {
	         URL url = this.getClass().getClassLoader().getResource("Sound/Engine_06High.wav");
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      }
	      catch(Exception e) { 
	            System.out.println(e); 
	            e.printStackTrace();
	        }
	    }
	   
	}

}
