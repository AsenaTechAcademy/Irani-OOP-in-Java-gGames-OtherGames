import java.awt.event.KeyEvent;

public class GBackground extends GameMovableElementAdapter
{
	int xpos;
	int ypos;
	public GBackground(int x , int y , int type)
	{
		super("Images/baaa"+type+".jpg" , x , y);
		setSpeedY(0);
		setSpeedX(2);
		
		StopMoving();
	}
	
}
//mahdi1994622