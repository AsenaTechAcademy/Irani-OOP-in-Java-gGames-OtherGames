import java.awt.DisplayMode;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class GGame {
	private static PlayerInfo  CurrentPlayer;
	private static Multilife  mhero;
	private static LevelStatus Levelstatus=LevelStatus.LevelNotStarted;
	private JFrame frmmain;
	private JPanel a;
	private BufferStrategy				buffer;
	Graphics							graphics;
	private static GameElementAdapter	Entities[]	=new GameElementAdapter[10000];
	private static int	
	cEntities	=0;
	private static long timer=1200;
	
	
	public GGame()
	{
		GraphicsEnvironment genv=GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice device=genv.getDefaultScreenDevice();
		GraphicsConfiguration gc=device.getDefaultConfiguration();
		frmmain=new JFrame(gc);
		frmmain.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmmain.setUndecorated(true);
		frmmain.setResizable(false);
		frmmain.setLayout(null);
		frmmain.setIgnoreRepaint(true);
		device.setFullScreenWindow(frmmain);
		device.setDisplayMode(new DisplayMode(GameConstants.Window_Width , GameConstants.Window_Height ,
				32 , 0));
		frmmain.createBufferStrategy(2);
		buffer=frmmain.getBufferStrategy();
		
		frmmain.requestFocus();
		frmmain.addKeyListener(new KeyHandler());
		frmmain.addMouseMotionListener(new MouseMotionHandler());
		frmmain.addMouseListener(new MouseHandler());
	
		
	}// end of constructor
	public void setPlayerInfo(PlayerInfo p)
	{
		CurrentPlayer=new PlayerInfo(p);
	}
	
	public PlayerInfo getPlayerInfo()
	{
		return CurrentPlayer;
	}
	public void setInfo( Multilife  mheroo)
	{
		mhero=new Multilife(mheroo);
	}
	
	public Multilife getInfo()
	{
		return mhero;
	}
	
	public static void IncreaseFires(int fires)
	{
		CurrentPlayer.setFires(CurrentPlayer.getFires()+fires);
	}
	
	public static void DecreaseFires(int fires)
	{
		CurrentPlayer.setFires(CurrentPlayer.getFires()-fires);
	}
	
	public static int getTotalFires()
	{
		return CurrentPlayer.getFires();
	}
	public static int gFires()
	{
		return mhero.getFires();
	}
	public static int getczombi()
	{
		return mhero.getczombie();
	}
	public static void setczombi(int i)
	{
		mhero.setczombi(mhero.getczombie()+1);
	}
	
	
	public static void IncreaseScore(int score)
	{
		CurrentPlayer.setScore(CurrentPlayer.getScore()+score);
		if (score>0)
			SoundStore.get().Play(Sounds.Score);
	}
	
	public static void IncreaseLive()
	{
		if(CurrentPlayer.getLives()<10)
		CurrentPlayer.setLives(CurrentPlayer.getLives()+1);
	}
	
	public static void DLive()
	{
		
			mhero.setLives(mhero.getLives()-1);
			
		
	}
	public static void DecreaseLive()
	{
		if (CurrentPlayer.getLives()==1)
			Levelstatus=LevelStatus.GameOver;
		else
		{
			CurrentPlayer.setLives(CurrentPlayer.getLives()-1);
			if (CurrentPlayer.getLives()<3){
			Levelstatus=LevelStatus.LevelStop_LiveLoss;}
			((Ghero) Entities[5]).Reset(); // Reset hero to first status
		}
	}
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Add Entities
		public void setNextEntity(GameElementAdapter element)
		{
			element.setID(cEntities);
			Entities[cEntities++]=element;
		}
		
		public static void addNewEntity(GameElementAdapter element)
		{
			element.setID(cEntities);
			Entities[cEntities++]=element;
			// Maybe we do something in the future
		}
		
		public void clearEntities()
		{
			cEntities=0;
		}
		
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Game Start
	
	public void Game_Start() {
		Levelstatus=LevelStatus.LevelNotStarted;
		CurrentPlayer.setStartTime(System.currentTimeMillis());
		
	}
	public LevelStatus Game_Loop() {
		while (true)
		{
			
			graphics=buffer.getDrawGraphics();
			
			if(timer==1200)
			{
				SoundStore.get().Play(Sounds.gamesound);
				timer=0;
			}
			else
				timer++;
			
			if (mhero.getLives()==0){
				Levelstatus=LevelStatus.LevelWined;
			}
			// Step of All Entities
			if (Levelstatus==LevelStatus.LevelRunning)
			{
				for (int i=0 ; i<cEntities ; i++)
					Entities[i].Step();
				CheckCollisions();
				CurrentPlayer.setCurrentTime((System.currentTimeMillis()-CurrentPlayer
						.getStartTime())/1000);
			}
			
			// Draw ALL current entities in any condition of game
			for (int i=0 ; i<cEntities ; i++)
				Entities[i].draw(graphics);
			
			// Message of Game
			LevelMessages.ShowLevelMessages(CurrentPlayer , graphics , Levelstatus);
			
			buffer.show();
			graphics.dispose();
			
			if ((Levelstatus==LevelStatus.waitNextLevel)||(Levelstatus==LevelStatus.waitGameOver))
				return Levelstatus;
		}// End of While(true)
	}
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Collisions
		private void CheckCollisions()
		{
			// Check collision of all moving elements with static elements
			for (int mm=1 ; mm<cEntities ; mm++)
			{
				for (int i=mm+1 ; i<cEntities ; i++)
				{
					GameElementAdapter me=(GameElementAdapter) Entities[mm];
					GameElementAdapter him=(GameElementAdapter) Entities[i];
					
					if (me.Contains(him))
					{
						me.CollideWith(him);
						him.CollideWith(me);
					}
				}
			}
		} // end of method check collisions
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Death Notify
		public static void NotifyDeath(GameElementAdapter element)
		{
			Entities[cEntities-1].setID(element.getID());
			Entities[element.getID()]=Entities[--cEntities];
		}
		
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Mouse Adapter
		private class MouseMotionHandler extends MouseMotionAdapter
		{
			public void mouseMoved(MouseEvent e)
			{
				// Say to all entities
			}
		}
		
		private class MouseHandler extends MouseAdapter
		{
			public void mouseClicked(MouseEvent e)
			{
				// Say to all entities
			}
		}
		
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ key Adapter
		private class KeyHandler extends KeyAdapter
		{
			public void keyPressed(KeyEvent e)
			{
				if (Levelstatus==LevelStatus.LevelRunning)
				{
					// say to all elements that a key Pressed
					for (int i=0 ; i<cEntities ; i++)
						if (Entities[i].WantKeyEvents())
							Entities[i].KeyPressed(e);
					return;
				}
			}
			
			public void keyReleased(KeyEvent e)
			{
				if (e.getKeyCode()==KeyEvent.VK_ESCAPE)
				{
					if (Levelstatus==LevelStatus.LevelStop_Player)
						Levelstatus=LevelStatus.waitGameOver;
					if (Levelstatus==LevelStatus.LevelRunning)
						Levelstatus=LevelStatus.LevelStop_Player;
					return;
				}
				if (e.getKeyCode()==KeyEvent.VK_CONTROL)
				{
					if (Levelstatus==LevelStatus.GameOver)
						Levelstatus=LevelStatus.waitGameOver;
					if ((Levelstatus==LevelStatus.LevelWined))
						Levelstatus=LevelStatus.waitNextLevel;
					if (Levelstatus==LevelStatus.LevelNotStarted
							||Levelstatus==LevelStatus.LevelStop_LiveLoss
							||Levelstatus==LevelStatus.LevelStop_Player)
						Levelstatus=LevelStatus.LevelRunning;
					return;
				}
				
				if ((Levelstatus==LevelStatus.LevelRunning)
						||(Levelstatus==LevelStatus.LevelStop_LiveLoss))
				{
					// say to all elements that a key Released
					for (int i=0 ; i<cEntities ; i++)
						if (Entities[i].WantKeyEvents())
							Entities[i].KeyReleased(e);
				}
			}
			
		}// End of Key Adapter

}
