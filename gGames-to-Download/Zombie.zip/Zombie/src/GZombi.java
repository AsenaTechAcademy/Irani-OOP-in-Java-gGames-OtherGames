public class GZombi extends GameMovableElementAdapter
{
	
	private static String	Images[]	= { "Images/Evil31.png", "Images/Evil32.png",
			"Images/Evil33.png", "Images/Evil34.png", "Images/Evil35.png","Images/Evil36.png","Images/Evil37.png","Images/Evil38.png","Images/Evil39.png","Images/Evil40.png"
			,"Images/Evil41.png","Images/Evil42.png","Images/Evil43.png","Images/Evil44.png","Images/Evil45.png","Images/Evil46.png","Images/Evil47.png"};
	private int				cImage		=0;
	private long			waitTime	=70;
	private long			lastTime	=0;
	
	public GZombi(int x , int y)
	{
		super(Images[0] , x , y);
		destroyedScore=100;
		
		setSpeedY(0);
		setSpeedX(1);
		setLeftDirection();
		StartMoving();
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%5;
		ChangeImage("Images/Evil"+(cImage+31)+".png");
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			this.Destroy();
			GGame.IncreaseScore(destroyedScore);
			//SoundStore.get().Play(Sounds.Dog);
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		if (element instanceof LBullet)
		{
			this.Destroy();
			GGame.IncreaseScore(destroyedScore);
			//SoundStore.get().Play(Sounds.Dog);
			return;
		}
		if (element instanceof Ghero)
		{
			
			ChangeImage("Images/Evil"+(cImage+41)+".png");
			return;
		}
		if (element instanceof GZombi)
		{
			return;
		}
		if (element instanceof tree1)
		{
		return;
		}
		if (element instanceof moon)
		{
		return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof cloud1)
		{
			
			
			
			return;
		}
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		if (element instanceof Ammo)
		{
			
			return;
		}
		if (element instanceof woodenbox)
		{
			
			return;
		}
		if (element instanceof Glife)
		{
			
			return;
		}
		// to collide with other elements
		element.Destroy();
	}
	
	protected void CollideLeftBorder()
	{
		GGame.DecreaseLive();
		super.CollideLeftBorder();
		this.Destroy();
	}
}
