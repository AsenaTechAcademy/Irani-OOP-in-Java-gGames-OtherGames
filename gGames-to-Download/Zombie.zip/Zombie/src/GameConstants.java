
public class GameConstants {

	public static final int Game_Width = 10204	;
	public static final int Game_Height = 768;
	public static final int Window_Height = 768;
	public static final int Window_Width = 1024	;
}
