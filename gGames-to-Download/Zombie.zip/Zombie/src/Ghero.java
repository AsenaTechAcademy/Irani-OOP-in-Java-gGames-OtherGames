import java.awt.event.KeyEvent;


public class Ghero extends GameMovableElementAdapter {
	private static String	Images[]	= { "Images/walk1.png", "Images/walk2.png",
		"Images/walk3.png", "Images/walk4.png", "Images/walk5.png","Images/walk6.png" ,"Images/still3.png","Images/bm1.png","Images/bm2.png",
		"Images/bm3.png","Images/bm4.png","Images/bm5.png","Images/bm6.png","Images/run1.png","Images/run2.png","Images/run3.png","Images/run4.png","Images/run5.png","Images/run6.png"
		,"Images/brun1.png","Images/brun2.png","Images/brun3.png","Images/brun4.png","Images/brun5.png","Images/brun6.png"};
	private int				cImage		=0;
	private long			waitTime	=70;
	private long			lastTime	=0;
	private  LevelStatus Levelstatus;
	private boolean	isRightFire	=true;
	public Ghero(int x , int y)
	{
		super(Images[0] , x , y);
		
		setSpeedY(0);
		setSpeedX(0);
		setRightDirection();
		StopMoving();
	
	}
	public void limit(){
		if(this.getY()==400||this.getX()==-400){
			StopMoving();
			setSpeedY(0);
			setSpeedX(0);
		}
	}
	public void Reset()
	{
		this.setXY(getX()-50 , getY()); // set to first status
	}
	public boolean WantKeyEvents()
	{
		return true;
	}
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
			{ChangeImage("Images/still"+(3)+".png");
			StopMoving();}
		if (e.getKeyCode()==KeyEvent.VK_D)
		{ChangeImage("Images/still"+(3)+".png");
		StopMoving();}
		if(e.getKeyCode()==KeyEvent.VK_LEFT){
			ChangeImage("Images/bms"+(3)+".png");
			StopMoving();
		}
		if(e.getKeyCode()==KeyEvent.VK_A){
			ChangeImage("Images/bms"+(3)+".png");
			StopMoving();
		}
	}
	public void KeyPressed(KeyEvent e)
	{
		
		if (e.getKeyCode()==KeyEvent.VK_SPACE)
			Fire();
		if (e.getKeyCode()==KeyEvent.VK_ENTER)
			LFire();
		
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			setSpeedY(0);
			setSpeedX(1);
			cImage=(cImage+1)%5;
			ChangeImage("Images/walk"+(cImage+1)+".png");
			StartMoving();
			setRightDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_D)
		{
			setSpeedY(0);
			setSpeedX(0);
			cImage=(cImage+1)%5;
			ChangeImage("Images/run"+(cImage+1)+".png");
			StartMoving();
			setRightDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_A)
		{
			setSpeedY(0);
			setSpeedX(0);
			cImage=(cImage+1)%5;
			ChangeImage("Images/brun"+(cImage+1)+".png");
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			
			setSpeedY(0);
			setSpeedX(1);
			cImage=(cImage+1)%5;
			ChangeImage("Images/bm"+(cImage+1)+".png");
			StartMoving();
			setLeftDirection();
		
		}
		if (e.getKeyCode()==KeyEvent.VK_UP)
		{
			if(getY()>500){
			setUpDirection();
			up();}
		}
		if (e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			//StartMoving();
			Down();
		}
		if (e.getKeyCode()==KeyEvent.VK_SHIFT)
		{
			Fly();
			
		}
		
	}
	private void win(){
		
	}
	private void Fire() {
		if (GGame.getTotalFires()>0)
		{
			
			RBullet b=new RBullet(0 , 0);
				b.setXY(this.getX()+this.getWidth()-b.getWidth()+20 , this.getY()-b.getHeight()+30);
				
			
			GGame.addNewEntity(b);
			
			GGame.DecreaseFires(1);
			SoundStore.get().Play(Sounds.Fire);
		}
		
	}
	private void LFire() {
		if (GGame.getTotalFires()>0)
		{
			
			
			LBullet c=new LBullet(0, 0);
				
				c.setXY(this.getX()+this.getWidth()-c.getWidth()-20 , this.getY()-c.getHeight());
			
			
			GGame.addNewEntity(c);
			GGame.DecreaseFires(1);
			SoundStore.get().Play(Sounds.Fire);
		}
		
	}
	
	private void nextImage()
	{
		
		
	}
	public void Step()
	{
		super.Step();
		Main.game.getPlayerInfo().setMyX(this.getX());
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	public void CollideWith(GameElementAdapter element)
	{
		if ((element instanceof woodenbox))
		{
			this.StopMoving();
			setSpeedY(0);
			setSpeedX(0);
			return;
			
		}
		if ((element instanceof GZombi))
		{
			GGame.DecreaseLive();
			//this.Destroy();
			
			return;
		}
		if (element instanceof Zombifun)
		{
			GGame.DecreaseLive();
			//this.Destroy();
			return;
		}
		if (element instanceof Mainhero)
		{
			GGame.DecreaseLive();
			return;
		}
		if (element instanceof Gun)
		{
			GGame.DecreaseLive();
			//this.Destroy();
			return;
		}
		if (element instanceof Ammo)
		{
			
			return;
		}
		if (element instanceof woodenbox)
		{
			StopMoving();
			return;
		}
		
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof moon)
		{
			return;
		}
		if (element instanceof cloud1)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			GGame.DecreaseLive();
			//this.Destroy();
			
			return;
		}
		if (element instanceof zBullet)
		{
			GGame.DecreaseLive();
			//this.Destroy();
			
			return;
		}
		// to collide with other elements
		element.Destroy();
	}
	
}
