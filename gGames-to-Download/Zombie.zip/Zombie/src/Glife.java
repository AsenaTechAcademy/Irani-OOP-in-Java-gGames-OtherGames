public class Glife extends GameMovableElementAdapter
{
	
	private static String	Images[]	= { "Images/tmp-1.gif", "Images/tmp-2.gif",
			"Images/tmp-3.gif", "Images/tmp-4.gif", "Images/tmp-5.gif", "Images/tmp-6.gif", "Images/tmp-7.gif"
			, "Images/tmp-8.gif", "Images/tmp-9.gif"};
	private int				cImage		=0;
	private long			waitTime	=50;
	private long			lastTime	=0;
	
	public Glife(int x , int y)
	{
		super(Images[0] , x , y);
		setSpeedX(1);
		setSpeedY(0);
		setLeftDirection();
		StartMoving();
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%6;
		ChangeImage("Images/tmp-"+(cImage+1)+".gif");
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	protected void CollideLeftBorder()
	{
		super.CollideLeftBorder();
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			this.Destroy();
			return;
		}
		if (element instanceof Mainhero)
		{
			return;
		}
		if (element instanceof Ghero)
		{
			GGame.IncreaseLive();
			GGame.IncreaseScore(destroyedScore);
			this.Destroy();
			return;
		}
		if (element instanceof Ammo)
		{
			
			return;
		}
		if (element instanceof woodenbox)
		{
			
			return;
		}
		if (element instanceof Glife)
		{
			
			return;
		}
		
		
		
		
		if (element instanceof LBullet)
		{
			this.Destroy();
			return;
		}
		
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof GZombi)
		{
			
			
			
			return;
		}
		
		if (element instanceof moon)
		{
			return;
		}
		if (element instanceof tree1)
		{
			return;
		}
		
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		if (element instanceof cloud1)
		{	
			return;
		}
		
		// to collide with other elements
		//this.goBack();
		this.StartMoving();
	}
}
