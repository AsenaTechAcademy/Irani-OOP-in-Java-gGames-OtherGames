import java.awt.event.KeyEvent;


public class Gun  extends GameMovableElementAdapter{
	private static String	Images[]	= { "Images/gun1.gif", "Images/gun2.gif"};
	private long			waitTime	=70;
	private long			lastTime	=0;
	
	public Gun( int x, int y) {
		super("Images/gun1.gif" , x , y);	
		setSpeedY(0);
		setSpeedX(6);
		setRightDirection();
		StopMoving();
	}
	public void Reset()
	{
		this.setXY(100 , 700); // set to first status
	}
	public boolean WantKeyEvents()
	{
		return true;
	}
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_UP||e.getKeyCode()==KeyEvent.VK_DOWN||e.getKeyCode()==KeyEvent.VK_RIGHT||e.getKeyCode()==KeyEvent.VK_LEFT)
			StopMoving();
	}
	public void KeyPressed(KeyEvent e)
	{
		
		
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			StartMoving();
			setRightDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_UP)
		{
			setUpDirection();
			up();
		}
		if (e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			//StartMoving();
			Down();
		}
		if (e.getKeyCode()==KeyEvent.VK_SHIFT)
		{
			Fly();
			
		}
		
	}
	
	
	private void nextImage()
	{
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	public void CollideWith(GameElementAdapter element)
	{
		//if ((element instanceof GZombi))
		//{
			//GGame.IncreaseScore(destroyedScore);
			//StartMoving();
			//SoundStore.get().Play(Sounds.Dog);
		//	return;
	//	}
		if (element instanceof Zombifun)
		{
			//GGame.DecreaseLive();
			//this.Destroy();
			return;
		}
		if (element instanceof Ghero)
		{
			//GGame.DecreaseLive();
			//this.Destroy();
			return;
		}
		if (element instanceof GZombi)
		{
			//GGame.DecreaseLive();
			//this.Destroy();
			return;
		}
		if(element instanceof Ammo){
			ChangeImage("Images/gun2.gif");
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		// to collide with other elements
		element.Destroy();
	}
	
	

}
