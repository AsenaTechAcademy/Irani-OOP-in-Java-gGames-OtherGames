public class LBullet extends GameMovableElementAdapter
{
	
	public LBullet(int x , int y)
	{
		super("Images/rfire1.png" , x , y);
		
		this.setSpeedX(3);
		this.setSpeedY(0);
		this.setLeftDirection();
		this.StartMoving();
	}
	
	protected void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.Destroy();
	}
	protected void CollideLeftBorder()
	{
		super.CollideLeftBorder();
		this.Destroy();
	}
	
	
		public void CollideWith(GameElementAdapter element)
		{

			if (element instanceof RBullet)
			{
				
				return;
			}
			if (element instanceof LBullet)
			{
				
				return;
			}
			if (element instanceof Ghero)
			{
				return;
			}
			if (element instanceof Mainhero)
			{
				this.Destroy();
				return;
			}
			if (element instanceof tree1)
			{
				return;
			}
			if (element instanceof GZombi)
			{
				
				this.Destroy();
				
				return;
			}
			if (element instanceof Zombifun)
			{
				this.Destroy();
				return;
			}
			if (element instanceof movablebackground)
			{
				return;
			}
			if (element instanceof WZombi)
			{
				this.Destroy();
				return;
			}
			if (element instanceof cloud1)
			{
				
				
				
				return;
			}
			if (element instanceof moon)
			{
				
				
				
				return;
			}
			
			if (element instanceof woodenbox)
			{
				
				return;
			}
			
			this.Destroy();
		}
		
	}

	

