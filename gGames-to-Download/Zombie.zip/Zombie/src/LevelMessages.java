import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;

import javax.swing.ImageIcon;

public class LevelMessages
{
	
	
	public static void ShowLevelMessages(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		ShowScoreBoard(currentPlayer , graphics , Levelstatus);
		ShowLevelNotStarted(currentPlayer , graphics , Levelstatus);
		ShowLossLive(currentPlayer , graphics , Levelstatus);
		ShowGameOver(currentPlayer , graphics , Levelstatus);
		ShowLevelWinned(currentPlayer , graphics , Levelstatus);
		ShowMenu(currentPlayer , graphics , Levelstatus);
	}
	
	private static void ShowMenu(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelStop_Player)
		{
			graphics.setColor(Color.RED); 
			graphics.fillRect(150 , 380 , 500 , 80);
			
			
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Game Stop" , 320 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("press  ESC to exit game" , 310 , 440);
			graphics.drawString("press  Ctrl  to resume game" , 310 , 453);
		}
	}
	
	private static void ShowScoreBoard(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		graphics.setColor(Color.red);
		graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
		
		URL Lives1 = LevelMessages.class.getResource("Images/live1.gif");
		URL Lives2 = LevelMessages.class.getResource("Images/live2.gif");
		URL Lives3 = LevelMessages.class.getResource("Images/live3.gif");
		URL Lives4 = LevelMessages.class.getResource("Images/live4.gif");
		URL Lives5 = LevelMessages.class.getResource("Images/live5.gif");
		URL Lives6 = LevelMessages.class.getResource("Images/live6.gif");
		URL Lives7 = LevelMessages.class.getResource("Images/live7.gif");
		URL Lives8 = LevelMessages.class.getResource("Images/live8.gif");
		URL Lives9 = LevelMessages.class.getResource("Images/live9.gif");
		URL Lives10 = LevelMessages.class.getResource("Images/live10.gif");
		URL Score = LevelMessages.class.getResource("Images/live10.gif");
		URL Fire = LevelMessages.class.getResource("Images/zombi.jpg");
		URL Time = LevelMessages.class.getResource("Images/zombi.jpg");
		ImageIcon lives1 = new ImageIcon(Lives1);
		Image livess1=lives1.getImage();
		if(currentPlayer.getLives()<=10&&currentPlayer.getLives()>9){
		graphics.drawImage(livess1, 100, 740, 100, 20, null);}
		///////////////////////////////////////////////////////////////
		ImageIcon lives2 = new ImageIcon(Lives2);
		Image livess2=lives2.getImage();
		if(currentPlayer.getLives()<=9&&currentPlayer.getLives()>8){
		graphics.drawImage(livess2, 100, 740, 100, 20, null);}
		////////////////////////////////////////////////////////////////
		ImageIcon lives3 = new ImageIcon(Lives3);
		Image livess3=lives3.getImage();
		if(currentPlayer.getLives()<=8&&currentPlayer.getLives()>7){
		graphics.drawImage(livess3, 100, 740, 100, 20, null);}
		/////////////////////////////////////////////////////////////////
		ImageIcon lives4 = new ImageIcon(Lives4);
		Image livess4=lives4.getImage();
		if(currentPlayer.getLives()<=7&&currentPlayer.getLives()>6){
		graphics.drawImage(livess4, 100, 740, 100, 20, null);}
		////////////////////////////////////////////////////////////////
		ImageIcon lives5 = new ImageIcon(Lives5);
		Image livess5=lives5.getImage();
		if(currentPlayer.getLives()<=6&&currentPlayer.getLives()>5){
		graphics.drawImage(livess5, 100, 740, 100, 20, null);}
		////////////////////////////////////////////////////////////////
		ImageIcon lives6 = new ImageIcon(Lives6);
		Image livess6=lives6.getImage();
		if(currentPlayer.getLives()<=5&&currentPlayer.getLives()>4){
		graphics.drawImage(livess6, 100, 740, 100, 20, null);}
		/////////////////////////////////////////////////////////////////
		ImageIcon lives7 = new ImageIcon(Lives7);
		Image livess7=lives7.getImage();
		if(currentPlayer.getLives()<=4&&currentPlayer.getLives()>3){
		graphics.drawImage(livess7, 100, 740, 100, 20, null);}
		/////////////////////////////////////////////////////////////////
		ImageIcon lives8 = new ImageIcon(Lives8);
		Image livess8=lives8.getImage();
		if(currentPlayer.getLives()<=3&&currentPlayer.getLives()>2){
		graphics.drawImage(livess8, 100, 740, 100, 20, null);}
		//////////////////////////////////////////////////////////////////
		ImageIcon lives9 = new ImageIcon(Lives9);
		Image livess9=lives9.getImage();
		if(currentPlayer.getLives()<=2&&currentPlayer.getLives()>1){
		graphics.drawImage(livess9, 100, 740, 100, 20, null);}
		//////////////////////////////////////////////////////////////////
		ImageIcon lives10 = new ImageIcon(Lives10);
		Image livess10=lives10.getImage();
		if(currentPlayer.getLives()<=1&&currentPlayer.getLives()>=0){
		graphics.drawImage(livess10, 100, 740, 100, 20, null);
		
		}
		//////////////////////////////////////////////////////////////////
		ImageIcon score = new ImageIcon(Score);
		Image scoree=score.getImage();
		//graphics.drawImage(scoree, 0, 0, 1024, 768, null);
		ImageIcon fire = new ImageIcon(Fire);
		Image firee=fire.getImage();
		//graphics.drawImage(firee, 0, 0, 1024, 768, null);
		ImageIcon time = new ImageIcon(Time);
		Image timee=time.getImage();
		//graphics.drawImage(timee, 0, 0, 1024, 768, null);
		graphics.drawString("Level: "+currentPlayer.getCurrentLevel() , 20 , 755);
		//graphics.drawString("="+currentPlayer.getLives() , 180 , 755);
		graphics.drawString("Score: "+currentPlayer.getScore() , 240 , 755);
		graphics.drawString("Fires: "+currentPlayer.getFires() , 350 , 755);
		graphics.drawString("Time: "+currentPlayer.getCurrentTime() , 450 , 755);
		//graphics.drawString("Salaam  "+currentPlayer.getPlayerName()+", " , 420 , 755);
	}
	
	private static void ShowLevelNotStarted(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelNotStarted)
		{
			URL blue = LevelMessages.class.getResource("Images/zombi.jpg");
			graphics.setColor(Color.RED);
			//graphics.fillRect(150 , 380 , 500 , 80);
			ImageIcon ad = new ImageIcon(blue);
			Image add=ad.getImage();
			graphics.drawImage(add, 0, 0, 1024, 768, null);
			graphics.setColor(Color.red);
			graphics.setFont(new Font("Arial" , Font.ITALIC , 35));
			graphics.drawString("Welcome to Zombi Shock Game. " , 145 , 385);
			graphics.setColor(Color.green);
			graphics.setFont(new Font("Arial" , Font.ROMAN_BASELINE , 20));
			graphics.drawString("Press CTRL to start the game " , 145 , 415);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			//graphics.drawString("Salaam "+currentPlayer.getPlayerName()
					//+", Press CTRL to start the game" , 200 , 440);
		}
	}
	
	
	private static void ShowGameOver(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.GameOver)
		{
			graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Game Over, Looser !" , 230 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to exit" , 310 , 440);
		}
	}
	
	private static void ShowLossLive(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (currentPlayer.getLives()<3&&(Levelstatus==LevelStatus.LevelStop_LiveLoss))
		{
			graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("Be careful !!" , 300 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to continue" , 310 , 440);
		}
	}
	
	private static void ShowLevelWinned(PlayerInfo currentPlayer , Graphics graphics ,
			LevelStatus Levelstatus)
	{
		if (Levelstatus==LevelStatus.LevelWined)
		{
			graphics.setColor(Color.RED);
			graphics.fillRect(150 , 380 , 500 , 80);
			graphics.setColor(Color.BLUE);
			graphics.setFont(new Font("Arial" , Font.BOLD , 28));
			graphics.drawString("OK, Level Complete" , 250 , 405);
			
			graphics.setColor(Color.WHITE);
			graphics.setFont(new Font("Tahoma" , Font.BOLD , 12));
			graphics.drawString("Press Ctrl to next level" , 310 , 440);
		}
	}
	
}
