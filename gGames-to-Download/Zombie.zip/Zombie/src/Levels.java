public abstract class Levels
{
	public static final int	FinalLevel	=5;
	
	public static void SetLevel(GGame game , int level)
	{ 
		if (level==1)
		{
			// configs of Level 1
			PlayerInfo p=new PlayerInfo();
			Multilife xox=new Multilife();
			xox.setLives(5);
			xox.setFires(9999);
			p.setLives(p.getLives());
			p.setFires(0);
			p.setScore(0);
			p.setPlayerName("Mohsen Mokhtari");
			p.setCurrentLevel(1);
			
			game.setPlayerInfo(p);
			game.setInfo(xox);
			LoadMap(game , 1);
		}
		else if (level==2)
		{
			PlayerInfo p=game.getPlayerInfo();
			Multilife xox=game.getInfo();
			xox.setLives(5);
			xox.setFires(9999);
			p.setLives(p.getLives());
			p.setFires(p.getFires());
			p.setScore(p.getScore());
			p.setPlayerName("Mohsen Mokhtari");
			p.setCurrentLevel(2);
			
			game.setPlayerInfo(p);
			game.setInfo(xox);
			LoadMap(game , 2);
		}
		else if (level==3)
		{
			PlayerInfo p=game.getPlayerInfo();
			Multilife xox=game.getInfo();
			xox.setLives(5);
			xox.setFires(9999);
			p.setLives(p.getLives());
			p.setFires(p.getFires());
			p.setScore(p.getScore());
			p.setPlayerName("Mohsen Mokhtari");
			p.setCurrentLevel(3);
			
			game.setPlayerInfo(p);
			game.setInfo(xox);
			LoadMap(game , 3);
		}
		
		else if (level<=FinalLevel)
		{
			PlayerInfo p=game.getPlayerInfo();
			Multilife xox=game.getInfo();
			p.setCurrentLevel(p.getCurrentLevel()+1);
			game.setPlayerInfo(p);
			LoadMap(game , level);
		}
		
	}
	
	
	private static void LoadMap(GGame game , int level)
	{
		if (level==1)
			LoadMap1(game);
		if (level==2)
			LoadMap2(game);
		if (level==3)
			LoadMap3(game);
		
		
	}
	private static void LoadMap1(GGame game)
	{
		game.clearEntities();
		// Static parts
		game.setNextEntity(new GBackground(-1000, 0, 1));
		
		
		
		
		
		
		game.setNextEntity(new movablebackground(0,0,1));
		game.setNextEntity(new movablebackground(800,0,2));
		game.setNextEntity(new movablebackground(1600,0,3));
		game.setNextEntity(new movablebackground(2400,0,4));
		
		game.setNextEntity(new Ghero(100 , 600));
		
		
		game.setNextEntity(new Mainhero(2000 , 400,1));
		


game.setNextEntity(new moon(740,0));
game.setNextEntity(new cloud1(20,60));
game.setNextEntity(new cloud1(120,0));
game.setNextEntity(new cloud1(180,80));
game.setNextEntity(new cloud1(220,40));
game.setNextEntity(new cloud1(360,0));
game.setNextEntity(new cloud1(340,80));
game.setNextEntity(new cloud1(520,40));
game.setNextEntity(new cloud1(660,0));
game.setNextEntity(new cloud1(660,80));
game.setNextEntity(new cloud1(1100,0));
game.setNextEntity(new cloud1(1060,40));
game.setNextEntity(new cloud1(1260,0));
game.setNextEntity(new cloud1(1360,100));
//game.setNextEntity(new WZombi(1300,640));
game.setNextEntity(new WZombi(1300,540));
game.setNextEntity(new WZombi(1300,460));
game.setNextEntity(new WZombi(1300,560));
game.setNextEntity(new WZombi(1260,560));
//game.setNextEntity(new WZombi(1260,640));
game.setNextEntity(new WZombi(1260,460));
//game.setNextEntity(new WZombi(1220,640));
game.setNextEntity(new WZombi(1220,540));
game.setNextEntity(new WZombi(1220,460));
//game.setNextEntity(new WZombi(1180,640));
game.setNextEntity(new WZombi(1180,540));
game.setNextEntity(new WZombi(1180,460));

//game.setNextEntity(new GZombi(1080,660));
game.setNextEntity(new GZombi(1080,580));
game.setNextEntity(new GZombi(1080,500));
game.setNextEntity(new GZombi(1000,500));
game.setNextEntity(new GZombi(1000,580));
//game.setNextEntity(new GZombi(1020,660));
//game.setNextEntity(new GZombi(920,660));
game.setNextEntity(new GZombi(920,580));
game.setNextEntity(new GZombi(920,500));
//game.setNextEntity(new GZombi(1320,680));
game.setNextEntity(new GZombi(1320,580));
game.setNextEntity(new GZombi(1320,480));
game.setNextEntity(new Ammo(300,560));
game.setNextEntity(new Ammo(260,620));
game.setNextEntity(new Ammo(360,500));
game.setNextEntity(new Glife(880,620));
game.setNextEntity(new Glife(880,520));

//game.setNextEntity(new Zombifun(760,700));
game.setNextEntity(new Zombifun(760,640));
game.setNextEntity(new Zombifun(760,560));
game.setNextEntity(new Zombifun(760,520));
game.setNextEntity(new Zombifun(760,600));
game.setNextEntity(new Zombifun(860,580));
game.setNextEntity(new cloud1(120,60));
game.setNextEntity(new cloud1(1120,0));
game.setNextEntity(new cloud1(1180,80));
game.setNextEntity(new cloud1(1220,40));
game.setNextEntity(new cloud1(1360,0));
game.setNextEntity(new cloud1(1340,80));
game.setNextEntity(new cloud1(1520,40));
game.setNextEntity(new cloud1(1660,0));
game.setNextEntity(new cloud1(1660,80));
game.setNextEntity(new cloud1(2100,0));
game.setNextEntity(new cloud1(2060,40));
game.setNextEntity(new cloud1(2260,0));
game.setNextEntity(new cloud1(2360,100));
//game.setNextEntity(new WZombi(1300,640));
game.setNextEntity(new WZombi(2300,540));
game.setNextEntity(new WZombi(2300,460));
game.setNextEntity(new WZombi(2300,560));
game.setNextEntity(new WZombi(2260,560));
//game.setNextEntity(new WZombi(1260,640));
game.setNextEntity(new WZombi(2260,460));
//game.setNextEntity(new WZombi(1220,640));
game.setNextEntity(new WZombi(2220,540));
game.setNextEntity(new WZombi(2220,460));
//game.setNextEntity(new WZombi(1180,640));
game.setNextEntity(new WZombi(2180,540));
game.setNextEntity(new WZombi(2180,460));

//game.setNextEntity(new GZombi(1080,660));
game.setNextEntity(new GZombi(2080,580));
game.setNextEntity(new GZombi(2080,500));
game.setNextEntity(new GZombi(2000,500));
game.setNextEntity(new GZombi(2000,580));
//game.setNextEntity(new GZombi(1020,660));
//game.setNextEntity(new GZombi(920,660));
game.setNextEntity(new GZombi(1920,580));
game.setNextEntity(new GZombi(1920,500));
//game.setNextEntity(new GZombi(1320,680));
game.setNextEntity(new GZombi(2320,580));
game.setNextEntity(new GZombi(2320,480));
game.setNextEntity(new Ammo(1300,560));
game.setNextEntity(new Ammo(1260,620));
game.setNextEntity(new Ammo(1360,500));
game.setNextEntity(new Glife(1880,620));
game.setNextEntity(new Glife(1880,520));

//game.setNextEntity(new Zombifun(760,700));
game.setNextEntity(new Zombifun(1760,640));
game.setNextEntity(new Zombifun(1760,560));
game.setNextEntity(new Zombifun(1760,520));
game.setNextEntity(new Zombifun(1760,600));
game.setNextEntity(new Zombifun(1860,580));

	}
	private static void LoadMap2(GGame game)
	{
		game.clearEntities();
		// Static parts
		game.setNextEntity(new GBackground(-1000, 0, 1));
		game.setNextEntity(new movablebackground(0,0,1));
		game.setNextEntity(new movablebackground(800,0,2));
		game.setNextEntity(new movablebackground(1600,0,3));
		game.setNextEntity(new movablebackground(2400,0,4));

		game.setNextEntity(new Ghero(100 , 600));
		game.setNextEntity(new Mainhero(1700 , 400,2));
		game.setNextEntity(new GZombi(620,640));
		game.setNextEntity(new GZombi(600,560));
		game.setNextEntity(new GZombi(580,480));
		game.setNextEntity(new WZombi(940,620));
		game.setNextEntity(new WZombi(940,540));
		game.setNextEntity(new WZombi(920,420));
		game.setNextEntity(new Zombifun(1080,520));
		game.setNextEntity(new Zombifun(1120,660));
		game.setNextEntity(new Zombifun(1180,580));
		game.setNextEntity(new moon(600,0));
		game.setNextEntity(new cloud1(460,60));
		game.setNextEntity(new cloud1(720,80));
		game.setNextEntity(new cloud1(1280,0));
		game.setNextEntity(new GZombi(600,600));
		game.setNextEntity(new GZombi(600,520));
		game.setNextEntity(new WZombi(920,440));
		game.setNextEntity(new WZombi(920,460));
		game.setNextEntity(new WZombi(940,520));
		game.setNextEntity(new WZombi(940,600));
		game.setNextEntity(new WZombi(920,540));
		game.setNextEntity(new Zombifun(1160,500));
		game.setNextEntity(new Zombifun(1220,660));
		game.setNextEntity(new Zombifun(1200,520));
		game.setNextEntity(new Zombifun(1200,560));
		game.setNextEntity(new Zombifun(1200,500));
		game.setNextEntity(new Zombifun(1200,620));
			


game.setNextEntity(new Ammo(2300,700));
game.setNextEntity(new Ammo(2300,500));
game.setNextEntity(new Ammo(2140,580));
game.setNextEntity(new tree1(1680,240,3));
game.setNextEntity(new Glife(2340,580));
game.setNextEntity(new GZombi(1480,600));
game.setNextEntity(new GZombi(1480,520));
game.setNextEntity(new GZombi(1460,460));
game.setNextEntity(new GZombi(1480,660));
game.setNextEntity(new GZombi(1580,660));
game.setNextEntity(new GZombi(1580,580));
game.setNextEntity(new GZombi(1560,500));
game.setNextEntity(new GZombi(1560,440));
game.setNextEntity(new WZombi(1700,640));
game.setNextEntity(new WZombi(1700,580));
game.setNextEntity(new WZombi(1700,540));
game.setNextEntity(new WZombi(1700,460));
game.setNextEntity(new WZombi(1740,640));
game.setNextEntity(new WZombi(1740,580));
game.setNextEntity(new WZombi(1740,500));
game.setNextEntity(new WZombi(1740,440));
game.setNextEntity(new GZombi(1420,680));
game.setNextEntity(new GZombi(1420,620));
game.setNextEntity(new GZombi(1420,540));
game.setNextEntity(new GZombi(1400,500));
game.setNextEntity(new Zombifun(1420,660));
game.setNextEntity(new Zombifun(1420,600));
game.setNextEntity(new Zombifun(1400,540));
game.setNextEntity(new Zombifun(1400,500));
game.setNextEntity(new Zombifun(1420,720));
game.setNextEntity(new Ammo(1180,600));
game.setNextEntity(new Ammo(1180,520));
game.setNextEntity(new Glife(1320,580));
game.setNextEntity(new Glife(1320,520));
game.setNextEntity(new cloud1(1220,0));
game.setNextEntity(new cloud1(2080,20));
game.setNextEntity(new cloud1(1920,0));
game.setNextEntity(new GZombi(1760,660));
game.setNextEntity(new GZombi(1760,480));
game.setNextEntity(new GZombi(1760,540));
game.setNextEntity(new GZombi(1760,580));
game.setNextEntity(new WZombi(1880,640));
game.setNextEntity(new WZombi(1880,580));
game.setNextEntity(new WZombi(1880,520));
game.setNextEntity(new WZombi(1880,460));
game.setNextEntity(new WZombi(1140,580));
game.setNextEntity(new WZombi(1140,520));
game.setNextEntity(new WZombi(2040,460));
game.setNextEntity(new WZombi(2000,520));

	}
	private static void LoadMap3(GGame game)
	{game.clearEntities();
	// Static parts
	game.setNextEntity(new GBackground(-1000, 0, 1));
	game.setNextEntity(new movablebackground(0,0,1));
	game.setNextEntity(new movablebackground(800,0,2));
	game.setNextEntity(new movablebackground(1600,0,3));
	game.setNextEntity(new movablebackground(2400,0,4));
	game.setNextEntity(new Ghero(100 , 600));
	game.setNextEntity(new Mainhero(1700 , 400,1));
	game.setNextEntity(new moon(440,0));
	game.setNextEntity(new cloud1(60,0));
	game.setNextEntity(new cloud1(300,80));
	game.setNextEntity(new cloud1(480,20));
	game.setNextEntity(new cloud1(740,100));
	game.setNextEntity(new cloud1(640,0));
	game.setNextEntity(new cloud1(940,20));
	game.setNextEntity(new cloud1(1180,0));
	game.setNextEntity(new cloud1(280,0));
	game.setNextEntity(new cloud1(400,40));
	game.setNextEntity(new cloud1(600,60));
	game.setNextEntity(new cloud1(800,40));
	game.setNextEntity(new cloud1(1320,40));
	game.setNextEntity(new cloud1(1080,0));
	game.setNextEntity(new GZombi(540,680));
	game.setNextEntity(new GZombi(540,620));
	game.setNextEntity(new GZombi(540,560));
	game.setNextEntity(new GZombi(540,500));
	game.setNextEntity(new GZombi(540,440));
	game.setNextEntity(new GZombi(600,440));
	game.setNextEntity(new GZombi(600,480));
	game.setNextEntity(new GZombi(600,520));
	game.setNextEntity(new GZombi(620,560));
	game.setNextEntity(new GZombi(620,600));
	game.setNextEntity(new GZombi(620,640));
	game.setNextEntity(new GZombi(620,680));
	game.setNextEntity(new GZombi(720,680));
	game.setNextEntity(new GZombi(700,640));
	game.setNextEntity(new GZombi(700,600));
	game.setNextEntity(new GZombi(660,520));
	game.setNextEntity(new WZombi(880,660));
	game.setNextEntity(new WZombi(880,620));
	game.setNextEntity(new WZombi(880,560));
	game.setNextEntity(new WZombi(880,520));
	game.setNextEntity(new WZombi(880,480));
	game.setNextEntity(new WZombi(880,440));
	game.setNextEntity(new WZombi(880,420));
	game.setNextEntity(new WZombi(920,420));
	game.setNextEntity(new WZombi(920,480));

	game.setNextEntity(new WZombi(1000,420));
	game.setNextEntity(new WZombi(1040,640));
	game.setNextEntity(new WZombi(1040,580));
	game.setNextEntity(new WZombi(1040,540));
	game.setNextEntity(new WZombi(1040,520));
	game.setNextEntity(new WZombi(1040,480));
	game.setNextEntity(new WZombi(1040,440));
	game.setNextEntity(new GZombi(1020,660));
	game.setNextEntity(new GZombi(1040,600));
	game.setNextEntity(new GZombi(1020,520));
	game.setNextEntity(new GZombi(1020,460));
	game.setNextEntity(new GZombi(1040,420));
	game.setNextEntity(new GZombi(1060,460));
	game.setNextEntity(new GZombi(1060,500));
	game.setNextEntity(new GZombi(1080,660));
	game.setNextEntity(new GZombi(1080,540));
	game.setNextEntity(new GZombi(1100,600));
	game.setNextEntity(new Zombifun(1200,500));
	game.setNextEntity(new Zombifun(1240,680));
	game.setNextEntity(new Zombifun(1220,540));
	game.setNextEntity(new Zombifun(1220,580));
	game.setNextEntity(new Zombifun(1240,640));

	game.setNextEntity(new Zombifun(1280,540));
	game.setNextEntity(new Zombifun(1280,580));
	game.setNextEntity(new Zombifun(1240,600));
	game.setNextEntity(new Zombifun(1280,620));
	game.setNextEntity(new Zombifun(1280,660));
	game.setNextEntity(new Zombifun(1300,660));
	game.setNextEntity(new Zombifun(1300,620));
	game.setNextEntity(new Zombifun(1300,560));
	game.setNextEntity(new Zombifun(1280,520));
	game.setNextEntity(new Zombifun(1280,500));
	game.setNextEntity(new GZombi(1300,700));
	game.setNextEntity(new GZombi(1300,660));
	game.setNextEntity(new GZombi(1300,620));
	game.setNextEntity(new GZombi(1300,560));
	game.setNextEntity(new GZombi(1280,520));
	game.setNextEntity(new GZombi(1280,480));
	game.setNextEntity(new GZombi(1280,460));
	game.setNextEntity(new GZombi(1280,580));

	game.setNextEntity(new Zombifun(1340,500));
	game.setNextEntity(new Zombifun(1340,500));
	game.setNextEntity(new Zombifun(1340,560));
	game.setNextEntity(new Zombifun(1340,520));
	game.setNextEntity(new Zombifun(1320,500));
	game.setNextEntity(new Zombifun(1360,500));
	game.setNextEntity(new Zombifun(1380,540));
	game.setNextEntity(new Zombifun(1380,580));
	
	game.setNextEntity(new GZombi(1400,700));
	game.setNextEntity(new GZombi(1400,660));
	game.setNextEntity(new GZombi(1400,620));
	game.setNextEntity(new GZombi(1400,560));
	game.setNextEntity(new GZombi(1280,520));
	game.setNextEntity(new GZombi(1380,480));
	game.setNextEntity(new GZombi(1380,460));
	game.setNextEntity(new GZombi(1380,580));
	}


	
}