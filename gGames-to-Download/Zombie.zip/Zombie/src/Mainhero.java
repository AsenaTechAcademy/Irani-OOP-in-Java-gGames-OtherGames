import java.awt.event.KeyEvent;


public class Mainhero extends GameMovableElementAdapter
{
	private int	maxLimit	=100;
	private int Y0;
	private int	direction;
	private int a=0;
	public static final int	Zombii	=1;
	public static final int	Zombii2	=2;
	

	public Mainhero(int x, int y,int Mtype) 
	{
		super((getZombiType(Mtype)) , x , y);
		Y0=getY();
		direction=3;
	}
	private static String getZombiType(int type)
	{
		if (type==Zombii)
			return "Images/mhero1.png";
		else if (type==Zombii2)
			return "Images/mhero2.png";
		return "";
	}
	protected void goNextPoint()
	{
		
			setXY( getX()-a,getY()+direction );
			if (getY()>Y0+1+maxLimit)
				{
					direction=-3; 
				}
			if (getY()<Y0+1-maxLimit)
				{
				direction=3; 
				
				}
	}
	protected void CollideUpBorder()
	{
		setXY(getX(), getY()+1);
		direction=3;
	}
	
	protected void CollideDownBorder()
	{
		setXY(getX(), getY()-1);
		direction=-3;
	}
	private void zBullet() {
		if (GGame.gFires()>0)
		{
			
			
			zBullet c=new zBullet(0, 0);
				
				c.setXY(this.getX()+this.getWidth()-c.getWidth()-100 , this.getY()-c.getHeight()+120);
			
			
			GGame.addNewEntity(c);
			
			//SoundStore.get().Play(Sounds.Fire);
		}
		
		
	}
	public boolean WantKeyEvents()
	{
		return true;
	}
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
			a=0;
		if (e.getKeyCode()==KeyEvent.VK_D)
			a=0;
		
	}
	public void KeyPressed(KeyEvent e)
	{
		
		
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			
			a=2;
		}
		if (e.getKeyCode()==KeyEvent.VK_D)
		{
			a=2;
		}
	}
	public void Step()
	{
		super.Step();
			if( (int)(Math.random()*10+1)>8)
			 zBullet();
		 
		
		
	}
	public void CollideWith(GameElementAdapter element)
	{
		if ((element instanceof woodenbox))
		{
			
			return;
			
		}
		if ((element instanceof GZombi))
		{
			
			
			return;
		}
		if (element instanceof Zombifun)
		{
			
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof moon)
		{
			return;
		}
		if (element instanceof cloud1)
		{
			return;
		}
		if (element instanceof RBullet)
		{
			GGame.DLive();
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}if (element instanceof zBullet)
		{
			
			return;
		}
		// to collide with other elements
		//element.Destroy();
	}
}
