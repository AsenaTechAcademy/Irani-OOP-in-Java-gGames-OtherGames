public class Multilife
{
	private  int czombie;
	private int		Lives;
	private int		Fires;
	private long	TotalTime	=0;
	private long	StartTime	=0;
	private long	CurrentTime	=0;
	private int 	MyX;
	public Multilife()
	{
		TotalTime=0;
		StartTime=0;
		CurrentTime=0;
	}
	
	public Multilife(Multilife p)
	{
		
		this.TotalTime=p.TotalTime;
		this.Fires=p.Fires;
		this.Lives=p.Lives;
	}
	
	
	public void setMyX(int i){
		MyX=i;
	}
	public int getMyX(){
		return MyX;
	}
	public void setczombi(int i){
		czombie=i;
	}
	public int getczombie(){
		return czombie;
	}

	
	public long getTotalTime()
	{
		return TotalTime;
	}
	
	public void setTotalTime(long totalTime)
	{
		TotalTime=totalTime;
	}
	
	public long getStartTime()
	{
		return StartTime;
	}
	
	public void setStartTime(long startTime)
	{
		StartTime=startTime;
	}
	
	public long getCurrentTime()
	{
		return CurrentTime;
	}
	
	public void setCurrentTime(long currentTime)
	{
		CurrentTime=currentTime;
	}
	
	
	
	public int getLives()
	{
		return Lives;
	}
	
	public void setLives(int lives)
	{
		Lives=lives;
	}
	
	
	
	
	
	public int getFires()
	{
		return Fires;
	}
	
	public void setFires(int fires)
	{
		Fires=fires;
	}
	
}
