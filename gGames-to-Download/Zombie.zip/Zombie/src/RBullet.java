public class RBullet extends GameMovableElementAdapter
{
	
	public RBullet(int x , int y)
	{
		super("Images/bfire1.png" , x , y);
		
		this.setSpeedX(3);
		this.setSpeedY(0);
		this.setUpDirection();
		this.StartMoving();
	}
	
	public void Step(){
		super.Step();
		if(this.getX()-Main.game.getPlayerInfo().getMyX()>400)this.Destroy();
		
	}
	protected void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.Destroy();
	}
	protected void CollideLeftBorder()
	{
		super.CollideLeftBorder();
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{

		if (element instanceof RBullet)
		{
			
			return;
		}
		if (element instanceof LBullet)
		{
			
			return;
		}
		if (element instanceof Ghero)
		{
			return;
		}
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof GZombi)
		{
			
			this.Destroy();
			
			return;
		}
		if (element instanceof Mainhero)
		{
			this.Destroy();
			return;
		}
		if (element instanceof Zombifun)
		{
			this.Destroy();
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			this.Destroy();
			return;
		}
		if (element instanceof cloud1)
		{
			
			
			
			return;
		}
		if (element instanceof moon)
		{
			
			
			
			return;
		}
		//this.Destroy();
	}
	
}
