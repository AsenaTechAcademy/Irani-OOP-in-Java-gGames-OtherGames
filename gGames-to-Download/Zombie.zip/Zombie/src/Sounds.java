public class Sounds
{
	public final static String	Fire	="Sounds/Fire.wav";
	public final static String	gamesound	="Sounds/gamesound.wav";
	public final static String	Brick	="Sounds/Brick.wav";
	public final static String	Beton	="Sounds/Beton.wav";
	public final static String	Score	="Sounds/Score.wav";
	public final static String	Dog		="Sounds/Dog.wav";
}
