public class WZombi extends GameMovableElementAdapter
{

	private static String	Images[]	= { "Images/wzombi1.gif", "Images/wzombi2.gif"
		,"Images/wzombi3.gif","Images/wzombi4.gif","Images/wzombi5.gif","Images/wzombi6.gif"};

	private int				cImage		=0;
	private long			waitTime	=70;
	private long			lastTime	=0;
	
	public WZombi(int x , int y)
	{
		super(Images[0] , x , y);
		destroyedScore=100;
		
		setSpeedY(0);
		setSpeedX(1);
		setLeftDirection();
		StartMoving();
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%5;
		ChangeImage("Images/wzombi"+(cImage+1)+".gif");
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			Destroy();
			GGame.IncreaseScore(destroyedScore);
			//SoundStore.get().Play(Sounds.Dog);
			return;
		}
		if (element instanceof LBullet)
		{
			Destroy();
			GGame.IncreaseScore(destroyedScore);
			//SoundStore.get().Play(Sounds.Dog);
			return;
		}
		if ((element instanceof woodenbox))
		{
			return;
			
		}
		if ((element instanceof GZombi))
		{
			
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		
		if (element instanceof Gun)
		{
			return;
		}
		
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof moon)
		{
			return;
		}
		if (element instanceof cloud1)
		{
			return;
		}
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof Ammo)
		{
			
			return;
		}
		if (element instanceof woodenbox)
		{
			
			return;
		}
		if (element instanceof Glife)
		{
			
			return;
		}
		
		
	}
	
	protected void CollideLeftBorder()
	{
		super.CollideLeftBorder();
		this.Destroy();
	}
}
