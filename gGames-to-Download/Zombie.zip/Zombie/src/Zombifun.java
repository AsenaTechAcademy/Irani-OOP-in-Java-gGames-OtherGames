public class Zombifun extends GameMovableElementAdapter
{

	private static String	Images[]	= { "Images/zombi1.gif", "Images/zombi.gif"
		,"Images/zombi3.gif","Images/zombi4.gif","Images/zombi5.gif","Images/zombi6.gif","Images/zombi7.gif"
		,"Images/zombi8.gif","Images/zombi9.gif","Images/zombi10.gif",};

	private int				cImage		=0;
	private long			waitTime	=70;
	private long			lastTime	=0;
	
	public Zombifun(int x , int y)
	{
		super(Images[0] , x , y);
		destroyedScore=100;
		
		setSpeedY(0);
		setSpeedX(1);
		setLeftDirection();
		StartMoving();
	}
	
	private void nextImage()
	{
		cImage=(cImage+1)%5;
		ChangeImage("Images/zombi"+(cImage+1)+".gif");
	}
	
	public void Step()
	{
		super.Step();
		if (lastTime+waitTime<System.currentTimeMillis())
		{
			this.nextImage();
			lastTime=System.currentTimeMillis();
		}
	}
	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			Destroy();
			GGame.IncreaseScore(destroyedScore);
			//SoundStore.get().Play(Sounds.Dog);
			return;
		}
		
		if (element instanceof LBullet)
		{
			Destroy();
			GGame.IncreaseScore(destroyedScore);
			//SoundStore.get().Play(Sounds.Dog);
			return;
		}
		if ((element instanceof woodenbox))
		{
			return;
			
		}
		if ((element instanceof GZombi))
		{
			
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof Gun)
		{
			return;
		}
		
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof moon)
		{
			return;
		}
		if (element instanceof cloud1)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		if (element instanceof Ammo)
		{
			
			return;
		}
		if (element instanceof woodenbox)
		{
			
			return;
		}
		if (element instanceof Glife)
		{
			
			return;
		}
		
		
	}
	
	protected void CollideLeftBorder()
	{
		super.CollideLeftBorder();
		this.Destroy();
	}
}
