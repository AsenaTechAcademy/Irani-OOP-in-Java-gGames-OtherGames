import java.awt.event.KeyEvent;

public class cloud1 extends GameMovableElementAdapter
{
	
	public cloud1(int x , int y)
	{
super("Images/cloud1.gif" , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(0);
		setLeftDirection();
		StartMoving();
	}
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
			StopMoving();
		if (e.getKeyCode()==KeyEvent.VK_D)
	
		StopMoving();
		if(e.getKeyCode()==KeyEvent.VK_LEFT)
			StopMoving();
		if(e.getKeyCode()==KeyEvent.VK_A)
			StopMoving();
		
	}
	public void KeyPressed(KeyEvent e)
	{
		
		
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			setSpeedY(0);
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
			
		}
		if (e.getKeyCode()==KeyEvent.VK_D)
		{
			setSpeedY(0);
			setSpeedX(3);
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_A)
		{
			setSpeedY(0);
			setSpeedX(3);
			StartMoving();
			setRightDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{/*
			setSpeedY(0);
			setSpeedX(1);
			StartMoving();
			setRightDirection();
		*/
		}
		
	}
	

	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			
			return;
		}
		if (element instanceof LBullet)
		{
			
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		if (element instanceof Ghero)
		{
			return;
		}
		if (element instanceof cloud1)
		{return;
		}
		if (element instanceof GZombi)
		{
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof moon)
		{
			
			
			
			return;
		}
		if (element instanceof tree1)
		{
			
			
			
			return;
		}
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		
		// to collide with other elements
		element.Destroy();
	}
	
	protected void CollideLeftBorder()
	{
		return;
	}
}
