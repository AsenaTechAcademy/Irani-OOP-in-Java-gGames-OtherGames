import java.awt.event.KeyEvent;

public class movablebackground extends GameMovableElementAdapter
{
	public static final int	back1	=1;
	public static final int	back2	=2;
	public static final int	back3	=3;
	public static final int	back4	=4;
	public movablebackground(int x , int y,int type)
	{
super((getbackType(type)) , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(0);
		setLeftDirection();
		StartMoving();
	}
	private static String getbackType(int type)
	{
		if (type==back1)
			return "Images/back1.jpg";
		else if (type==back2)
			return "Images/back2.jpg";
		else if (type==back3)
			return "Images/back3.jpg";
		else if (type==back4)
			return "Images/back4.jpg";
		return "";
	}
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
			StopMoving();
		if (e.getKeyCode()==KeyEvent.VK_D)
	
		StopMoving();
		if(e.getKeyCode()==KeyEvent.VK_LEFT)
			StopMoving();
		if(e.getKeyCode()==KeyEvent.VK_A)
			StopMoving();
		
	}
	public void KeyPressed(KeyEvent e)
	{
		
		
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			setSpeedY(0);
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
			
		}
		if (e.getKeyCode()==KeyEvent.VK_D)
		{
			setSpeedY(0);
			setSpeedX(3);
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_A)
		{
			setSpeedY(0);
			setSpeedX(3);
			StartMoving();
			setRightDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{/*
			setSpeedY(0);
			setSpeedX(1);
			StartMoving();
			setRightDirection();
		*/
		}
		
	}
	

	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			
			return;
		}
		if (element instanceof LBullet)
		{
			
			return;
		}
		if (element instanceof Ghero)
		{
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof GZombi)
		{
			
			
			
			return;
		}
		if (element instanceof zBullet)
		{
			
			
			
			return;
		}
		if (element instanceof moon)
		{
			
			
			
			return;
		}
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof Mainhero)
		{
			return;
		}
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		if (element instanceof cloud1)
		{	
			return;
		}
		if (element instanceof Ammo)
		{
			
			return;
		}
		if (element instanceof woodenbox)
		{
			
			return;
		}
		if (element instanceof Glife)
		{
			
			return;
		}
		// to collide with other elements
		element.Destroy();
	}
	
	protected void CollideLeftBorder()
	{
		return;
	}
}
