import java.awt.event.KeyEvent;

public class tree1 extends GameMovableElementAdapter
{
	public static final int	tree1	=1;
	public static final int	tree3	=3;
	public static final int	tree4	=4;
	
	
	public tree1(int x , int y,int treeType)
	{
		super((gettreeType(treeType)) , x , y);
		
		this.setSpeedX(0);
		this.setSpeedY(0);
		setLeftDirection();
		StartMoving();
	}
	private static String gettreeType(int type)
	{
		if (type==tree1)
			return "Images/tree1.gif";
		else if (type==tree3)
			return "Images/tree3.gif";
		else if (type==tree4)
			return "Images/tree4.gif";
		return "";
	}
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
			StopMoving();
		if (e.getKeyCode()==KeyEvent.VK_D)
	
		StopMoving();
		if(e.getKeyCode()==KeyEvent.VK_LEFT)
			StopMoving();
		if(e.getKeyCode()==KeyEvent.VK_A)
			StopMoving();
		
	}
	public void KeyPressed(KeyEvent e)
	{
		
		
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			setSpeedY(0);
			setSpeedX(1);
			StartMoving();
			setLeftDirection();
			
		}
		if (e.getKeyCode()==KeyEvent.VK_D)
		{
			setSpeedY(0);
			setSpeedX(3);
			StartMoving();
			setLeftDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_A)
		{
			setSpeedY(0);
			setSpeedX(3);
			StartMoving();
			setRightDirection();
		}
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{/*
			setSpeedY(0);
			setSpeedX(1);
			StartMoving();
			setRightDirection();
		*/
		}	
	}
	

	
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		if (element instanceof LBullet)
		{
			
			return;
		}
		if (element instanceof Ghero)
		{
			return;
		}
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof GZombi)
		{
			
			
			
			return;
		}
		if (element instanceof cloud1)
		{
			
			
			
			return;
		}
		if (element instanceof moon)
		{
			
			
			
			return;
		}
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		
		// to collide with other elements
		element.Destroy();
	}
	
	protected void CollideLeftBorder()
	{
		return;
	}
}
