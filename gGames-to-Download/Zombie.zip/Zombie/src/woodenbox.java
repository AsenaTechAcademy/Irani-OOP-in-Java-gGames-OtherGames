public class woodenbox extends GameMovableElementAdapter
{
	private static String	Images[]	= { "Images/box4.gif", "Images/Evil32.png"};
	private int				cImage		=0;
	public woodenbox(int x , int y)
	{
		super(Images[0] , x , y);
		destroyedScore=100;
		setSpeedY(0);
		setSpeedX(0);
		StopMoving();
	}
	private void nextImage()
	{
		
		ChangeImage("Images/box"+(cImage+4)+".gif");
	}
	public void CollideWith(GameElementAdapter element)
	{
		if (element instanceof RBullet)
		{
			
			return;
		}
		if (element instanceof Ammo)
		{
			
			return;
		}
		if (element instanceof woodenbox)
		{
			
			return;
		}
		if (element instanceof Ghero)
		{
			
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		
		if (element instanceof LBullet)
		{
			return;
		}
		
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof GZombi)
		{
			
			
			
			return;
		}
		if (element instanceof zBullet)
		{
			return;
		}
		if (element instanceof moon)
		{
			return;
		}
		if (element instanceof tree1)
		{
			return;
		}
		
		if (element instanceof Zombifun)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			return;
		}
		if (element instanceof cloud1)
		{	
			return;
		}
	}

	
	
	
}