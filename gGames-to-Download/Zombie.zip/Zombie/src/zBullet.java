public class zBullet extends GameMovableElementAdapter
{
	
	public zBullet(int x , int y)
	{
		super("Images/zBullet.gif" , x , y);
		
		this.setSpeedX(3);
		this.setSpeedY(0);
		this.setLeftDirection();
		this.StartMoving();
	}
	
	public void Step(){
		super.Step();
		if(this.getX()-Main.game.getInfo().getMyX()<300)this.Destroy();
		
	}
	protected void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.Destroy();
	}
	protected void CollideLeftBorder()
	{
		super.CollideLeftBorder();
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{

		if (element instanceof zBullet)
		{
			
			return;
		}
		if (element instanceof LBullet)
		{
			
			return;
		}
		if (element instanceof Ghero)
		{
			this.Destroy();
			return;
		}
		if (element instanceof tree1)
		{
			return;
		}
		if (element instanceof GZombi)
		{
			
			
			
			return;
		}
		if (element instanceof Mainhero)
		{
			
			return;
		}
		if (element instanceof Zombifun)
		{
			
			return;
		}
		if (element instanceof movablebackground)
		{
			return;
		}
		if (element instanceof WZombi)
		{
			this.Destroy();
			return;
		}
		if (element instanceof cloud1)
		{
			
			
			
			return;
		}
		if (element instanceof moon)
		{
			
			
			
			return;
		}
		//this.Destroy();
	}
	
}
