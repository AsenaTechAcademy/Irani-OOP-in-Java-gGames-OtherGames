
public enum DirectionStatus {
	up , right , down , left
}
