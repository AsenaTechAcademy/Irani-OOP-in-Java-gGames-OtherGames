
public class EnemyFire extends MultiFire{

	
	public EnemyFire(int x,int y,DirectionStatus directin){
		super("Images/Enemyfire.png", x, y);
		setSpeed(4);
		setDirection(directin);
		isMoving();
	}
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		if(element instanceof MyTank)
		{
			GGame.DecreaseTankReserved();
			this.Destroy();
			return;
		}
	}
	
	
}
