import java.awt.event.KeyEvent;


public class EnemyTank extends Tank{
	
	private long changedirectinlasttime=0;
	private long changedirectinwaittime=15000;

	public EnemyTank(int x, int y) {
		super("Images/EnemyTank3.png", x, y);
		setnextImage("Images/EnemyTank1.png");
		setnextImage("Images/EnemyTank2.png");
		setnextImage("Images/EnemyTank3.png");
		setnextImage("Images/EnemyTank4.png");
		destroyedScore=60;
		setSpeed(2);
		setDirection(DirectionStatus.down);
		setSavedirect(DirectionStatus.down);
		setfirelasttime(2);
		setfirewaittime();
		setdirectionwaittime();
		changedirectinlasttime=3;
	}
	public void Step(){
		if(getisSaveddirect()==true)
		{
	    	if((getDirection()==DirectionStatus.right)||(getDirection()==DirectionStatus.left))
			setrigth_leftchanges();
		    
		    if((getDirection()==DirectionStatus.up)||(getDirection()==DirectionStatus.down))
		    	setup_downchanges();
		}
		long x=System.currentTimeMillis();
		if(x-getFirelasttime()>getFirewaittime())
			{
			Fire();
			setfirelasttime(x);
			SoundStore.get().Play(Sounds.enemyfire);
			}
		long y=System.currentTimeMillis();
		if(y-changedirectinlasttime>changedirectinwaittime)
			{
			changes();
			changedirectinlasttime=y;
			}
		super.Step();
	}
	private void changes(){
		DirectionStatus getd=getDirection();
		DirectionStatus d=DirectionStatus.right;
		if(getd==DirectionStatus.up)
			d=DirectionStatus.right;
		if(getd==DirectionStatus.right)
			d=DirectionStatus.down;
		if(getd==DirectionStatus.down)
			d=DirectionStatus.right;
		if(getd==DirectionStatus.left)
			d=DirectionStatus.up;
		setSavedirect(getd);
		setDirection(d);
		changeDirectImage(d);
	}
	private void Fire(){
		setfirelocation();
		EnemyFire ef=new EnemyFire(getXfire(), getYfire(), getDirection());
		GGame.addNewEntity(ef);
		
	}
	private void setfirewaittime(){
		float x=(float) Math.random();
		x*=14;
		long a=(long)x;
		a+=5;
		a*=1000;
		setFirewaittime(a);
	}
	private void setdirectionwaittime(){
		float x=(float) Math.random();
		x*=10;
		long a=(long)x;
		a+=4;
		a*=1000;
		changedirectinwaittime=a;
	}
	protected void CollideLeftBorder()
	{
		setDirection(DirectionStatus.right);
		changeDirectImage(DirectionStatus.right);
		StartMoving();
	}
	
	protected void CollideRightBorder()
	{
		setDirection(DirectionStatus.left);
		changeDirectImage(DirectionStatus.left);
		StartMoving();
	}
	
	protected void CollideUpBorder()
	{
		setDirection(DirectionStatus.left);
		changeDirectImage(DirectionStatus.left);
		StartMoving();
	}
	
	protected void CollideDownBorder()
	{
		setDirection(DirectionStatus.right);
		changeDirectImage(DirectionStatus.right);
		StartMoving();
	}
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		if(element instanceof EnemyTank){
			goBack();
			setCollideWithdirect();
			return;
		}
		if(element instanceof MyTank){
			GGame.DecreaseTankReserved();
			SoundStore.get().Play(Sounds.mydestroytion);
			return;
		}
		if((element instanceof MyFire1)||(element instanceof MyFire2)){
			this.Destroy();
			SoundStore.get().Play(Sounds.enemydestroition);
			return;
		}
		
	}
	private void setCollideWithdirect()
	{
		DirectionStatus d=getDirection();
		DirectionStatus sd=getDirection();
		DirectionStatus svd=getDirection();
		if(d==DirectionStatus.up)
			sd=DirectionStatus.down;
			
		if(d==DirectionStatus.right)
			sd=DirectionStatus.left;
		if(d==DirectionStatus.down)
			sd=DirectionStatus.up;
		if(d==DirectionStatus.left)
			sd=DirectionStatus.right;
		
		setSavedirect(d);
		setDirection(sd);
		changeDirectImage(sd);
	}
	
}
	
	

