public class GBackground extends GameElementAdapter
{
	public GBackground(int x , int y ,int num)
	{
		super("Images/bg"+num+".jpg" , x , y);
	}
	
}
