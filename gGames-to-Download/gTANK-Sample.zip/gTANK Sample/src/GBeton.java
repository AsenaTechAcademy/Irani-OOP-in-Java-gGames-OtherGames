
public class GBeton extends GameElementAdapter {
	
	public GBeton(int x, int y) {
		super("Images/Beton.png", x, y);
		
	}
	
}
