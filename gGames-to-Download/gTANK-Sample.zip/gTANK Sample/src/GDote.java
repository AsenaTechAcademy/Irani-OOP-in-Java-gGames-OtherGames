
public class GDote extends Gmotionless {

	public GDote(int x, int y) {
		super("Images/Dote.png", x, y);
		destroyedScore=150;
	}
	
}
