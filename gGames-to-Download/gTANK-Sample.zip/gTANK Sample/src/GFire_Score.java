
public class GFire_Score extends Gmotionless {
	
	public GFire_Score(int x, int y) {
		super("Images/Fire_score.png", x, y);
		
	}
	
}
