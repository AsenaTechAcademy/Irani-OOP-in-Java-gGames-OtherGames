
public class GFire_time extends Gmotionless {
	
	public GFire_time(int x, int y) {
		super("Images/Fire_time.png", x, y);		
	}
	
	
}
