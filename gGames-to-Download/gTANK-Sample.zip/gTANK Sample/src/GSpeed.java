
public class GSpeed extends Gmotionless{
	
	public GSpeed(int x, int y) {
		super("Images/speed.png", x, y);
		
	}
	
	
}
