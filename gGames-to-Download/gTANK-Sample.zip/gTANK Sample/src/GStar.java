
public class GStar extends Gmotionless{
	
	public GStar(int x, int y) {
		super("Images/Star.png", x, y);
		destroyedScore=40;
		
	}
	
	
}
