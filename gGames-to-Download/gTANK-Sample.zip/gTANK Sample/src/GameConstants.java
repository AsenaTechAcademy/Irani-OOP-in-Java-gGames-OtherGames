public class GameConstants
{
	public final static int	Game_Width	=800;
	public final static int	Game_Height	=600;
}
