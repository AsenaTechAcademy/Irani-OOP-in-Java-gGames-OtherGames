
public class Gmotionless extends GameElementAdapter {

	public Gmotionless(String ref, int x, int y) {
		super(ref, x, y);
		
	}
	public void CollideWith(GameElementAdapter element)
	{
		if(element instanceof MyTank)
		{
			this.Destroy();
			return;
		}
	}

}
