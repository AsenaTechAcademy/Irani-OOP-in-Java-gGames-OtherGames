public enum LevelStatus
{
	LevelNotStarted, LevelRunning, LevelStop_Player, LevelStop_LiveLoss, LevelWined, waitNextLevel, GameOver, waitGameOver;
}
