import javax.naming.ldap.StartTlsRequest;

public abstract class Levels
{
	public static final int	FinalLevel	=2;
	
	public static void SetLevel(GGame game , int level)
	{
		if (level==1)
		{
			// configs of Level 1
			PlayerInfo p=new PlayerInfo();
			p.setTankReserved(3);
			p.setScore(0);
			p.setPlayerName("Mohammad Dostifam");
			p.setCurrentLevel(1);
			
			game.setPlayerInfo(p);
			LoadMap(game , 1);
		}
		
		else if (level<=FinalLevel)
		{
			PlayerInfo p=game.getPlayerInfo();
			p.setCurrentLevel(p.getCurrentLevel()+1);
			game.setPlayerInfo(p);
			LoadMap(game , level);
		}
		
	}
	
	private static void LoadMap(GGame game , int level)
	{
		if (level==1)
			LoadMap1(game);
		if (level==2)
			LoadMap2(game);
		if (level==3)
			LoadMap3(game);
		
	}
	
	
	private static void LoadMap1(GGame game)
	{
		game.clearEntities();
		////////////////////////////////////mytank && backgr...
		GGame.addNewEntity(new GBackground(0, 0 ,1));
		GGame.addNewEntity(new MyTank(640,560));
		
		///////////////////////betons
		game.setNextEntity(new GBeton(40,520));
game.setNextEntity(new GBeton(120,520));
game.setNextEntity(new GBeton(200,520));
game.setNextEntity(new GBeton(280,520));
game.setNextEntity(new GBeton(360,520));
game.setNextEntity(new GBeton(440,520));
game.setNextEntity(new GBeton(520,520));
game.setNextEntity(new GBeton(600,520));
game.setNextEntity(new GBeton(600,440));
game.setNextEntity(new GBeton(520,440));
game.setNextEntity(new GBeton(440,440));
game.setNextEntity(new GBeton(280,440));
game.setNextEntity(new GBeton(360,440));
game.setNextEntity(new GBeton(200,440));
game.setNextEntity(new GBeton(120,440));
game.setNextEntity(new GBeton(40,440));
game.setNextEntity(new GBeton(40,360));
game.setNextEntity(new GBeton(40,280));
game.setNextEntity(new GBeton(40,200));
game.setNextEntity(new GBeton(40,120));
game.setNextEntity(new GBeton(40,40));
game.setNextEntity(new GBeton(120,40));
game.setNextEntity(new GBeton(120,120));
game.setNextEntity(new GBeton(120,200));
game.setNextEntity(new GBeton(120,280));
game.setNextEntity(new GBeton(120,360));
game.setNextEntity(new GBeton(200,360));
game.setNextEntity(new GBeton(280,360));
game.setNextEntity(new GBeton(360,360));
game.setNextEntity(new GBeton(440,360));
game.setNextEntity(new GBeton(520,360));
game.setNextEntity(new GBeton(600,360));
game.setNextEntity(new GBeton(600,280));
game.setNextEntity(new GBeton(520,280));
game.setNextEntity(new GBeton(440,280));
game.setNextEntity(new GBeton(360,280));
game.setNextEntity(new GBeton(280,280));
game.setNextEntity(new GBeton(200,280));
game.setNextEntity(new GBeton(200,200));
game.setNextEntity(new GBeton(280,200));
game.setNextEntity(new GBeton(360,200));
game.setNextEntity(new GBeton(440,200));
game.setNextEntity(new GBeton(520,200));
game.setNextEntity(new GBeton(600,200));
game.setNextEntity(new GBeton(600,120));
game.setNextEntity(new GBeton(520,120));
game.setNextEntity(new GBeton(440,120));
game.setNextEntity(new GBeton(360,120));
game.setNextEntity(new GBeton(280,120));
game.setNextEntity(new GBeton(200,120));
game.setNextEntity(new GBeton(200,40));
game.setNextEntity(new GBeton(280,40));
game.setNextEntity(new GBeton(360,40));
game.setNextEntity(new GBeton(440,40));
game.setNextEntity(new GBeton(520,40));
game.setNextEntity(new GBeton(600,40));
//////////////////////////////////////////////others
game.setNextEntity(new GDote(280,420));
game.setNextEntity(new GDote(140,500));
game.setNextEntity(new GDote(460,340));
game.setNextEntity(new GDote(40,260));
game.setNextEntity(new GDote(0,580));
game.setNextEntity(new GDote(600,100));
game.setNextEntity(new GDote(360,160));
game.setNextEntity(new GDote(240,220));
game.setNextEntity(new GDote(640,380));
game.setNextEntity(new GDote(380,20));
//////////////
game.setNextEntity(new GStar(320,480));
////////
game.setNextEntity(new EnemyTank(0,0));
game.setNextEntity(new EnemyTank(40,480));
game.setNextEntity(new EnemyTank(140,400));
game.setNextEntity(new EnemyTank(0,200));
game.setNextEntity(new EnemyTank(120,0));
game.setNextEntity(new EnemyTank(40,80));
game.setNextEntity(new EnemyTank(360,160));
//////////////////
game.setNextEntity(new GFire_Score(80,140));
game.setNextEntity(new GFire_Score(600,260));
//////////////////
game.setNextEntity(new GFire_time(440,500));
///////
game.setNextEntity(new GSpeed(0,0));

	}
	
	private static void LoadMap2(GGame game)
	{
		game.clearEntities();
		////////////////////////////////////mytank && backgr...
		GGame.addNewEntity(new GBackground(0, 0 ,1));
		GGame.addNewEntity(new MyTank(640,560));
		
		///////////////////////betons
		game.setNextEntity(new GBeton(40,520));
game.setNextEntity(new GBeton(120,520));
game.setNextEntity(new GBeton(200,520));
game.setNextEntity(new GBeton(280,520));
game.setNextEntity(new GBeton(360,520));
game.setNextEntity(new GBeton(440,520));
game.setNextEntity(new GBeton(520,520));
game.setNextEntity(new GBeton(600,520));
game.setNextEntity(new GBeton(600,440));
game.setNextEntity(new GBeton(520,440));
game.setNextEntity(new GBeton(440,440));
game.setNextEntity(new GBeton(280,440));
game.setNextEntity(new GBeton(360,440));
game.setNextEntity(new GBeton(200,440));
game.setNextEntity(new GBeton(120,440));
game.setNextEntity(new GBeton(40,440));
game.setNextEntity(new GBeton(40,360));
game.setNextEntity(new GBeton(40,280));
game.setNextEntity(new GBeton(40,200));
game.setNextEntity(new GBeton(40,120));
game.setNextEntity(new GBeton(40,40));
game.setNextEntity(new GBeton(120,40));
game.setNextEntity(new GBeton(120,120));
game.setNextEntity(new GBeton(120,200));
game.setNextEntity(new GBeton(120,280));
game.setNextEntity(new GBeton(120,360));
game.setNextEntity(new GBeton(200,360));
game.setNextEntity(new GBeton(280,360));
game.setNextEntity(new GBeton(360,360));
game.setNextEntity(new GBeton(440,360));
game.setNextEntity(new GBeton(520,360));
game.setNextEntity(new GBeton(600,360));
game.setNextEntity(new GBeton(600,280));
game.setNextEntity(new GBeton(520,280));
game.setNextEntity(new GBeton(440,280));
game.setNextEntity(new GBeton(360,280));
game.setNextEntity(new GBeton(280,280));
game.setNextEntity(new GBeton(200,280));
game.setNextEntity(new GBeton(200,200));
game.setNextEntity(new GBeton(280,200));
game.setNextEntity(new GBeton(360,200));
game.setNextEntity(new GBeton(440,200));
game.setNextEntity(new GBeton(520,200));
game.setNextEntity(new GBeton(600,200));
game.setNextEntity(new GBeton(600,120));
game.setNextEntity(new GBeton(520,120));
game.setNextEntity(new GBeton(440,120));
game.setNextEntity(new GBeton(360,120));
game.setNextEntity(new GBeton(280,120));
game.setNextEntity(new GBeton(200,120));
game.setNextEntity(new GBeton(200,40));
game.setNextEntity(new GBeton(280,40));
game.setNextEntity(new GBeton(360,40));
game.setNextEntity(new GBeton(440,40));
game.setNextEntity(new GBeton(520,40));
game.setNextEntity(new GBeton(600,40));
//////////////////////////////////////////////others
game.setNextEntity(new GDote(160,380));
game.setNextEntity(new GDote(560,380));
game.setNextEntity(new GDote(640,60));
game.setNextEntity(new GDote(320,460));
game.setNextEntity(new GDote(400,220));
game.setNextEntity(new GDote(200,20));
game.setNextEntity(new GDote(100,540));
game.setNextEntity(new GDote(80,220));
///////////////
game.setNextEntity(new GFire_Score(420,580));
game.setNextEntity(new GFire_Score(560,140));
/////////
game.setNextEntity(new GStar(520,500));
game.setNextEntity(new GStar(380,20));
/////
game.setNextEntity(new GFire_time(360,100));
game.setNextEntity(new GFire_time(40,420));
///////////
game.setNextEntity(new EnemyTank(0,480));
game.setNextEntity(new EnemyTank(0,320));
game.setNextEntity(new EnemyTank(240,240));
game.setNextEntity(new EnemyTank(80,160));
game.setNextEntity(new EnemyTank(140,80));
game.setNextEntity(new EnemyTank(240,0));
game.setNextEntity(new EnemyTank(0,0));
game.setNextEntity(new EnemyTank(420,320));
game.setNextEntity(new EnemyTank(200,400));
///////////
game.setNextEntity(new GSpeed(0,580));
	}
	
	
	private static void LoadMap3(GGame game)
	{
		game.clearEntities();
		
	}
	
	
}
