
public class MultiFire extends GameMovableElementAdapter {

	public MultiFire(String ref,int x, int y) {
		super(ref, x, y);
		SetLimits(0, 680, 0,600);
		StartMoving();
		}
	protected void CollideLeftBorder()
	{
		this.Destroy();
		return;

	}
	
	protected void CollideRightBorder()
	{
		this.Destroy();
		return;
	}
	
	protected void CollideUpBorder()
	{
		this.Destroy();
		return;

	}
	
	protected void CollideDownBorder()
	{
		this.Destroy();
		return;

	}
	public void CollideWith(GameElementAdapter element)
	{
		if(element instanceof GBeton)
		{
			goBack();
			this.Destroy();
		}
	}

}
