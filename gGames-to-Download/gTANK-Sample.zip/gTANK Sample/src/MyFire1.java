
public class MyFire1 extends MyMultiFire{

	
	public MyFire1( int x, int y ,DirectionStatus direction) {
		super("Images/Myfire1.png", x, y);
		setSpeed(3);
		setDirection(direction);
	}
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
	}
}
