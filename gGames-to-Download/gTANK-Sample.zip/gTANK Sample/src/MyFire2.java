
public class MyFire2 extends MyMultiFire{

	
	public MyFire2( int x, int y,DirectionStatus direction) {
		super("Images/Myfire2.png", x, y);
		setSpeed(5);
		setDirection(direction);
		}
	public void increasspeed(int s){
		setSpeed(s);
	}
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
	}
}
