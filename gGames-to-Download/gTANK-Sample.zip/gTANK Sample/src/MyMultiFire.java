
public class MyMultiFire extends MultiFire {


	public MyMultiFire(String ref, int x, int y) {
		super(ref, x, y);
	}

	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		if(element instanceof EnemyTank)
		{
			GGame.IncreaseScore(element.destroyedScore);
			this.Destroy();
			return;
		}
		
		
		
	}

}
