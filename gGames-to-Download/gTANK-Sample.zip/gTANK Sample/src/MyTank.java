import java.awt.event.KeyEvent;
import java.io.ObjectInputStream.GetField;
import java.security.acl.LastOwnerException;
import java.sql.Date;


public class MyTank extends Tank {

	private int fireType;
	private int station;
	
	public MyTank(int x, int y) {
		super("Images/MyTank4.png", x, y);
		setnextImage("Images/MyTank1.png");
		setnextImage("Images/MyTank2.png");
		setnextImage("Images/MyTank3.png");
		setnextImage("Images/MyTank4.png");
		setSpeed(2);
		setDirection(DirectionStatus.left);
		setFireType(1);
		setStation(1);
		setFirewaittime(2000);
	}

	public void Step()
	{
		if(getisSaveddirect()==true)
		{
			if((getDirection()==DirectionStatus.right)||(getDirection()==DirectionStatus.left))
			{
				setrigth_leftchanges();
			}
			if((getDirection()==DirectionStatus.up)||(getDirection()==DirectionStatus.down))
			{
			     setup_downchanges();
			     
			}
			
		}
		
		super.Step();
	}
	private void Fire()
	{
		
		setfirelocation();
		if(getFireType()==1)
		{
			MyFire1 f1=new MyFire1(getXfire(), getYfire(), this.getDirection());
			GGame.addNewEntity(f1);
			SoundStore.get().Play(Sounds.myFire1);
		}
		if(getFireType()==2)
		{
			MyFire2 f2=new MyFire2(getXfire(), getYfire(), this.getDirection());
			GGame.addNewEntity(f2);
			SoundStore.get().Play(Sounds.myFire2);
		}		
	}
	public void setFirelasttime() {
		if(!(isFireperiod()))
		{
			setfirelasttime((long)System.currentTimeMillis());
			setFireperiod(true);
			
		}
	}
	protected void CollideLeftBorder()
	{
		StopMoving();
	}
	
	protected void CollideRightBorder()
	{
		StopMoving();
	}
	
	protected void CollideUpBorder()
	{
		StopMoving();
	}
	
	protected void CollideDownBorder()
	{
		StopMoving();
	}
	public void CollideWith(GameElementAdapter element)
	{
		super.CollideWith(element);
		if(element instanceof GDote)
		{
			GGame.IncreaseScore(element.destroyedScore);
			SoundStore.get().Play(Sounds.dote_score);
			return;
		}
		if(element instanceof GStar)
		{
			GGame.IncreaseTankReserved();
			SoundStore.get().Play(Sounds.star);
			return;
		}
		if(element instanceof GSpeed)
		{
			this.setSpeed(this.getSpeed()+2);
			SoundStore.get().Play(Sounds.speed);
			return;
		}
		if(element instanceof GFire_time)
		{
			decreaseFirewaittime();
			return;
		}
		if(element instanceof GFire_Score)
		{
			if(getFireType()==1)
				setFireType(2);
			else
				setFirewaittime(0);
			SoundStore.get().Play(Sounds.f_Score);
			return;
		}
	
	}
	public boolean WantKeyEvents()
	{
		return true;
	}
	
	public void KeyPressed(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_SPACE){
			setFirelasttime();
			if (isFireperiod() && (getFirelasttime()+getFirewaittime())<System.currentTimeMillis())
			{
				Fire();
			}
			if(isFireperiod() && (getFirelasttime()+getFirewaittime()+1100)<System.currentTimeMillis())
				setFireperiod(false);
				
			
			
		}
		if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			setSavedirect(getDirection());
			setDirection(DirectionStatus.left);
			changeDirectImage(DirectionStatus.left);
			StartMoving();
		}
		if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			setSavedirect(getDirection());
			setDirection(DirectionStatus.right);
			changeDirectImage(DirectionStatus.right);
			StartMoving();
		}
		if (e.getKeyCode()==KeyEvent.VK_UP)
		{
			setSavedirect(getDirection());
			setDirection(DirectionStatus.up);
			changeDirectImage(DirectionStatus.up);
			StartMoving();
		}
		if (e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			setSavedirect(getDirection());
			setDirection(DirectionStatus.down);
			changeDirectImage(DirectionStatus.down);
			StartMoving();
		}
	}

	public void Reset() {
		setXY(0, 0);
		float x=(float) Math.random();
		x*=500;
		int a=(int)x;
		if(station==1)
		{
			setXY((a/8)*8,160);
			setDirection(DirectionStatus.left);
			changeDirectImage(DirectionStatus.left);
		}
		if(station==2)
		{
			setXY((a/8)*8, 320);
			setDirection(DirectionStatus.left);
			changeDirectImage(DirectionStatus.left);
		}
		if(station==3)
		{
			setXY(640,560);
			setDirection(DirectionStatus.left);
			changeDirectImage(DirectionStatus.left);
		}
		if(station==4)
		{
			setXY((a/8)*8,0);
			setDirection(DirectionStatus.right);
			changeDirectImage(DirectionStatus.right);
		}

		if(station<4)
			station++;
		if(station==4)
			station=1;
	}
	private int getFireType() {
		return fireType;
	}
	private void setFireType(int fireType) {
		this.fireType = fireType;
	}
	private int getStation() {
		return station;
	}
	private void setStation(int station) {
		this.station = station;
	}


}
