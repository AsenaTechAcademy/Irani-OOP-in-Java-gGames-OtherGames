public class PlayerInfo
{
	private String	PlayerName;
	private int		currentLevel;
	private int		Score;
	private int		TankReserved;
	private long	TotalTime	=0;
	private long	StartTime	=0;
	private long	CurrentTime	=0;
	
	public PlayerInfo()
	{
		TotalTime=0;
		StartTime=0;
		CurrentTime=0;
	}
	
	public PlayerInfo(PlayerInfo p)
	{
		this.PlayerName=p.PlayerName;
		this.currentLevel=p.currentLevel;
		this.TotalTime=p.TotalTime;
		this.Score=p.Score;
		this.TankReserved=p.TankReserved;
		
	}
	
	
	public int getCurrentLevel()
	{
		return currentLevel;
	}
	
	public void setCurrentLevel(int currentLevel)
	{
		this.currentLevel=currentLevel;
	}
	
	public String getPlayerName()
	{
		return PlayerName;
	}
	
	public void setPlayerName(String playerName)
	{
		PlayerName=playerName;
	}
	
	public long getTotalTime()
	{
		return TotalTime;
	}
	
	public void setTotalTime(long totalTime)
	{
		TotalTime=totalTime;
	}
	
	public long getStartTime()
	{
		return StartTime;
	}
	
	public void setStartTime(long startTime)
	{
		StartTime=startTime;
	}
	
	public long getCurrentTime()
	{
		return CurrentTime;
	}
	
	public void setCurrentTime(long currentTime)
	{
		CurrentTime=currentTime;
	}
	
	
	public int getScore()
	{
		return Score;
	}
	
	public void setScore(int score)
	{
		Score=score;
	}
	
	public int getTankReserved() {
		return TankReserved;
	}

	public void setTankReserved(int tankReserved) {
		TankReserved = tankReserved;
	}
	
}
