public class Sounds
{
	public final static String	myFire1	="Sounds/myfire 1.wav";
	public final static String	myFire2	="Sounds/myfire 2.wav";
	public final static String	enemyfire	="Sounds/enemyfire.wav";
	public final static String	speed	="Sounds/speed.wav";
	public final static String	f_Score	="Sounds/f _score.wav";
	public final static String	dote_score	="Sounds/doteScore.wav";
	public final static String	mydestroytion	="Sounds/mydistroition.wav";
	public final static String	enemydestroition	="Sounds/enemydistroition.wav";
	public final static String	star	="Sounds/star.wav";
	public final static String	gamesound	="Sounds/gamesound.wav";

}
