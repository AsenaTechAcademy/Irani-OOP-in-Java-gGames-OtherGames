import javax.swing.text.StyledEditorKit.BoldAction;


public class Tank extends GameMovableElementAdapter {

	private String[] images ;
	private int cimages;
	private DirectionStatus savedirect=DirectionStatus.right;
	private boolean issaveddirect=false;
	private  long firelasttime=0;
	private  long firewaittime=0;
	private boolean fireperiod=true;
	private int  xfire=0;
	private int  yfire=200;

	public Tank(String ref, int x, int y) {
		super(ref, x, y);
		images=new String[4];
		cimages=0;
		StartMoving();
		SetLimits(0, 640, 0,560);
	}
	protected void changeDirectImage(DirectionStatus d){
		String s="";
		if(d==DirectionStatus.up)
			s=images[0];
		if(d==DirectionStatus.right)
			s=images[1];
		if(d==DirectionStatus.down)
			s=images[2];
		if(d==DirectionStatus.left)
			s=images[3];
		ChangeImage(s);
	}
	protected void setnextImage(String img){
		images[cimages++]=img;
	}
	
	protected void decreaseFirewaittime() {
		if(this.getFirewaittime()>=1000)
			this.setFirewaittime(this.getFirewaittime() - 1000);
	}
	protected void setfirelocation() {
		int x=getX();
		int y=getY();
		DirectionStatus d=getDirection();
		if(d==DirectionStatus.up)
		{
			setXfire(x+(getWidth()/8)*3+1);
			setYfire(y);
		}
		if(d==DirectionStatus.down)
		{
			setXfire(x+(getWidth()/8)*3+2);
			setYfire(y+getHeight());
		}
		if(d==DirectionStatus.right)
		{
			setXfire(x+getWidth());
			setYfire(y+(getHeight()/8)*3+1);
		}
		if(d==DirectionStatus.left)
		{
			setXfire(x);
			setYfire(y+(getHeight()/8)*3+1);
		}
	}
	protected DirectionStatus getSavedirect() {
		return savedirect;
	}
	protected void setSavedirect(DirectionStatus savedirect) {
		this.savedirect = savedirect;
	}
	protected int getXfire() {
		return xfire;
	}
	private void setXfire(int xfire) {
		this.xfire = xfire;
	}
	protected int getYfire() {
		return yfire;
	}
	private void setYfire(int yfire) {
		this.yfire = yfire;
	}
	protected boolean getisSaveddirect() {
		return issaveddirect;
	}
	protected void setisSaveddirect(boolean saveddirect) {
		this.issaveddirect = saveddirect;
	}
	protected void setrigth_leftchanges(){
		int[] ax={0,80,160,240,320,400,480,560,640};
		for(int x=0;x<ax.length;x++)
		{	
			if(getX()==ax[x]){
				setDirection(getSavedirect());
				changeDirectImage(getSavedirect());
				setisSaveddirect(false);
			}
		}
	}
    protected void setup_downchanges(){
    	int[] ax={0,80,160,240,320,400,480,560,640};
    	for(int x=0;x<ax.length;x++)
		{	
			if(getY()==ax[x]){
				setDirection(getSavedirect());
				changeDirectImage(getSavedirect());
				setisSaveddirect(false);
			}
		}
    }
    public void CollideWith(GameElementAdapter element)
    	{
    	if(element instanceof GBeton)
    		{
    			goBack();
    			DirectionStatus d=getDirection();
    			setDirection(getSavedirect());
    			changeDirectImage(getDirection());
    			setSavedirect(d);
    			setisSaveddirect(true);
    			return;
    		}
	  }
	protected boolean isFireperiod() {
		return fireperiod;
	}
	protected void setFireperiod(boolean fireperiod) {
		this.fireperiod=fireperiod;
	}
	
	protected long getFirelasttime() {
		return firelasttime;
	}
	protected void setfirelasttime(long firelasttime) {
		this.firelasttime=firelasttime;
	}
	protected long getFirewaittime() {
		return firewaittime;
	}
	protected void setFirewaittime(long firewaittime) {
		this.firewaittime = firewaittime;
	}
    
	}

