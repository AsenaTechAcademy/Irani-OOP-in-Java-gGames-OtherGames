public class GBackground extends GameElementAdapter
{
	public GBackground(int x , int y)
	{
		super("Images/bg.png" , x , y);
	}
}
