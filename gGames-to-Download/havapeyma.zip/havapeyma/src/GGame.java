 import java.awt.DisplayMode;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter; 
import java.awt.image.BufferStrategy;

import javax.swing.JFrame; 



public class GGame
{
	private static PlayerInfo			currentPlayer;
	private static LevelStatus			Levelstatus	=LevelStatus.LevelNotStarted;
	private JFrame						frmMain;
	private BufferStrategy				buffer;
	Graphics							graphics;
	
	private static GameElementAdapter	Entities[]	=new GameElementAdapter[10000];
	private static int					cEntities	=0;
	private long time=0;
	
	public GGame()
	{
		GraphicsEnvironment genv=GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice device=genv.getDefaultScreenDevice();
		GraphicsConfiguration gc=device.getDefaultConfiguration();
		
		frmMain=new JFrame(gc);
		frmMain.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmMain.setUndecorated(true);
		frmMain.setResizable(false);
		frmMain.setLayout(null);
		frmMain.setIgnoreRepaint(true);
		
		device.setFullScreenWindow(frmMain);
		device.setDisplayMode(new DisplayMode(GameConstants.Game_Width , GameConstants.Game_Height ,
				32 , 0));
		
		frmMain.createBufferStrategy(2);
		buffer=frmMain.getBufferStrategy();
		
		frmMain.requestFocus();
		frmMain.addKeyListener(new KeyHandler());
		frmMain.addMouseMotionListener(new MouseMotionHandler());
		frmMain.addMouseListener(new MouseHandler());
		
		
	}// end of default constructor
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Other Methods
	public void setPlayerInfo(PlayerInfo p)
	{
		currentPlayer=new PlayerInfo(p);
	}
	
	public static long gettime()
	{
		return currentPlayer.getCurrentTime();
	}
	
	public PlayerInfo getPlayerInfo()
	{
		return currentPlayer;
	}
	
	public static void IncreaseFires(int fires)
	{
		currentPlayer.setFires(currentPlayer.getFires()+fires);
	}
	
	public static void DecreaseFires(int fires)
	{
		currentPlayer.setFires(currentPlayer.getFires()-fires);
	}
	public static void DecreaseMooshak(int Mooshak)
	{
		currentPlayer.setMooshak(currentPlayer.getMooshak()-Mooshak);
	}
	public static void IncreaseMooshak(int Mooshak)
	{
		currentPlayer.setMooshak(currentPlayer.getMooshak()+Mooshak);
	}
	public static int getMooshak()
	{
		return currentPlayer.getMooshak();
	}
	public static int getFire()
	{
		return currentPlayer.getFires();
	}
	
	public static int getTotalFires()
	{
		return currentPlayer.getFires();
	}
	
	public static void IncreaseScore(int score)
	{
		currentPlayer.setScore(currentPlayer.getScore()+score);
		if (score>0)
			SoundStore.get().Play(Sounds.Score);
	}
	
	public static void IncreaseLive()
	{
		currentPlayer.setLives(currentPlayer.getLives()+1);
	}
	public static void IncreaseFuel()
	{
		if(currentPlayer.getfuel()+400<=1000)
		     currentPlayer.setfuel(currentPlayer.getfuel()+400);
		else
		     currentPlayer.setfuel(1000);

	}
	public static void DecreaseFuel()
	{
		currentPlayer.setfuel(currentPlayer.getfuel()-1);
	}
	public static long getFuel()
	{
		return currentPlayer.getfuel();
	}
	
	
	public static void setLevelStatus(int a)
	{
		if(a==1)
		Levelstatus	=LevelStatus.GameOver;
		else if(a==2)
			Levelstatus	=LevelStatus.LevelWined;
	}
	
	
	public static void DecreaseLive()
	{
		if (currentPlayer.getLives()==1)
			Levelstatus=LevelStatus.GameOver;
		else
		{
			currentPlayer.setLives(currentPlayer.getLives()-1);
			Levelstatus=LevelStatus.LevelStop_LiveLoss;
			//((havapeyma) Entities[1]).Reset(); // Reset Bar to first status
		}
	}
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Add Entities
	public void setNextEntity(GameElementAdapter element)
	{
		element.setID(cEntities);
		Entities[cEntities++]=element;
	}
	
	public static void addNewEntity(GameElementAdapter element)
	{
		element.setID(cEntities);
		Entities[cEntities++]=element;
		// Maybe we do something in the future
	}
	
	public void clearEntities()
	{
		cEntities=0;
	}
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Game Start
	public void Game_Start()
	{
		Levelstatus=LevelStatus.LevelNotStarted;
		currentPlayer.setStartTime(System.currentTimeMillis());
	}
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Game Loop
	public LevelStatus Game_Loop()
	{
		
		while (true)
		{
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			graphics=buffer.getDrawGraphics();
			
			if (cEntities==2)
				Levelstatus=LevelStatus.LevelWined;
			
			// Step of All Entities
			if (Levelstatus==LevelStatus.LevelRunning)
			{
				for (int i=0 ; i<cEntities ; i++)
					Entities[i].Step();
				CheckCollisions();
				currentPlayer.setCurrentTime((System.currentTimeMillis()-currentPlayer
						.getStartTime())/1000);
			}
			
			// Draw ALL current entities in any condition of game
			for (int i=0 ; i<cEntities ; i++)
				Entities[i].draw(graphics);				
				
			// Message of Game
			LevelMessages.ShowLevelMessages(currentPlayer , graphics , Levelstatus);
			
			buffer.show();
			graphics.dispose();
			
			if ((Levelstatus==LevelStatus.waitNextLevel)||(Levelstatus==LevelStatus.waitGameOver))
				return Levelstatus;
		}// End of While(true)
	}
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Collisions
	private void CheckCollisions()
	{
		// Check collision of all moving elements with static elements
		for (int mm=1 ; mm<cEntities ; mm++)
		{
			for (int i=mm+1 ; i<cEntities ; i++)
			{
				GameElementAdapter me=(GameElementAdapter) Entities[mm];
				GameElementAdapter him=(GameElementAdapter) Entities[i];
				
				if (me.Contains(him))
				{
					me.CollideWith(him);
					him.CollideWith(me);
				}
			}
		}
	} // end of method check collisions
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Death Notify
	public static void NotifyDeath(GameElementAdapter element)
	{
		if(cEntities>=4)
		{    Entities[cEntities-2].setID(element.getID());
		     Entities[element.getID()]=Entities[cEntities-2];
		     Entities[cEntities-1].setID(cEntities-2);
		     Entities[cEntities-2]=Entities[cEntities-1];
		     cEntities--;
		}
		else if(cEntities==3)
		{
			Entities[1]=Entities[2];
			Entities[1].setID(2);
			cEntities--;
		}
	}
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Mouse Adapter
	private class MouseMotionHandler extends MouseMotionAdapter
	{
		public void mouseMoved(MouseEvent e)
		{
			if (Levelstatus==LevelStatus.LevelRunning)
			{
				// say to all elements that a key Pressed
				for (int i=0 ; i<cEntities ; i++)
					if (Entities[i].WantMouseEvents() && Entities[i]!=null)
						Entities[i].mouseMoved(e);
				return;
			}
		}
		public void mouseDragged(MouseEvent e)
		{
			if (Levelstatus==LevelStatus.LevelRunning)
			{
				for (int i=0 ; i<cEntities ; i++)
					if (Entities[i].WantMouseEvents())
						Entities[i].mouseDragged(e);
				return;
			}	
		}
	}
	
	private class MouseHandler extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e)
		{
			if (e.getButton()==MouseEvent.BUTTON3 && Levelstatus==LevelStatus.LevelRunning && currentPlayer.getMooshak()>=1)
			{
				if(currentPlayer.getCurrentTime()-time<=1)
				{
					try {
						Thread.sleep(10);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				// say to all elements that a key Pressed
				time=currentPlayer.getCurrentTime();
				for (int i=0 ; i<cEntities ; i++)
					if (Entities[i].WantMouseEvents())
						Entities[i].mouseb3_click(e);
				return;
			}
			
			else if(e.getButton()==MouseEvent.BUTTON1 && Levelstatus==LevelStatus.LevelRunning&&currentPlayer.getFires()>=1)
			{
				// say to all elements that a key Pressed
				for (int i=0 ; i<cEntities ; i++)
					if (Entities[i].WantMouseEvents())
						Entities[i].mouseb1_click(e);
				return;
			}
		}
		public void mousePressed(MouseEvent e)
		{
			//say to all entities
		}
		public void mouseReleased(MouseEvent e)
		{
			if (e.getButton()==MouseEvent.BUTTON1 && Levelstatus==LevelStatus.LevelRunning)
			{
				// say to all elements that a key Pressed
				for (int i=0 ; i<cEntities ; i++)
					if (Entities[i].WantMouseEvents())
						Entities[i].mouseb1_click(e);
				return;
			}
		}
	}
	
	// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ key Adapter
	private class KeyHandler extends KeyAdapter
	{
		public void keyPressed(KeyEvent e)
		{
			if (Levelstatus==LevelStatus.LevelRunning)
			{
				// say to all elements that a key Pressed
				for (int i=0 ; i<cEntities ; i++)
					if (Entities[i].WantKeyEvents())
						Entities[i].KeyPressed(e);
				return;
			}
		}
		
		public void keyReleased(KeyEvent e)
		{
			
			if (e.getKeyCode()==KeyEvent.VK_ESCAPE)
			{
				if (Levelstatus==LevelStatus.LevelStop_Player)
					Levelstatus=LevelStatus.waitGameOver;
				if (Levelstatus==LevelStatus.LevelRunning)
					Levelstatus=LevelStatus.LevelStop_Player;
				return;
			}
			if (e.getKeyCode()==KeyEvent.VK_CONTROL)
			{
				if (Levelstatus==LevelStatus.GameOver)
					Levelstatus=LevelStatus.waitGameOver;
				if ((Levelstatus==LevelStatus.LevelWined))
					Levelstatus=LevelStatus.waitNextLevel;
				if (Levelstatus==LevelStatus.LevelNotStarted
						||Levelstatus==LevelStatus.LevelStop_LiveLoss
						||Levelstatus==LevelStatus.LevelStop_Player)
					Levelstatus=LevelStatus.LevelRunning;
				return;
			}
			
			if ((Levelstatus==LevelStatus.LevelRunning)
					||(Levelstatus==LevelStatus.LevelStop_LiveLoss))
			{
				// say to all elements that a key Released
				for (int i=0 ; i<cEntities ; i++)
					if (Entities[i].WantKeyEvents())
						Entities[i].KeyReleased(e);
			}
		}
		
	}// End of Key Adapter
	
}// end of class GGame



