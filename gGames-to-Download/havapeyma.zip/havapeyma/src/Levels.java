public abstract class Levels
{
	public static final int	FinalLevel	=3;
	
	public static void SetLevel(GGame game , int level)
	{
		if (level==1)
		{
			// configs of Level 1
			PlayerInfo p=new PlayerInfo();
			p.setLives(3);
			p.setFires(60);
			p.setfuel(700);
			p.setScore(0);
			p.setMooshak(3);
			p.setPlayerName("Saman");
			p.setCurrentLevel(1);
			
			game.setPlayerInfo(p);
			LoadMap(game , 1);
		}
		
		else if (level<=FinalLevel)
		{
			PlayerInfo p=game.getPlayerInfo();
			p.setCurrentLevel(p.getCurrentLevel()+1);
			if(level==3)
			{
				p.setMooshak(p.getMooshak()+10);
				p.setFires(p.getFires()+50);
			}
			p.setfuel(1000);
			game.setPlayerInfo(p);
			LoadMap(game , level);
		}
		
	}
	
	private static void LoadMap(GGame game , int level)
	{
		if (level==1)
			LoadMap1(game);
		if (level==2)
			LoadMap2(game);
		if (level==3)
			LoadMap3(game);
		
		
	}
	
	private static void LoadMap1(GGame game)
	{
		game.clearEntities();
		// Static GBackground
		game.setNextEntity(new GBackground(0 , 0));

		
		////////////////////////////////////////////////////////
		
		//jazire
		game.setNextEntity(new jazire(300 , -150,0));
		game.setNextEntity(new jazire(290 , 400,1));
		game.setNextEntity(new jazire(100 , -680,2));
		game.setNextEntity(new jazire(500 , -900,1));
		game.setNextEntity(new jazire(350 , -1200,2));
		game.setNextEntity(new jazire(30 , -1400,1));
		game.setNextEntity(new jazire(590 , -1700,0));
		game.setNextEntity(new jazire(460 , -1900,3));
		game.setNextEntity(new jazire(100 , -2250,0));
		game.setNextEntity(new jazire(250 , -2700,0));
		game.setNextEntity(new jazire(325 , -3120,3));
		game.setNextEntity(new jazire(550 , -3300,1));
		game.setNextEntity(new jazire(100 , -3450,3));
		game.setNextEntity(new jazire(345 , -3600,0));
		

///////////////////////////////////////////////////////////////////////		
		

		//kashti bedoone barkhord
		game.setNextEntity(new k11(550 , -400));
		game.setNextEntity(new k21(100 , -750));
		game.setNextEntity(new k11(300 , -1000));
		game.setNextEntity(new k11(405 , -1350));
		game.setNextEntity(new k21(70 , -2500));
		game.setNextEntity(new k21(590 , -3600));
		game.setNextEntity(new k21(320 , -4500));

///////////////////////////////////////////////////////////////////////////////////
		
		
		//keshti doshman
		
				game.setNextEntity(new k31(540 , -1000));
				game.setNextEntity(new k41(50 , -1900));
				game.setNextEntity(new k51(450 , -2600));
				game.setNextEntity(new k31(540 , -3400));
				game.setNextEntity(new k41(500 , -500));
				game.setNextEntity(new k51(250 , -1000));
				
		///////////////////////////////////////////////////////////////////////////////
		
				// havapeymaye doshman
				
			    game.setNextEntity(new h11(500 , -150));
				game.setNextEntity(new h31(100 , -200));
				game.setNextEntity(new h31(250 , -800));
				game.setNextEntity(new h4(540 , -1350));
				game.setNextEntity(new h31(320 , -1600));
				game.setNextEntity(new h31(40 , -1920));
				game.setNextEntity(new h21(260 , -2320));
				game.setNextEntity(new h11(350 , -2850));
				game.setNextEntity(new h11(290 , -3100));
				game.setNextEntity(new h5(390 , -3300));
				game.setNextEntity(new h6(325 , -3555));
				game.setNextEntity(new h4(400 , -3590));
				game.setNextEntity(new h21(390 , -3650));
				game.setNextEntity(new h31(60 , -3740));
				game.setNextEntity(new h31(540 , -3800));
				game.setNextEntity(new h11(105 , -4200));
				game.setNextEntity(new h21(540 , -4505));
				game.setNextEntity(new h11(560 , -4708));
				game.setNextEntity(new h4(100 , -4800));
				game.setNextEntity(new h5(250 , -4900));
				game.setNextEntity(new h6(350 , -4990));
				game.setNextEntity(new h4(450 , -5100));
				game.setNextEntity(new h11(560 , -5190));
				game.setNextEntity(new h31(20  , -5260));

		/////////////////////////////////////////////////////////////////////////////////
		
		
		//abr 
		
		game.setNextEntity(new abr(100 , -100,2));
		game.setNextEntity(new abr(250 , -200,0));
		game.setNextEntity(new abr(500 , -300,0));
		game.setNextEntity(new abr(430 , -305,1));
		game.setNextEntity(new abr(325 , -365,2));
		game.setNextEntity(new abr(550 , -370,1));
		game.setNextEntity(new abr(100 , -390,0));
		game.setNextEntity(new abr(345 , -430,0));
		game.setNextEntity(new abr(500 , -550,1));
		game.setNextEntity(new abr(300 , -680,2));
		game.setNextEntity(new abr(150 , -900,1));
		game.setNextEntity(new abr(350 , -1050,2));
		game.setNextEntity(new abr(215 , -1200,1));
		game.setNextEntity(new abr(405 , -1290,0));
		game.setNextEntity(new abr(100 , -1400,1));
		game.setNextEntity(new abr(460 , -1490,1));
		game.setNextEntity(new abr(100 , -1589,2));
		game.setNextEntity(new abr(250 , -1700,0));
		game.setNextEntity(new abr(50 , -1900,1));
		game.setNextEntity(new abr(300 , -2050,1));
		game.setNextEntity(new abr(365 , -2250,0));
		game.setNextEntity(new abr(600 , -2500,0));
		game.setNextEntity(new abr(100 , -2650,2));
		game.setNextEntity(new abr(250 , -2700,0));
		game.setNextEntity(new abr(500 , -2820,0));
		game.setNextEntity(new abr(430 , -2945,1));
		game.setNextEntity(new abr(325 , -3120,2));
		game.setNextEntity(new abr(550 , -3260,1));
		game.setNextEntity(new abr(100 , -3450,0));
		game.setNextEntity(new abr(345 , -3600,0));
		game.setNextEntity(new abr(500 , -3650,1));
		game.setNextEntity(new abr(300 , -3765,2));
		game.setNextEntity(new abr(150 , -3900,1));
		game.setNextEntity(new abr(350 , -3985,2));
		/*game.setNextEntity(new abr(215 , -4060,1));
		game.setNextEntity(new abr(405 , -4225,0));
		game.setNextEntity(new abr(100 , -4300,1));
		game.setNextEntity(new abr(560 , -4452,1));
		game.setNextEntity(new abr(100 , -4520,2));
		game.setNextEntity(new abr(250 , -4600,0));
		game.setNextEntity(new abr(50 , -4780,1));
		game.setNextEntity(new abr(300 , -4920,1));
		game.setNextEntity(new abr(365 , -5300,0));
		game.setNextEntity(new abr(550 , -5123,0));*/
//////////////////////////////////////////////////////////////////////////////////



	
		
		//sookht
		game.setNextEntity(new fuel(60 , -1000,1));
		game.setNextEntity(new fuel(540 , -2400,0));
		game.setNextEntity(new fuel(325 , -3200,2));

		
////////////////////////////////////////////////////////////////////////////////////////////////////////		

		

		// life
		game.setNextEntity(new emdad(540 , -2500));
		game.setNextEntity(new emdad(100 , -1000));
		game.setNextEntity(new emdad(300 , -2900));

	//////////////////////////////////////////////////////////////////////////////////	
		//tir
		game.setNextEntity(new ragbar(60 , -1000));
		game.setNextEntity(new rocket(540 , -1300));
		game.setNextEntity(new ragbar(200 , -3000));
		game.setNextEntity(new rocket(540 , -3400));
		game.setNextEntity(new ragbar(350 , -3800));

		/////////////////////////////////////////////////////////////////////////////////

		//Static
				game.setNextEntity(new havapeyma(300 , 400));
				
		/////////////////////////////////////////////////////////////////////////
		

	}
	
	private static void LoadMap2(GGame game)
	{
		game.clearEntities();
		// Static GBackground
		
		game.setNextEntity(new GBackground(0 , 0));
		//////////////////////////////////////////////////////////

		
		//jazire
	    game.setNextEntity(new jazire(290 , -390,1));
		game.setNextEntity(new jazire(300 , -550,3));
		game.setNextEntity(new jazire(500 , -900,1));
		game.setNextEntity(new jazire(215 , -1290,0));
		game.setNextEntity(new jazire(190 , -1589,2));
		game.setNextEntity(new jazire(460 , -1900,0));
		game.setNextEntity(new jazire(100 , -2250,3));
		game.setNextEntity(new jazire(260 , -2500,0));
		game.setNextEntity(new jazire(250 , -2700,1));
		game.setNextEntity(new jazire(430 , -2945,1));
		game.setNextEntity(new jazire(550 , -3300,3));
		game.setNextEntity(new jazire(345 , -3600,0));
		game.setNextEntity(new jazire(300 , -3765,2));
		game.setNextEntity(new jazire(100 , -4000,3));
		game.setNextEntity(new jazire(480 , -4560,0));
		game.setNextEntity(new jazire(390 , -4809,1));
		game.setNextEntity(new jazire(100 , -5500,1));
		game.setNextEntity(new jazire(530 , -6000,0));
		game.setNextEntity(new jazire(300 , -6300,2));
		game.setNextEntity(new jazire(80 , -6800,0));
		game.setNextEntity(new jazire(330 , -7000,3));
		game.setNextEntity(new jazire(560 , -7300,1));
		game.setNextEntity(new jazire(90 , -7600,0));
		game.setNextEntity(new jazire(460 , -8000,0));
		game.setNextEntity(new jazire(90 , -8360,1));
		game.setNextEntity(new jazire(540 , -8490,2));
		game.setNextEntity(new jazire(320 , -9200,1));
		game.setNextEntity(new jazire(490 , -9460,3));
		game.setNextEntity(new jazire(220 , -9670,2));

///////////////////////////////////////////////////////////////////////		
		
		
		
		

		//kashti bedoone barkhord
		game.setNextEntity(new k11(550 , -400));
		game.setNextEntity(new k11(100 , -750));
		game.setNextEntity(new k11(300 , -1000));
		game.setNextEntity(new k11(405 , -1350));
		game.setNextEntity(new k21(70 , -2500));
		game.setNextEntity(new k21(590 , -3600));
		game.setNextEntity(new k21(320 , -4500));
		game.setNextEntity(new k11(550 , -5600));
		game.setNextEntity(new k11(100 , -5900));
		game.setNextEntity(new k11(300 , -6200));
		game.setNextEntity(new k11(405 , -6450));
		game.setNextEntity(new k21(70  , -6620));
		game.setNextEntity(new k21(590 , -6800));
		game.setNextEntity(new k21(320 , -7010));
		game.setNextEntity(new k11(550 , -7250));
		game.setNextEntity(new k11(100 , -7600));
		game.setNextEntity(new k11(300 , -7820));
		game.setNextEntity(new k11(405 , -8100));
		game.setNextEntity(new k21(70  , -8360));
		game.setNextEntity(new k21(590 , -8800));
		game.setNextEntity(new k21(320 , -9300));
		game.setNextEntity(new k11(550 , -9650));
		game.setNextEntity(new k11(100 , -9850));
		game.setNextEntity(new k11(300 , -1080));

///////////////////////////////////////////////////////////////////////////////////////
		
		
		
		//keshti doshman
				game.setNextEntity(new k41(500 , -500));
				game.setNextEntity(new k31(540 , -1000));
				game.setNextEntity(new k51(250 , -1000));
				game.setNextEntity(new k41(50 , -1900));
				game.setNextEntity(new k51(450 , -2600));
				game.setNextEntity(new k31(540 , -3400));
				game.setNextEntity(new k61(315 , -3400));
				game.setNextEntity(new k61(100 , -4000));
				game.setNextEntity(new k51(320 , -4500));
				game.setNextEntity(new k61(540 , -4800));
				game.setNextEntity(new k41(80 , -5200));
				game.setNextEntity(new k41(350 , -6000));
				game.setNextEntity(new k51(450 , -6350));
				game.setNextEntity(new k31(540 , -6620));
				game.setNextEntity(new k61(315 , -6900));
				game.setNextEntity(new k61(100 , -7200));
				game.setNextEntity(new k61(500 , -7450));
				game.setNextEntity(new k41(540 , -7800));
				game.setNextEntity(new k51(250 , -7950));
				game.setNextEntity(new k41(50 , -8150));
				game.setNextEntity(new k51(450 , -8450));
				game.setNextEntity(new k51(540 , -8800));
				game.setNextEntity(new k61(315 , -9200));
				game.setNextEntity(new k61(100 , -9500));
				game.setNextEntity(new k41(540 , -9650));
				game.setNextEntity(new k51(250 , -9780));
				game.setNextEntity(new k41(50 , -9920));
				game.setNextEntity(new k51(450 , -10100));
				game.setNextEntity(new k51(540 , -10250));
				game.setNextEntity(new k61(315 , -10300));
				game.setNextEntity(new k61(100 , -10350));
				//////////////////////////////////////////////////////////////////////////////////
		
				
				
				

				// havapeymaye doshman
				
			    game.setNextEntity(new h4(400 , -190));
				game.setNextEntity(new h31(160 , -260));
				game.setNextEntity(new h31(450 , -650));
				game.setNextEntity(new h5(300 , -1200));
				game.setNextEntity(new h4(450 , -1400));
				game.setNextEntity(new h31(90 , -1800));
				game.setNextEntity(new h31(190 , -1890));
				game.setNextEntity(new h21(200 , -2230));
				game.setNextEntity(new h11(420 , -2600));
				game.setNextEntity(new h11(120, -3000));
				game.setNextEntity(new h11(540 , -3300));
				game.setNextEntity(new h5(340 , -3330));
				game.setNextEntity(new h6(540 , -3520));
				game.setNextEntity(new h4(139 , -3620));
				game.setNextEntity(new h21(460 , -3700));
				game.setNextEntity(new h31(220 , -3831));
				game.setNextEntity(new h31(200 , -3920));
				game.setNextEntity(new h6(410 , -4305));
				game.setNextEntity(new h21(380 , -4490));
				game.setNextEntity(new h31(95 , -4660));
				game.setNextEntity(new h4(390 , -4760));
				game.setNextEntity(new h5(500 , -4950));
				game.setNextEntity(new h6(420 , -5050));
				game.setNextEntity(new h4(125 , -5232));
				game.setNextEntity(new h11(260 , -5400));
				game.setNextEntity(new h31(31  , -5680));
				game.setNextEntity(new h5(400 , -5780));
				game.setNextEntity(new h5(160 , -5900));
				game.setNextEntity(new h5(450 , -6150));
				game.setNextEntity(new h4(300 , -6305));
				game.setNextEntity(new h4(450 , -6800));
				game.setNextEntity(new h6(90 , -7000));
				game.setNextEntity(new h6(190 , -7100));
				game.setNextEntity(new h6(200 , -7260));
				game.setNextEntity(new h31(420 , -7350));
				game.setNextEntity(new h31(120, -7420));
				game.setNextEntity(new h21(540 , -7500));
				game.setNextEntity(new h5(340 , -7620));
				game.setNextEntity(new h6(540 , -7735));
				game.setNextEntity(new h4(139 , -7800));
				game.setNextEntity(new h21(460 , -8000));
				game.setNextEntity(new h31(220 , -8235));
				game.setNextEntity(new h31(200 , -8340));
				game.setNextEntity(new h21(410 , -8460));
				game.setNextEntity(new h11(380 , -8690));
				game.setNextEntity(new h6(95 , -8700));
				game.setNextEntity(new h4(390 , -8850));
				game.setNextEntity(new h5(500 , -9000));
				game.setNextEntity(new h11(420 , -9200));
				game.setNextEntity(new h4(125 , -9360));
				game.setNextEntity(new h5(260 , -9500));
				game.setNextEntity(new h4(31  , -9800));
				game.setNextEntity(new h6(31  , -9990));
				game.setNextEntity(new h11(31  , -10150));
				game.setNextEntity(new h31(31  , -10300));
				game.setNextEntity(new h6(90 , -10450));
				game.setNextEntity(new h6(190 , -10600));
				game.setNextEntity(new h6(200 , -10890));
				game.setNextEntity(new h31(420 , -11050));
				game.setNextEntity(new h31(120, -11200));
				game.setNextEntity(new h21(540 , -11450));
				game.setNextEntity(new h5(340 , -11700));
				game.setNextEntity(new h6(540 , -11890));
				game.setNextEntity(new h4(139 , -11950));
				game.setNextEntity(new h21(460 , -12160));
				game.setNextEntity(new h31(220 , -12350));
				game.setNextEntity(new h31(200 , -12400));
				game.setNextEntity(new h21(410 , -12600));
				game.setNextEntity(new h11(380 , -12800));
				game.setNextEntity(new h6(95 , -13050));
				game.setNextEntity(new h4(390 , -13200));
				game.setNextEntity(new h5(500 , -13350));
				game.setNextEntity(new h11(420 , -13600));
				game.setNextEntity(new h4(125 , -13800));
				game.setNextEntity(new h5(260 , -13999));
				game.setNextEntity(new h4(331  , -13999));
				game.setNextEntity(new h6(450  , -13999));
				game.setNextEntity(new h11(31  , -13999));
				game.setNextEntity(new h31(540  , -13999));

			
				
			
				
				
				////////////////////////////////////////////////////////////////////////////
		
		
		
		
		//abr 
		
		game.setNextEntity(new abr(100 , -100,2));
		game.setNextEntity(new abr(250 , -200,0));
		game.setNextEntity(new abr(500 , -300,0));
		game.setNextEntity(new abr(430 , -305,1));
		game.setNextEntity(new abr(325 , -365,2));
		game.setNextEntity(new abr(550 , -370,1));
		game.setNextEntity(new abr(100 , -390,0));
		game.setNextEntity(new abr(345 , -430,0));
		game.setNextEntity(new abr(500 , -550,1));
		game.setNextEntity(new abr(300 , -680,2));
		game.setNextEntity(new abr(150 , -900,1));
		game.setNextEntity(new abr(350 , -1050,2));
		game.setNextEntity(new abr(215 , -1200,1));
		game.setNextEntity(new abr(405 , -1290,0));
		game.setNextEntity(new abr(100 , -1400,1));
		game.setNextEntity(new abr(460 , -1490,1));
		game.setNextEntity(new abr(100 , -1589,2));
		game.setNextEntity(new abr(250 , -1700,0));
		game.setNextEntity(new abr(50 , -1900,1));
		game.setNextEntity(new abr(300 , -2050,1));
		game.setNextEntity(new abr(365 , -2250,0));
		game.setNextEntity(new abr(600 , -2500,0));
		game.setNextEntity(new abr(100 , -2650,2));
		game.setNextEntity(new abr(250 , -2700,0));
		game.setNextEntity(new abr(500 , -2820,0));
		game.setNextEntity(new abr(430 , -2945,1));
		game.setNextEntity(new abr(325 , -3120,2));
		game.setNextEntity(new abr(550 , -3260,1));
		game.setNextEntity(new abr(100 , -3450,0));
		game.setNextEntity(new abr(345 , -3600,0));
		game.setNextEntity(new abr(500 , -3650,1));
		game.setNextEntity(new abr(300 , -3765,2));
		game.setNextEntity(new abr(150 , -3900,1));
		game.setNextEntity(new abr(350 , -3985,2));
		game.setNextEntity(new abr(215 , -4060,1));
		game.setNextEntity(new abr(405 , -4225,0));
		game.setNextEntity(new abr(100 , -4300,1));
		game.setNextEntity(new abr(560 , -4452,1));
		game.setNextEntity(new abr(100 , -4520,2));
		game.setNextEntity(new abr(250 , -4600,0));
		game.setNextEntity(new abr(50 , -4780,1));
		game.setNextEntity(new abr(300 , -4920,1));
		game.setNextEntity(new abr(365 , -5300,0));
		game.setNextEntity(new abr(550 , -5123,0));
		game.setNextEntity(new abr(250 , -5250,0));
		game.setNextEntity(new abr(500 , -5390,1));
		game.setNextEntity(new abr(430 , -5480,1));
		game.setNextEntity(new abr(325 , -5690,2));
		game.setNextEntity(new abr(550 , -5780,1));
		game.setNextEntity(new abr(100 , -5840,0));
		game.setNextEntity(new abr(345 , -6100,0));
		game.setNextEntity(new abr(500 , -6250,1));
		game.setNextEntity(new abr(300 , -6380,2));
		game.setNextEntity(new abr(150 , -6500,1));
		game.setNextEntity(new abr(350 , -6580,2));
		game.setNextEntity(new abr(215 , -6590,0));
		game.setNextEntity(new abr(425 , -6680,0));
		game.setNextEntity(new abr(215 , -6750,1));
		game.setNextEntity(new abr(405 , -6800,0));
		game.setNextEntity(new abr(100 , -6890,1));
		game.setNextEntity(new abr(560 , -6950 ,2));
		game.setNextEntity(new abr(100 , -7100,2));
		game.setNextEntity(new abr(250 , -7250,0));
		game.setNextEntity(new abr(50 , -7320,1));
		game.setNextEntity(new abr(300 , -7430,1));
		game.setNextEntity(new abr(365 , -7550,0));
		game.setNextEntity(new abr(550 , -7750,0));
		game.setNextEntity(new abr(100 , -7900,2));
		game.setNextEntity(new abr(250 , -8050,0));
		game.setNextEntity(new abr(500 , -8220,0));
		game.setNextEntity(new abr(430 , -8350,1));
		game.setNextEntity(new abr(325 , -8420,2));
		game.setNextEntity(new abr(550 , -8530,1));
		game.setNextEntity(new abr(100 , -8610,0));
		game.setNextEntity(new abr(345 , -8700,0));
		game.setNextEntity(new abr(500 , -8805,1));
		game.setNextEntity(new abr(300 , -9000,2));
		game.setNextEntity(new abr(150 , -9150,1));
		game.setNextEntity(new abr(350 , -9220,2));
		game.setNextEntity(new abr(215 , -9350,1));
		game.setNextEntity(new abr(405 , -9460,0));
		game.setNextEntity(new abr(100 , -9500,1));
		game.setNextEntity(new abr(560 , -9610,1));
		game.setNextEntity(new abr(100 , -9735,2));
		game.setNextEntity(new abr(250 , -9800,0));
		game.setNextEntity(new abr(50 , -9885,1));
		game.setNextEntity(new abr(300 , -9950,1));
		game.setNextEntity(new abr(365 , -10000,0));
		game.setNextEntity(new abr(550 , -10012,0));
		
		
/////////////////////////////////////////////////////////////

		
		


		
		
		//sookht
		game.setNextEntity(new fuel(100 , -1000,1));
		game.setNextEntity(new fuel(540 , -2400,3));
		game.setNextEntity(new fuel(325 , -3800,2));
		game.setNextEntity(new fuel(100 , -4500,4));
		game.setNextEntity(new fuel(540 , -6000,1));
		game.setNextEntity(new fuel(325 , -6800,2));
		game.setNextEntity(new fuel(100 , -7100,1));
		game.setNextEntity(new fuel(540 , -7500,3));
		game.setNextEntity(new fuel(325 , -7900,0));
		game.setNextEntity(new fuel(100 , -8300,4));
		game.setNextEntity(new fuel(540 , -8700,0));
		game.setNextEntity(new fuel(325 , -9200,3));
		game.setNextEntity(new fuel(100 , -9400,3));
		game.setNextEntity(new fuel(540 , -9750,4));
		game.setNextEntity(new fuel(325 , -10000,2));
		game.setNextEntity(new fuel(100 , -10100,4));
		game.setNextEntity(new fuel(540 , -8900,0));
		game.setNextEntity(new fuel(100 , -9500,3));
		game.setNextEntity(new fuel(540 , -10250,4));
		//game.setNextEntity(new fuel(100 , -10460,3));
		//game.setNextEntity(new fuel(460 , -10590,0));
		game.setNextEntity(new fuel(230 , -10690,1));
		//game.setNextEntity(new fuel(540 , -10900,0));
		game.setNextEntity(new fuel(300 , -11400,2));
		//game.setNextEntity(new fuel(100 , -11560,3));
		game.setNextEntity(new fuel(390 , -11700,4));
		/*game.setNextEntity(new fuel(476 , -12000,0));
		game.setNextEntity(new fuel(400 , -12560,1));
		game.setNextEntity(new fuel(100 , -12600,0));
		game.setNextEntity(new fuel(540 , -12800,2));
		game.setNextEntity(new fuel(260 , -13200,3));
		game.setNextEntity(new fuel(320 , -13350,4));
		//game.setNextEntity(new fuel(125 , -13690,5));
		game.setNextEntity(new fuel(425 , -13980,1));*/

		

		// life
		game.setNextEntity(new emdad(540 , -500));
		game.setNextEntity(new emdad(100 , -1000));
		game.setNextEntity(new emdad(400 , -2500));
		game.setNextEntity(new emdad(520 , -3000));
		game.setNextEntity(new emdad(50 , -3500));
		game.setNextEntity(new emdad(435 , -4000));
		game.setNextEntity(new emdad(190 , -4600));
		game.setNextEntity(new emdad(490 , -4900));
		game.setNextEntity(new emdad(436 , -5200));
		game.setNextEntity(new emdad(560 , -5500));
		game.setNextEntity(new emdad(125 , -6000));
		game.setNextEntity(new emdad(290 , -6300));
		game.setNextEntity(new emdad(365 , -6400));
		game.setNextEntity(new emdad(570 , -6700));
		game.setNextEntity(new emdad(300 , -6800));
		game.setNextEntity(new emdad(340 , -6950));
		game.setNextEntity(new emdad(460 , -7200));
		game.setNextEntity(new emdad(200 , -7800));
		game.setNextEntity(new emdad(380 , -8000));
		game.setNextEntity(new emdad(180 , -8200));
		game.setNextEntity(new emdad(340 , -3000));
		game.setNextEntity(new emdad(460 , -4000));
		game.setNextEntity(new emdad(200 , -5000));
		game.setNextEntity(new emdad(380 , -7000));
		game.setNextEntity(new emdad(180 , -9000));
		
		
		
		game.setNextEntity(new emdad(540 , -9300));
		game.setNextEntity(new emdad(100 , -9550));
		game.setNextEntity(new emdad(400 , -9750));
		game.setNextEntity(new emdad(520 , -10000));
		game.setNextEntity(new emdad(50 , -10300));
		game.setNextEntity(new emdad(435 , -10750));
		game.setNextEntity(new emdad(190 , -11000));
		game.setNextEntity(new emdad(490 , -11360));
		game.setNextEntity(new emdad(436 , -11800));
		/*game.setNextEntity(new emdad(560 , -12300));
		game.setNextEntity(new emdad(125 , -12690));
		game.setNextEntity(new emdad(290 , -13000));*/
		

		
		//tir
		/////////       ragbar
		game.setNextEntity(new ragbar(60 , -1000));
		game.setNextEntity(new ragbar(200 , -2000));
		game.setNextEntity(new ragbar(350 , -3450));
		game.setNextEntity(new ragbar(60 , -4000));
		game.setNextEntity(new ragbar(200 , -5000));
		game.setNextEntity(new ragbar(350 , -6000));
		game.setNextEntity(new ragbar(60 , -6300));
		game.setNextEntity(new ragbar(200 , -6700));
		game.setNextEntity(new ragbar(350 , -7400));
		game.setNextEntity(new ragbar(60 , -7890));
		game.setNextEntity(new ragbar(200 , -8600));
		game.setNextEntity(new ragbar(350 , -9600));
		game.setNextEntity(new ragbar(350 , -9750));
		game.setNextEntity(new ragbar(60 , -9860));
		game.setNextEntity(new ragbar(200 , -1090));
		game.setNextEntity(new ragbar(350 , -10300));
		
		game.setNextEntity(new ragbar(230 , -10600));
		game.setNextEntity(new ragbar(350 , -11000));
		game.setNextEntity(new ragbar(460 , -11400));

		////////////  Mooshak
		game.setNextEntity(new rocket(290 , -1300));
		game.setNextEntity(new rocket(120 , -2800));
		game.setNextEntity(new rocket(300 , -4300));
		game.setNextEntity(new rocket(540 , -5700));
		game.setNextEntity(new rocket(300 , -6450));
		game.setNextEntity(new rocket(460 , -10220));
		game.setNextEntity(new rocket(90 , -8200));
		game.setNextEntity(new rocket(320 , -9990));
		game.setNextEntity(new rocket(540 , -8900));
		game.setNextEntity(new rocket(200 , -6450));
		game.setNextEntity(new rocket(540 , -6900));
		
		game.setNextEntity(new rocket(350 , -7350));
		game.setNextEntity(new rocket(100 , -8000));
		
		game.setNextEntity(new rocket(350 , -8500));
		game.setNextEntity(new rocket(100 , -9000));
		game.setNextEntity(new rocket(350 , -9800));
		game.setNextEntity(new rocket(100 , -10300));

		//Static
				game.setNextEntity(new havapeyma(300 , 400));
		/////////////////////////////////////////////////////////////////////////

	}
	
	
	private static void LoadMap3(GGame game)
	{
		game.clearEntities();
		// Static GBackground
		game.setNextEntity(new GBackground(0 , 0));
		
		
		
		
		///////////////////////////////////////////////////////////////
		
		
		///////// bomb
		game.setNextEntity(new bomb(290 , -390));
		game.setNextEntity(new bomb(300 , -550));
		game.setNextEntity(new bomb(500 , -900));
		game.setNextEntity(new bomb(215 , -1290));
		game.setNextEntity(new bomb(190 , -1589));
		game.setNextEntity(new bomb(460 , -1900));
		game.setNextEntity(new bomb(100 , -2250));
		game.setNextEntity(new bomb(260 , -2500));
		game.setNextEntity(new bomb(250 , -2700));
		game.setNextEntity(new bomb(430 , -2945));
		game.setNextEntity(new bomb(550 , -3300));
		game.setNextEntity(new bomb(345 , -3600));
		game.setNextEntity(new bomb(300 , -3765));
		game.setNextEntity(new bomb(100 , -4000));
		game.setNextEntity(new bomb(480 , -4560));
		game.setNextEntity(new bomb(390 , -4809));
		game.setNextEntity(new bomb(100 , -5500));
		game.setNextEntity(new bomb(530 , -6000));
		game.setNextEntity(new bomb(300 , -6300));
		game.setNextEntity(new bomb(80 , -6800));
		game.setNextEntity(new bomb(330 , -7000));
		game.setNextEntity(new bomb(560 , -7300));
		game.setNextEntity(new bomb(90 , -7600));
		game.setNextEntity(new bomb(460 , -8000));
		game.setNextEntity(new bomb(90 , -8360));
		game.setNextEntity(new bomb(540 , -8490));
		game.setNextEntity(new bomb(320 , -9200));
		game.setNextEntity(new bomb(490 , -9460));
		game.setNextEntity(new bomb(220 , -9670));
		
		
		game.setNextEntity(new bomb(550 , -400));
		game.setNextEntity(new bomb(100 , -750));
		game.setNextEntity(new bomb(300 , -1000));
		game.setNextEntity(new bomb(405 , -1350));
		game.setNextEntity(new bomb(70 , -2500));
		game.setNextEntity(new bomb(590 , -3600));
		game.setNextEntity(new bomb(320 , -4500));
		game.setNextEntity(new bomb(550 , -5600));
		game.setNextEntity(new bomb(100 , -5900));
		game.setNextEntity(new bomb(300 , -6200));
		game.setNextEntity(new bomb(405 , -6450));
		game.setNextEntity(new bomb(70  , -6620));
		game.setNextEntity(new bomb(590 , -6800));
		game.setNextEntity(new bomb(320 , -7010));
		game.setNextEntity(new bomb(550 , -7250));
		game.setNextEntity(new bomb(100 , -7600));
		game.setNextEntity(new bomb(300 , -7820));
		game.setNextEntity(new bomb(405 , -8100));
		game.setNextEntity(new bomb(70  , -8360));
		game.setNextEntity(new bomb(590 , -8800));
		game.setNextEntity(new bomb(320 , -9300));
		game.setNextEntity(new bomb(550 , -9650));
		game.setNextEntity(new bomb(100 , -9850));
		game.setNextEntity(new bomb(300 , -1080));
	
		 game.setNextEntity(new bomb(400 , -190));
		 game.setNextEntity(new bomb(160 , -260));
	 	 game.setNextEntity(new bomb(450 , -650));
		 game.setNextEntity(new bomb(300 , -1200));
		 game.setNextEntity(new bomb(450 , -1400));
		 game.setNextEntity(new bomb(90 , -1800));
	 	 game.setNextEntity(new bomb(190 , -1890));
		 game.setNextEntity(new bomb(200 , -2230));
		 game.setNextEntity(new bomb(420 , -2600));
		 game.setNextEntity(new bomb(120, -3000));
		 game.setNextEntity(new bomb(540 , -3300));
		 game.setNextEntity(new bomb(340 , -3330));
		 game.setNextEntity(new bomb(540 , -3520));
		 game.setNextEntity(new bomb(139 , -3620));
		 game.setNextEntity(new bomb(460 , -3700));
		 game.setNextEntity(new bomb(220 , -3831));
		 game.setNextEntity(new bomb(200 , -3920));
		 game.setNextEntity(new bomb(410 , -4305));
		 game.setNextEntity(new bomb(380 , -4490));
		 game.setNextEntity(new bomb(95 , -4660));
		 game.setNextEntity(new bomb(390 , -4760));
		 game.setNextEntity(new bomb(500 , -4950));
		 game.setNextEntity(new bomb(420 , -5050));
		 game.setNextEntity(new bomb(125 , -5232));
		 game.setNextEntity(new bomb(260 , -5400));
		 game.setNextEntity(new bomb(31  , -5680));
		 game.setNextEntity(new bomb(400 , -5780));
		 game.setNextEntity(new bomb(160 , -5900));
		 game.setNextEntity(new bomb(450 , -6150));
		 game.setNextEntity(new bomb(300 , -6305));
		 game.setNextEntity(new bomb(450 , -6800));
		 game.setNextEntity(new bomb(90 , -7000));
		 game.setNextEntity(new bomb(190 , -7100));
		 game.setNextEntity(new bomb(200 , -7260));
		 game.setNextEntity(new bomb(420 , -7350));
		 game.setNextEntity(new bomb(120, -7420));
		 game.setNextEntity(new bomb(540 , -7500));
		 game.setNextEntity(new bomb(340 , -7620));
		 game.setNextEntity(new bomb(540 , -7735));
		 game.setNextEntity(new bomb(139 , -7800));
		 game.setNextEntity(new bomb(460 , -8000));
		 game.setNextEntity(new bomb(220 , -8235));
		 game.setNextEntity(new bomb(200 , -8340));
		 game.setNextEntity(new bomb(410 , -8460));
		 game.setNextEntity(new bomb(380 , -8690));
		 game.setNextEntity(new bomb(95 , -8700));
		 game.setNextEntity(new bomb(390 , -8850));
		 game.setNextEntity(new bomb(500 , -9000));
		 game.setNextEntity(new bomb(420 , -9200));
		 game.setNextEntity(new bomb(125 , -9360));
		 game.setNextEntity(new bomb(260 , -9500));
		 game.setNextEntity(new bomb(31  , -9800));
		 game.setNextEntity(new bomb(31  , -9990));
		 game.setNextEntity(new bomb(31  , -10150));
		 game.setNextEntity(new bomb(31  , -10300));
		 game.setNextEntity(new bomb(90 , -10450));
		 game.setNextEntity(new bomb(190 , -10600));
		 game.setNextEntity(new bomb(200 , -10890));
		 game.setNextEntity(new bomb(420 , -11050));
		 game.setNextEntity(new bomb(120, -11200));
		 game.setNextEntity(new bomb(540 , -11450));
		 game.setNextEntity(new bomb(340 , -11700));
		 game.setNextEntity(new bomb(540 , -11890));
		 game.setNextEntity(new bomb(139 , -11950));
		 game.setNextEntity(new bomb(460 , -12160));
		 game.setNextEntity(new bomb(220 , -12350));
		 game.setNextEntity(new bomb(200 , -12400));
		 game.setNextEntity(new bomb(410 , -12600));
		 game.setNextEntity(new bomb(380 , -12800));
		 game.setNextEntity(new bomb(95 , -13050));
		 game.setNextEntity(new bomb(390 , -13200));
		 game.setNextEntity(new bomb(500 , -13350));
		 game.setNextEntity(new bomb(420 , -13600));
		 game.setNextEntity(new bomb(125 , -13800));
		 game.setNextEntity(new bomb(260 , -13999));
		 game.setNextEntity(new bomb(331  , -13999));
		 game.setNextEntity(new bomb(450  , -13999));
		 game.setNextEntity(new bomb(31  , -13999));
		 game.setNextEntity(new bomb(540  , -13999));
		///////////////////////////////////////////////////////
		
		//static
				game.setNextEntity(new hb(400 , 0));
		
		///////////////////////////////////////////////////////
				
		//////havapeyma doshman
		 game.setNextEntity(new h31(95 , -4660));
		 game.setNextEntity(new h4(390 , -4760));
		 game.setNextEntity(new h5(500 , -4950));
		 game.setNextEntity(new h6(420 , -5050));
		 game.setNextEntity(new h4(125 , -5232));
		 game.setNextEntity(new h11(260 , -5400));
		 game.setNextEntity(new h31(31  , -5680));
		 game.setNextEntity(new h5(400 , -5780));
		 game.setNextEntity(new h5(160 , -5900));
		 game.setNextEntity(new h5(450 , -6150));
		 game.setNextEntity(new h4(300 , -6305));
		 game.setNextEntity(new h4(450 , -6800));
		 game.setNextEntity(new h6(90 , -7000));
		 game.setNextEntity(new h6(190 , -7100));
		 game.setNextEntity(new h6(200 , -7260));
		 game.setNextEntity(new h31(420 , -7350));
				
				
				
				
				
				
		///// abr
		game.setNextEntity(new abr(100 , -100,2));
		game.setNextEntity(new abr(250 , -200,0));
		game.setNextEntity(new abr(500 , -300,0));
		game.setNextEntity(new abr(430 , -305,1));
		game.setNextEntity(new abr(325 , -365,2));
		game.setNextEntity(new abr(550 , -370,1));
		game.setNextEntity(new abr(100 , -390,0));
		game.setNextEntity(new abr(345 , -430,0));
		game.setNextEntity(new abr(500 , -550,1));
		game.setNextEntity(new abr(300 , -680,2));
		game.setNextEntity(new abr(150 , -900,1));
		game.setNextEntity(new abr(350 , -1050,2));
		game.setNextEntity(new abr(215 , -1200,1));
		game.setNextEntity(new abr(405 , -1290,0));
		game.setNextEntity(new abr(100 , -1400,1));
		game.setNextEntity(new abr(460 , -1490,1));
		game.setNextEntity(new abr(100 , -1589,2));
		game.setNextEntity(new abr(250 , -1700,0));
		game.setNextEntity(new abr(50 , -1900,1));
		game.setNextEntity(new abr(300 , -2050,1));
		game.setNextEntity(new abr(365 , -2250,0));
		game.setNextEntity(new abr(600 , -2500,0));
		game.setNextEntity(new abr(100 , -2650,2));
		game.setNextEntity(new abr(250 , -2700,0));
		game.setNextEntity(new abr(500 , -2820,0));
		game.setNextEntity(new abr(430 , -2945,1));
		game.setNextEntity(new abr(325 , -3120,2));
		game.setNextEntity(new abr(550 , -3260,1));
		game.setNextEntity(new abr(100 , -3450,0));
		game.setNextEntity(new abr(345 , -3600,0));
		game.setNextEntity(new abr(500 , -3650,1));
		game.setNextEntity(new abr(300 , -3765,2));
		game.setNextEntity(new abr(150 , -3900,1));
		game.setNextEntity(new abr(350 , -3985,2));
		game.setNextEntity(new abr(215 , -4060,1));
		game.setNextEntity(new abr(405 , -4225,0));
		game.setNextEntity(new abr(100 , -4300,1));
		game.setNextEntity(new abr(560 , -4452,1));
		game.setNextEntity(new abr(100 , -4520,2));
		game.setNextEntity(new abr(250 , -4600,0));
		game.setNextEntity(new abr(50 , -4780,1));
		game.setNextEntity(new abr(300 , -4920,1));
		game.setNextEntity(new abr(365 , -5300,0));
		game.setNextEntity(new abr(550 , -5123,0));
		game.setNextEntity(new abr(250 , -5250,0));
		game.setNextEntity(new abr(500 , -5390,1));
		game.setNextEntity(new abr(430 , -5480,1));
		game.setNextEntity(new abr(325 , -5690,2));
		game.setNextEntity(new abr(550 , -5780,1));
		game.setNextEntity(new abr(100 , -5840,0));
		game.setNextEntity(new abr(345 , -6100,0));
		game.setNextEntity(new abr(500 , -6250,1));
		game.setNextEntity(new abr(300 , -6380,2));
		game.setNextEntity(new abr(150 , -6500,1));
		game.setNextEntity(new abr(350 , -6580,2));
		game.setNextEntity(new abr(215 , -6590,0));
		game.setNextEntity(new abr(425 , -6680,0));
		game.setNextEntity(new abr(215 , -6750,1));
		game.setNextEntity(new abr(405 , -6800,0));
		game.setNextEntity(new abr(100 , -6890,1));
		game.setNextEntity(new abr(560 , -6950 ,2));
		game.setNextEntity(new abr(100 , -7100,2));
		game.setNextEntity(new abr(250 , -7250,0));
		game.setNextEntity(new abr(50 , -7320,1));
		game.setNextEntity(new abr(300 , -7430,1));
		game.setNextEntity(new abr(365 , -7550,0));
		game.setNextEntity(new abr(550 , -7750,0));
		game.setNextEntity(new abr(100 , -7900,2));
		game.setNextEntity(new abr(250 , -8050,0));
		game.setNextEntity(new abr(500 , -8220,0));
		game.setNextEntity(new abr(430 , -8350,1));
		game.setNextEntity(new abr(325 , -8420,2));
		game.setNextEntity(new abr(550 , -8530,1));
		game.setNextEntity(new abr(100 , -8610,0));
		game.setNextEntity(new abr(345 , -8700,0));
		game.setNextEntity(new abr(500 , -8805,1));
		game.setNextEntity(new abr(300 , -9000,2));
		game.setNextEntity(new abr(150 , -9150,1));
		game.setNextEntity(new abr(350 , -9220,2));
		game.setNextEntity(new abr(215 , -9350,1));
		game.setNextEntity(new abr(405 , -9460,0));
		game.setNextEntity(new abr(100 , -9500,1));
		game.setNextEntity(new abr(560 , -9610,1));
		game.setNextEntity(new abr(100 , -9735,2));
		game.setNextEntity(new abr(250 , -9800,0));
		game.setNextEntity(new abr(50 , -9885,1));
		game.setNextEntity(new abr(300 , -9950,1));
		game.setNextEntity(new abr(365 , -10000,0));
		game.setNextEntity(new abr(550 , -10012,0));
		

		/////////////////////////////////////////////////////////////////////
		
		
		//sookht
		game.setNextEntity(new fuel(300 , -500,1));
		game.setNextEntity(new fuel(100 , -1000,1));
		game.setNextEntity(new fuel(150 , -2300,3));
		game.setNextEntity(new fuel(540 , -2400,3));
		game.setNextEntity(new fuel(540 , -3000,3));
		game.setNextEntity(new fuel(450 , -3500,2));
		game.setNextEntity(new fuel(325 , -3800,2));
		game.setNextEntity(new fuel(100 , -4500,4));
		game.setNextEntity(new fuel(490 , -4600,4));
		game.setNextEntity(new fuel(120 , -5600,1));
		game.setNextEntity(new fuel(540 , -6000,1));
		game.setNextEntity(new fuel(325 , -6800,2));
		game.setNextEntity(new fuel(100 , -7100,1));
		game.setNextEntity(new fuel(400 , -7200,1));
		game.setNextEntity(new fuel(540 , -7500,3));
		game.setNextEntity(new fuel(320 , -7650,3));
		game.setNextEntity(new fuel(100 , -7900,0));
		game.setNextEntity(new fuel(325 , -8000,0));
		game.setNextEntity(new fuel(100 , -8300,4));
		game.setNextEntity(new fuel(540 , -8360,4));
		game.setNextEntity(new fuel(210 , -8700,0));
		game.setNextEntity(new fuel(540 , -8950,0));
		game.setNextEntity(new fuel(325 , -9200,3));
		game.setNextEntity(new fuel(128 , -9350,3));
		game.setNextEntity(new fuel(100 , -9400,3));
		game.setNextEntity(new fuel(360 , -9560,3));
		game.setNextEntity(new fuel(540 , -9750,4));
		game.setNextEntity(new fuel(325 , -10000,2));
		game.setNextEntity(new fuel(540 , -10000,2));
		game.setNextEntity(new fuel(100 , -10100,4));
		game.setNextEntity(new fuel(250 , -10100,3));
		game.setNextEntity(new fuel(320 , -8900,0));
		game.setNextEntity(new fuel(120 , -8900,0));
		game.setNextEntity(new fuel(430 , -9500,3));
		game.setNextEntity(new fuel(100 , -9150,3));
		game.setNextEntity(new fuel(310 , -10340,4));
		game.setNextEntity(new fuel(540 , -10250,4));
		

		// life
		game.setNextEntity(new emdad(540 , -500));
		game.setNextEntity(new emdad(100 , -1000));
		game.setNextEntity(new emdad(400 , -2500));
		game.setNextEntity(new emdad(520 , -3000));
		game.setNextEntity(new emdad(50 , -3500));
		game.setNextEntity(new emdad(435 , -4000));
		game.setNextEntity(new emdad(190 , -4600));
		game.setNextEntity(new emdad(490 , -4900));
		game.setNextEntity(new emdad(436 , -5200));
		game.setNextEntity(new emdad(560 , -5500));
		game.setNextEntity(new emdad(125 , -6000));
		game.setNextEntity(new emdad(290 , -6300));
		game.setNextEntity(new emdad(365 , -6400));
		game.setNextEntity(new emdad(570 , -6700));
		game.setNextEntity(new emdad(300 , -6800));
		game.setNextEntity(new emdad(340 , -6950));
		game.setNextEntity(new emdad(460 , -7200));
		game.setNextEntity(new emdad(200 , -7800));
		game.setNextEntity(new emdad(380 , -8000));
		game.setNextEntity(new emdad(180 , -8200));
		game.setNextEntity(new emdad(340 , -3000));
		game.setNextEntity(new emdad(460 , -4000));
		game.setNextEntity(new emdad(200 , -5000));
		game.setNextEntity(new emdad(380 , -7000));
		game.setNextEntity(new emdad(180 , -9000));
		game.setNextEntity(new emdad(460 , -9150));
		game.setNextEntity(new emdad(200 , -9350));
		game.setNextEntity(new emdad(380 , -9460));
		game.setNextEntity(new emdad(180 , -9790));
		game.setNextEntity(new emdad(340 , -10000));
		game.setNextEntity(new emdad(460 , -10150));
		game.setNextEntity(new emdad(200 , -10350));
		game.setNextEntity(new emdad(380 , -10590));
		game.setNextEntity(new emdad(180 , -10750));
		
		game.setNextEntity(new emdad(460 , -10900));
		game.setNextEntity(new emdad(200 , -11000));
		game.setNextEntity(new emdad(380 , -11260));
		game.setNextEntity(new emdad(180 , -11450));
		game.setNextEntity(new emdad(340 , -11800));
		game.setNextEntity(new emdad(460 , -12200));
		game.setNextEntity(new emdad(200 , -12500));
		game.setNextEntity(new emdad(380 , -12900));
		game.setNextEntity(new emdad(180 , -13400));
		
		game.setNextEntity(new emdad(460 , -13500));
		game.setNextEntity(new emdad(200 , -13460));
		game.setNextEntity(new emdad(380 , -13700));
		game.setNextEntity(new emdad(180 , -13860));
		game.setNextEntity(new emdad(340 , -13900));
		game.setNextEntity(new emdad(460 , -13950));
		game.setNextEntity(new emdad(200 , -13995));
		
		

		
		//tir
		/////////       ragbar
		game.setNextEntity(new ragbar(120 , -250));
		game.setNextEntity(new ragbar(445 , -450));
		game.setNextEntity(new ragbar(350 , -900));

		game.setNextEntity(new ragbar(60 , -1000));
		game.setNextEntity(new ragbar(540 , -1300));
		game.setNextEntity(new ragbar(360 , -1650));
		game.setNextEntity(new ragbar(200 , -2000));
		game.setNextEntity(new ragbar(350 , -2240));
		game.setNextEntity(new ragbar(400 , -2500));
		game.setNextEntity(new ragbar(100 , -2700));
		game.setNextEntity(new ragbar(350 , -3150));
		game.setNextEntity(new ragbar(540 , -3400));
		game.setNextEntity(new ragbar(60 , -3800));
		game.setNextEntity(new ragbar(350 , -4000));
		game.setNextEntity(new ragbar(540 , -4300));
		game.setNextEntity(new ragbar(360 , -4750));
		game.setNextEntity(new ragbar(200 , -5000));
		game.setNextEntity(new ragbar(350 , -6300));
		game.setNextEntity(new ragbar(120 , -6800));
		game.setNextEntity(new ragbar(60 , -6950));

		game.setNextEntity(new ragbar(350 , -7200));
		game.setNextEntity(new ragbar(500 , -7490));
		game.setNextEntity(new ragbar(60 , -7890));
		game.setNextEntity(new ragbar(395 , -8300));
		game.setNextEntity(new ragbar(200 , -8600));
		game.setNextEntity(new ragbar(390 , -8950));
		game.setNextEntity(new ragbar(120 , -9300));
		game.setNextEntity(new ragbar(520 , -9500));
		game.setNextEntity(new ragbar(350 , -9750));
		game.setNextEntity(new ragbar(60 , -9860));
		game.setNextEntity(new ragbar(200 , -10200));
		game.setNextEntity(new ragbar(520 , -10300));
		game.setNextEntity(new ragbar(350 , -10400));
		game.setNextEntity(new ragbar(100 , -10560));
		game.setNextEntity(new ragbar(490 , -10800));
		game.setNextEntity(new ragbar(260 , -11100));
		game.setNextEntity(new ragbar(350 , -11500));
		game.setNextEntity(new ragbar(80 , -11900));
		game.setNextEntity(new ragbar(470 , -12000));

////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		////////////  Mooshak
		game.setNextEntity(new rocket(290 , -250));
		game.setNextEntity(new rocket(120 , -480));
		game.setNextEntity(new rocket(300 , -800));
		game.setNextEntity(new rocket(540 , -1300));
		game.setNextEntity(new rocket(300 , -1500));
		game.setNextEntity(new rocket(460 , -1700));
		game.setNextEntity(new rocket(90 , -1900));
		game.setNextEntity(new rocket(320 , -2150));
		game.setNextEntity(new rocket(540 , -2300));
		game.setNextEntity(new rocket(200 , -2650));
		game.setNextEntity(new rocket(540 , -3300));
		
		game.setNextEntity(new rocket(290 , -3800));
		game.setNextEntity(new rocket(120 , -4350));
		game.setNextEntity(new rocket(300 , -4900));
		game.setNextEntity(new rocket(540 , -5400));
		game.setNextEntity(new rocket(300 , -5670));
		game.setNextEntity(new rocket(460 , -5900));
		game.setNextEntity(new rocket(90 , -6300));
		game.setNextEntity(new rocket(320 , -6700));
		game.setNextEntity(new rocket(540 , -7200));
		game.setNextEntity(new rocket(200 , -7900));
		game.setNextEntity(new rocket(540 , -8300));
		
		game.setNextEntity(new rocket(290 , -9200));
		game.setNextEntity(new rocket(120 , -10000));
		game.setNextEntity(new rocket(300 , -10350));
		game.setNextEntity(new rocket(540 , -10900));
		game.setNextEntity(new rocket(300 , -11350));
		game.setNextEntity(new rocket(460 , -11900));
		game.setNextEntity(new rocket(90 , -12250));
		game.setNextEntity(new rocket(320 , -12600));
		game.setNextEntity(new rocket(540 , -13000));
		game.setNextEntity(new rocket(200 , -13300));
		game.setNextEntity(new rocket(290 , -1300));
		game.setNextEntity(new rocket(120 , -2800));
		game.setNextEntity(new rocket(300 , -4300));
		game.setNextEntity(new rocket(540 , -5700));
		game.setNextEntity(new rocket(300 , -6450));
		game.setNextEntity(new rocket(460 , -10220));
		game.setNextEntity(new rocket(90 , -8200));
		game.setNextEntity(new rocket(320 , -9990));
		game.setNextEntity(new rocket(540 , -8900));
		game.setNextEntity(new rocket(200 , -6450));
		game.setNextEntity(new rocket(540 , -6900));
		/////////////////////////////////////////////////////////////////
		
		// Static part
		game.setNextEntity(new havapeyma(300 , 400));
		//////////////////////////////////////////////////
		
	}
	
	
	
}
