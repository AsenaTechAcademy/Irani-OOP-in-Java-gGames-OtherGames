
public class Mooshak extends GameMovableElementAdapter 
{
	public Mooshak(int x , int y)
	{
		super("Images/mooshak.gif" , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , 0 ,
				GameConstants.Game_Height-this.getHeight());
		this.setSpeedX(0);
		this.setSpeedY(6);
		this.setUpDirection();
		this.StartMoving();
		
	}
	
	protected void CollideUpBorder()
	{
		this.Destroy();
	}
	
	public void CollideWith(GameElementAdapter element)
	{if(element instanceof k11||element instanceof abr||element instanceof Bullet||element instanceof jazire ||element instanceof Mooshak
			||element instanceof k21 )
		return;
		else
		this.Destroy();
	}

}
