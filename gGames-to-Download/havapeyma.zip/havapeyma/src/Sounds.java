public class Sounds
{
	public final static String	Fire	="Sounds/Fire.wav";
	public final static String	Score	="Sounds/Score.wav";
	public final static String	S	="Sounds/Speech On.wav";
	public final static String	ragbar	="Sounds/ragbar.wav";
	public final static String	level	="Sounds/start1.wav";
	public final static String	start	="Sounds/start2.wav";
	public final static String	Mooshak	="Sounds/Mooshak3.wav";
	public final static String	lose	="Sounds/levelup.wav";
	public final static String	matn1	="Sounds/matn1.wav";
	public final static String	matn2	="Sounds/matn2.wav";
	public final static String	matn3	="Sounds/matn3.wav";
	public final static String	khragbar	="Sounds/khragbar.wav";
	public final static String	khmooshak	="Sounds/khmooshak.wav";
	public final static String	sookht	="Sounds/sookht.wav";
	public final static String	galb	="Sounds/galb.WAV";
	public final static String	win	="Sounds/win.wav";



	

	
}
