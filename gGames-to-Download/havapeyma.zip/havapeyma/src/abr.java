
public class abr extends GameMovableElementAdapter
{

	public static final int	abr	    =0;
	public static final int	abr2	=1;
	public static final int	abr3	=2;
	public static final int	abr4	=3;
	public static final int	abr5	=4;
	
	public abr(int x , int y , int aType)
	{
		super((getaType(aType)) , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -14000 ,
				GameConstants.Game_Height);
		setDownDirection();
		setSpeedY(1);
		StartMoving();
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	
	private static String getaType(int type)
	{
		if (type==abr)
			return "Images/abr.png";
		else if (type==abr2)
			return "Images/abr2.png";
		else if (type==abr3)
			return "Images/abr3.png";
		else if (type==abr4)
			return "Images/abr4.png";
		else if (type==abr5)
			return "Images/abr5.png";
		return "";
	}
	

}


