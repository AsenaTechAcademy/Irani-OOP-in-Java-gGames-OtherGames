public class bomb extends GameMovableElementAdapter
{
	private int		Lifes=2;

	
	public bomb(int x , int y)
	{
		super("Images/bomb.png" , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -14000 ,
				GameConstants.Game_Height);
		setDownDirection();
		setSpeedY(2);
		StartMoving();
	}
	
	
	@Override
	public void CollideWith(GameElementAdapter element) {
		super.CollideWith(element);
		if(element instanceof Bullet)
		{
			if (Lifes==1)
			{
				this.Destroy();
				return;
				
			}
			this.LifeDecrease();

			return;
		}
		else if(element instanceof Mooshak||element instanceof havapeyma)
		{
				this.Destroy();
		}		
			
	}
	protected void LifeDecrease()
	{
		if (Lifes>=1)
			Lifes--;
	}
	

}
