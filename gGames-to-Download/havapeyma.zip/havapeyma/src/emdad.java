
public class emdad extends GameMovableElementAdapter
{
	public emdad(int x , int y)
	{
		super("Images/emdad.png" , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -14000 ,
				GameConstants.Game_Height-this.getHeight());
		setSpeedY(1);
		setDownDirection();
		StartMoving();

	}
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	@Override
	public void CollideWith(GameElementAdapter element) {
		if(element instanceof havapeyma||element instanceof Mooshak||element instanceof Bullet)
			this.Destroy();
	}

}
