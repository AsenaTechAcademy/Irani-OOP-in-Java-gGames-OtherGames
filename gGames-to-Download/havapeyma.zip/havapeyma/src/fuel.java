

public class fuel extends GameMovableElementAdapter
{

	public static final int	jazire	=0;
	public static final int	jazire2	=1;
	public static final int	jazire3	=2;
	public static final int	jazire4	=3;
	public static final int	jazire5	=4;
	
	public fuel(int x , int y , int fType)
	{
		super((getfType(fType)) , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -14000 ,
				GameConstants.Game_Height-this.getHeight());
		setDownDirection();
		setSpeedY(1);
		StartMoving();
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	
	private static String getfType(int type)
	{
		if (type==jazire)
			return "Images/fuel.png";
		else if (type==jazire2)
			return "Images/fuel2.png";
		else if (type==jazire3)
			return "Images/fuel3.png";
		else if (type==jazire4)
			return "Images/fuel4.png";
		else if (type==jazire5)
			return "Images/fuel5.png";
		return "";
	}
	@Override
	public void CollideWith(GameElementAdapter element) {
		if(element instanceof havapeyma||element instanceof Mooshak||element instanceof Bullet)
			this.Destroy();
	}

}


