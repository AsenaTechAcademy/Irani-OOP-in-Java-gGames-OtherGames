public class h21 extends hdoshman
{
	private int				cImage		=0;

	private static int sx=1;
	private static int sy=2;
	private static int lifes=2;
	private static String	Images[]	= { "Images/h21.png", "Images/h22.png" };
	public h21(int x, int y) 
	{
		super(x, y, sx, sy, lifes,Images[0]);
		setRightDirection();
		this.destroyedScore=60;
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -16000 ,
				GameConstants.Game_Height-this.getHeight()/4);

	}
	public void setlife(int life)
	{
		super.setlife(life);
		lifes=life;
	}
	@Override
	public void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.nextImage();
		setLeftDirection();
		
	}
	@Override
	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.nextImage();
		setRightDirection();
	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/h2"+(cImage+1)+".png");
	}
	
}
