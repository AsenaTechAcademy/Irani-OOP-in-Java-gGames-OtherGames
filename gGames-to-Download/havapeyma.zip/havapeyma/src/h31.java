public class h31 extends hdoshman
{
	private static int sx=4;
	private static int sy=2;
	private static int lifes=5;
	private int				cImage		=0;
	private static String	Images[]	= { "Images/h31.png", "Images/h32.png" };

	public h31(int x, int y) 
	{
		super(x, y, sx, sy, lifes,Images[0]);
		setRightDirection();
		this.destroyedScore=150;
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -16000 ,
				GameConstants.Game_Height-this.getHeight()/4);
	}
	public void setlife(int life)
	{
		super.setlife(life);
		lifes=life;
	}
	@Override
	public void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.nextImage();
		setLeftDirection();
		
	}
	@Override
	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.nextImage();
		setRightDirection();
	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/h3"+(cImage+1)+".png");
	}
	
	
}
