public class h4 extends hdoshman
{
	private static int sx=0;
	private static int sy=2;
	private static int lifes=5;

	public h4(int x, int y) 
	{
		super(x, y, sx, sy, lifes,"Images/h4.png");
		setDownDirection();
		this.destroyedScore=80;
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -16000 ,
				GameConstants.Game_Height-this.getHeight()/4);
	}
	public void setlife(int life)
	{
		super.setlife(life);
	}
	
	public void CollideLeftBorder()
	{
		this.Destroy();
		super.CollideLeftBorder();
		
	}
}
