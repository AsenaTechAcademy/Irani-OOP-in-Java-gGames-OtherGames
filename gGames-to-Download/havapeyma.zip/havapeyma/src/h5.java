public class h5 extends hdoshman
{
	private static int sx=0;
	private static int sy=3;
	private static int lifes=4;

	public h5(int x, int y) 
	{
		super(x, y, sx, sy, lifes,"Images/h5.png");
		setDownDirection();
		this.destroyedScore=75;
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -16000 ,
				GameConstants.Game_Height-this.getHeight()/4);

	}
	public void setlife(int life)
	{
		super.setlife(life);
	}
	
	public void CollideLeftBorder()
	{
		this.Destroy();
		super.CollideLeftBorder();
		
	}
}
