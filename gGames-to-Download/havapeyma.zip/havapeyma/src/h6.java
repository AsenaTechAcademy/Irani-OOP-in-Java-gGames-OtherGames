public class h6 extends hdoshman
{
	private static int sx=0;
	private static int sy=3;
	private static int lifes=1;

	public h6(int x, int y) 
	{
		super(x, y, sx, sy, lifes,"Images/h6.png");
		setLeftDirection();
		this.destroyedScore=55;
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -16000 ,
				GameConstants.Game_Height-this.getHeight()/4);
	}
	public void setlife(int life)
	{
		super.setlife(life);
	}
	public void CollideLeftBorder()
	{
		this.Destroy();
		super.CollideLeftBorder();
	}
}
