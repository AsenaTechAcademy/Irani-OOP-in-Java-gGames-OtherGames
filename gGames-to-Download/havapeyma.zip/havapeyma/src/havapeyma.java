import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class havapeyma extends GameMovableElementAdapter
{
	
	public havapeyma(int x , int y)
	{
		super("Images/havapeyma.gif" , x , y);
		this.setSpeedX(7);
		this.setSpeedY(5);
		
	}
	public void Reset()
	{
		super.setXY(300 , 340); // set to first status
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -15 ,
				GameConstants.Game_Height-40);
	}
	
	
	public boolean WantMouseEvents()
	{
		return true;
	}
	@Override
	public boolean WantKeyEvents()
	{
		return true;
	}
	@Override
	public void KeyReleased(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_LEFT||e.getKeyCode()==KeyEvent.VK_RIGHT||e.getKeyCode()==KeyEvent.VK_UP||e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			this.StopMoving();
			
		}
	}
	@Override
	public void KeyPressed(KeyEvent e)
	{
		if (e.getKeyCode()==KeyEvent.VK_SPACE)
		{
			if(GGame.getFire()>=2)
				this.Fire_ragbar();
		}
		
		else if (e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			if(this.getX()>=-10)
			    this.setSpeedY(0);
			    this.setSpeedX(7);
			    StartMoving();
			    setLeftDirection();
		}
		else if (e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			if(this.getX()<=810)
			{   this.setSpeedY(0);
			    this.setSpeedX(7);
			    StartMoving();
			    setRightDirection();}
		}
		else if (e.getKeyCode()==KeyEvent.VK_UP)
		{
			if(this.getY()>=-20)
			{this.setSpeedY(5);
			this.setSpeedX(0);
			StartMoving();
			setUpDirection();	}
         }
		else if (e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			if(this.getY()<=620)
			{this.setSpeedY(5);
			this.setSpeedX(0);
			StartMoving();
			setDownDirection();
			}
		}
		else if(e.getKeyCode()==KeyEvent.VK_ENTER)
		{
			if(GGame.getMooshak()>=1)
			this.Fire_mooshak();
		}
	}
	public void mouseMoved(MouseEvent e)
	{	
		setXY(e.getX()-this.getWidth()/2 ,  e.getY()-this.getHeight()/2);
	}
	

	public void mouseb3_click(MouseEvent e)
	{
		if(GGame.getMooshak()>=1)
		Fire_mooshak();
		
	}
	public void mousePressed(MouseEvent e)
	{
		int x=0;
		while(x<=1)
		{
			Fire_ragbar();
			x++;
			try {
				Thread.sleep(40);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}	
	}
	public void mouseb1_click(MouseEvent e)
	{
		int x=0;
		while(x<=1)
		{
			Fire_ragbar();
			x++;
			try {
				Thread.sleep(30);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}	
	}
	
	public void CollideWith(GameElementAdapter e)
	{

		if(e instanceof emdad)
		{
			GGame.IncreaseLive();
			SoundStore.get().Play(Sounds.galb);
			
			return;
		}
		else if(e instanceof ragbar)
		{
			GGame.IncreaseFires(30);
			SoundStore.get().Play(Sounds.khragbar);

			return;
		}
		else if(e instanceof rocket)
		{
			GGame.IncreaseMooshak(4);
			SoundStore.get().Play(Sounds.khmooshak);

			return;
		}
		else if(e instanceof fuel)
			{
			GGame.IncreaseFuel();
			SoundStore.get().Play(Sounds.sookht);

			return;
			}
		else if(e instanceof abr ||e instanceof k11||e instanceof k21||e instanceof Bullet 
				|| e instanceof Mooshak||e instanceof jazire)
			return;
		
		GGame.DecreaseLive();
		this.Reset();
	}
	public void mouseDragged(MouseEvent e)
	{
		setXY(e.getX()-this.getWidth()/2 ,  e.getY()-this.getHeight()/2);
	}
	
	private void Fire_ragbar()
	{
		if (GGame.getTotalFires()>0)
		{
			Bullet b=new Bullet(0 , 0);
			b.setXY(this.getX()+(this.getWidth()/2)-b.getWidth()-5 , this.getY()-18);
			GGame.addNewEntity(b);
			GGame.DecreaseFires(1);
			SoundStore.get().Play(Sounds.ragbar);
		}
	}
	private void Fire_mooshak()
	{
		Mooshak b=new Mooshak(0 , 0);
		b.setXY(this.getX()+(this.getWidth()/2)-b.getWidth()+25 , this.getY()-80);
		GGame.addNewEntity(b);
		GGame.DecreaseMooshak(1);
		SoundStore.get().Play(Sounds.Mooshak);
	}
	public void Step()
	{
		super.Step();
		
		if(GGame.getFuel()<=1)
			GGame.setLevelStatus(1);
		else if(GGame.gettime()%4==0)
			GGame.DecreaseFuel();
	}
	
}
