
public class hb extends GameMovableElementAdapter
{
	private int		Lifes=800;

	
	public hb(int x , int y)
	{
		super("Images/hb.png" , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -1000 ,
				GameConstants.Game_Height);
		setSpeedX(1);
		setLeftDirection();
		StartMoving();
	}
	@Override
	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.setRightDirection();
	}
	@Override
	protected void CollideRightBorder() {
		super.CollideRightBorder();
		this.setLeftDirection();
	}
	@Override
	public void CollideWith(GameElementAdapter element) {
		super.CollideWith(element);
		if(element instanceof Bullet)
		{
			if (Lifes==2)
			{
				this.Destroy();
				GGame.setLevelStatus(2);
				return;
				
			}
			this.LifeDecrease(2);

			return;
		}
		else if(element instanceof Mooshak)
		{
			if (Lifes==10)
			{
				this.Destroy();
				GGame.setLevelStatus(2);
				return;
				
			}
			this.LifeDecrease(10);
			return;
		}
			
	}
	protected void LifeDecrease(int a)
	{
		if (Lifes>=a)
			Lifes-=a;
	}
	

}
