public class hdoshman extends GameMovableElementAdapter
{
	private int		Lifes;
	
	public hdoshman( int x , int y ,int sx,int sy, int lifes, String ref)
	{
		super(ref , x , y);
		
		setSpeedX(sx);
		setSpeedY(sy);
		setDownDirection();
		StartMoving();
		
		Lifes=lifes;
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -16000 ,
				GameConstants.Game_Height-this.getHeight()/4);
		
	}
	public void setlife(int life)
	{
		Lifes=life;
	}
	public int getlife()
	{
		return Lifes;
	}
	
	protected void LifeDecrease()
	{
		if (Lifes>=2)
			Lifes--;
	}
	public void CollideWith(GameElementAdapter element)
	{
		if ((element instanceof Bullet))
		{
			if (Lifes==1)
			{
				this.Destroy();
				GGame.IncreaseScore(this.destroyedScore);
				return;
				
			}
			this.LifeDecrease();

			return;
		}
		else if(element instanceof havapeyma||element instanceof Mooshak)
		{
			this.Destroy();
			GGame.IncreaseScore(this.destroyedScore);

		}
		else if(element instanceof abr||element instanceof fuel||element instanceof rocket||element instanceof ragbar||
				element instanceof k11||element instanceof k21)
			return;
	}
	protected void CollideDownBorder()
	{
		super.CollideDownBorder();
		this.Destroy();
	}
	
	
}