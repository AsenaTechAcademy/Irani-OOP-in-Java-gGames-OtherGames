
public class jazire extends GameMovableElementAdapter
{

	public static final int	jazire	=0;
	public static final int	jazire2	=1;
	public static final int	jazire3	=2;
	public static final int	jazire4	=3;
	public static final int	jazire5	=4;
	
	public jazire(int x , int y , int jType)
	{
		super((getjType(jType)) , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -14000 ,
				GameConstants.Game_Height);
		setDownDirection();
		setSpeedY(1);
		StartMoving();
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	
	private static String getjType(int type)
	{
		if (type==jazire)
			return "Images/jazire.png";
		else if (type==jazire2)
			return "Images/jazire2.png";
		else if (type==jazire3)
			return "Images/jazire3.png";
		else if (type==jazire4)
			return "Images/jazire4.png";
		else if (type==jazire5)
			return "Images/jazire5.png";
		return "";
	}

}
