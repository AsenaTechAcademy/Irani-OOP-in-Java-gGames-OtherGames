public class k11 extends hdoshman
{
	private static int sx=0;
	private static int sy=1;
	private static int lifes=3;
	private int				cImage		=0;
	private static String	Images[]	= { "Images/k11.png", "Images/k12.png" };
	public k11(int x, int y) 
	{
		super(x, y, sx, sy, lifes,Images[0]);
		setRightDirection();
	}
	
	public void setlife(int life)
	{
		super.setlife(life);
	}
	@Override
	public void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.nextImage();
		setLeftDirection();
		
	}
	@Override
	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.nextImage();
		setRightDirection();
	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/k1"+(cImage+1)+".png");
	}
	
	@Override
	public void CollideWith(GameElementAdapter element) {
		return;
	}
	
}
