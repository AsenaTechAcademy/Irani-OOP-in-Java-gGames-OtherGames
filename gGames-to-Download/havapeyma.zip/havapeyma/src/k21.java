public class k21 extends hdoshman
{
	private static int sx=0;
	private static int sy=2;
	private static int lifes=3;
	private int				cImage		=0;
	private static String	Images[]	= { "Images/k21.png", "Images/k22.png" };
	public k21(int x, int y) 
	{
		super(x, y, sx, sy, lifes,Images[0]);
		setRightDirection();
	}
	public void setlife(int life)
	{
		super.setlife(life);
		lifes=life;
	}
	@Override
	public void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.nextImage();
		setLeftDirection();
		
	}
	@Override
	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.nextImage();
		setRightDirection();
	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/k2"+(cImage+1)+".png");
	}
	
	@Override
	public void CollideWith(GameElementAdapter element) {
		return;
	}
	
}
