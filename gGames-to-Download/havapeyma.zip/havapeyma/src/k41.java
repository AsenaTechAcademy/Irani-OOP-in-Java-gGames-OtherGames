public class k41 extends hdoshman
{
	private static int sx=0;
	private static int sy=2;
	private static int lifes=3;
	private int				cImage		=0;
	private static String	Images[]	= { "Images/k41.png", "Images/k42.png" };
	public k41(int x, int y) 
	{
		super(x, y, sx, sy, lifes,Images[0]);
		setRightDirection();
		this.destroyedScore=150;
	}
	public void setlife(int life)
	{
		super.setlife(life);
		lifes=life;
	}
	@Override
	public void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.nextImage();
		setLeftDirection();
		
	}
	@Override
	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.nextImage();
		setRightDirection();
	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/k4"+(cImage+1)+".png");
	}
	
}
