public class k51 extends hdoshman
{
	private static int sx=2;
	private static int sy=1;
	private static int lifes=4;
	private int				cImage		=0;
	private static String	Images[]	= { "Images/k51.png", "Images/k52.png" };
	public k51(int x, int y) 
	{
		super(x, y, sx, sy, lifes,Images[0]);
		setRightDirection();
		this.destroyedScore=200;
	}
	public void setlife(int life)
	{
		super.setlife(life);
		lifes=life;
	}
	public void CollideRightBorder()
	{
		super.CollideRightBorder();
		this.nextImage();
		setLeftDirection();
		
	}
	@Override
	protected void CollideLeftBorder() {
		super.CollideLeftBorder();
		this.nextImage();
		setRightDirection();
	}
	private void nextImage()
	{
		cImage=(cImage+1)%2;
		ChangeImage("Images/k5"+(cImage+1)+".png");
	}
}
