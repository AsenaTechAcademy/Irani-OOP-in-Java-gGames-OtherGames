
public class ragbar extends GameMovableElementAdapter
{
	
	public ragbar(int x , int y)
	{
		super("Images/ragbar.png" , x , y);
		SetLimits(0 , GameConstants.Game_Width-this.getWidth() , -14000 ,
				GameConstants.Game_Height);
		setDownDirection();
		setSpeedY(2);
		StartMoving();
	}
	protected void CollideDownBorder()
	{
		this.Destroy();
	}
	@Override
	public void CollideWith(GameElementAdapter element) {
		if(element instanceof havapeyma||element instanceof Mooshak||element instanceof Bullet)
			this.Destroy();
	}

}


