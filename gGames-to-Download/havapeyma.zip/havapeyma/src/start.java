import java.awt.event.KeyEvent;

public class start extends GameElementAdapter
{
	public start(int x , int y)
	{
		super("Images/start.png" , x , y);
	}
	@Override
	public boolean WantKeyEvents() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public void KeyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		super.KeyPressed(e);
		if(e.getKeyCode()==KeyEvent.VK_CONTROL)
		{
			this.Destroy();
		}
	}
}